import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Home, User, MessageCircle, Plus, Bell, Upload,
  Video, Heart, Search, Settings
} from 'lucide-react';

interface BottomNavigationProps {
  activeTab: 'feed' | 'inbox' | 'upload' | 'profile';
  onTabChange: (tab: 'feed' | 'inbox' | 'upload' | 'profile') => void;
  notificationCounts?: {
    inbox: number;
    friends: number;
  };
}

export function BottomNavigation({ 
  activeTab, 
  onTabChange,
  notificationCounts = { inbox: 17, friends: 99 }
}: BottomNavigationProps) {
  const [showUploadOptions, setShowUploadOptions] = useState(false);

  const handleUploadClick = () => {
    if (activeTab === 'upload') {
      setShowUploadOptions(!showUploadOptions);
    } else {
      onTabChange('upload');
      setShowUploadOptions(true);
    }
  };

  const navItems = [
    {
      id: 'feed' as const,
      label: 'Home',
      icon: Home,
      activeColor: 'text-white',
      inactiveColor: 'text-gray-400'
    },
    {
      id: 'inbox' as const,
      label: 'Inbox',
      icon: MessageCircle,
      activeColor: 'text-white',
      inactiveColor: 'text-gray-400',
      badge: notificationCounts.inbox
    },
    {
      id: 'upload' as const,
      label: 'Upload',
      icon: Plus,
      isSpecial: true
    },
    {
      id: 'profile' as const,
      label: 'Profile',
      icon: User,
      activeColor: 'text-white',
      inactiveColor: 'text-gray-400'
    }
  ];

  return (
    <>
      {/* Upload Options Overlay */}
      {showUploadOptions && (
        <div className="fixed inset-0 bg-black/75 z-40" onClick={() => setShowUploadOptions(false)}>
          <div className="absolute bottom-20 left-1/2 transform -translate-x-1/2">
            <div className="bg-gray-900 rounded-2xl p-4 border border-gray-700 shadow-xl text-white">
              <div className="grid grid-cols-2 gap-4 w-64">
                <Button
                  variant="ghost"
                  className="flex flex-col items-center gap-2 h-20 hover:bg-gray-800"
                  onClick={() => {
                    onTabChange('upload');
                    setShowUploadOptions(false);
                  }}
                >
                  <Video className="w-6 h-6 text-blue-400" />
                  <span className="text-xs">Video</span>
                </Button>
                
                <Button
                  variant="ghost"
                  className="flex flex-col items-center gap-2 h-20 hover:bg-gray-800"
                  onClick={() => {
                    // Handle photo upload
                    setShowUploadOptions(false);
                  }}
                >
                  <Upload className="w-6 h-6 text-green-400" />
                  <span className="text-xs">Photo</span>
                </Button>
                
                <Button
                  variant="ghost"
                  className="flex flex-col items-center gap-2 h-20 hover:bg-gray-800"
                  onClick={() => {
                    // Handle live stream
                    setShowUploadOptions(false);
                  }}
                >
                  <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full" />
                  </div>
                  <span className="text-xs">Go Live</span>
                </Button>
                
                <Button
                  variant="ghost"
                  className="flex flex-col items-center gap-2 h-20 hover:bg-gray-800"
                  onClick={() => {
                    // Handle story
                    setShowUploadOptions(false);
                  }}
                >
                  <Heart className="w-6 h-6 text-pink-400" />
                  <span className="text-xs">Story</span>
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Navigation Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-black/95 backdrop-blur-sm border-t border-gray-800">
        <div className="max-w-md mx-auto px-4 py-2">
          <div className="flex items-center justify-around">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              const Icon = item.icon;

              if (item.isSpecial) {
                return (
                  <div key={item.id} className="relative">
                    <Button
                      onClick={handleUploadClick}
                      className={`
                        w-14 h-14 rounded-full bg-white hover:bg-gray-100 text-black
                        flex items-center justify-center transform transition-all duration-200
                        ${showUploadOptions ? 'scale-110 rotate-45' : 'scale-100 rotate-0'}
                        shadow-lg
                      `}
                    >
                      <Icon className="w-7 h-7" />
                    </Button>
                  </div>
                );
              }

              return (
                <Button
                  key={item.id}
                  variant="ghost"
                  onClick={() => onTabChange(item.id)}
                  className={`
                    flex flex-col items-center gap-1 p-2 h-auto hover:bg-transparent
                    ${isActive ? item.activeColor : item.inactiveColor}
                    transition-colors duration-200
                  `}
                >
                  <div className="relative">
                    <Icon className="w-6 h-6" />
                    {item.badge && item.badge > 0 && (
                      <Badge 
                        className="absolute -top-2 -right-2 bg-red-500 text-white text-xs min-w-[18px] h-[18px] rounded-full flex items-center justify-center p-0"
                      >
                        {item.badge > 99 ? '99+' : item.badge}
                      </Badge>
                    )}
                  </div>
                  <span className="text-xs font-medium">{item.label}</span>
                </Button>
              );
            })}
          </div>
        </div>

        {/* Progress indicator */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-800">
          <div 
            className="h-full bg-white rounded-full transition-all duration-300"
            style={{ 
              width: '25%', 
              marginLeft: `${navItems.findIndex(item => item.id === activeTab) * 25}%` 
            }}
          />
        </div>
      </div>
    </>
  );
}
