import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Heart, MessageCircle, Share, Bookmark, MoreHorizontal, 
  ThumbsUp, Laugh, Angry, Sad, Surprised, ChevronDown,
  Image, Video, Smile, Gift, MapPin, Users, Globe,
  Eye, Play, Pause, Volume2, VolumeX
} from 'lucide-react';

interface FacebookPost {
  id: string;
  author: {
    name: string;
    avatar?: string;
    verified?: boolean;
    isVIP?: boolean;
  };
  content: string;
  images?: string[];
  video?: {
    url: string;
    thumbnail: string;
    duration: number;
  };
  timestamp: Date;
  privacy: 'public' | 'friends' | 'private';
  location?: string;
  reactions: {
    like: number;
    love: number;
    laugh: number;
    angry: number;
    sad: number;
    wow: number;
  };
  comments: number;
  shares: number;
  userReaction?: 'like' | 'love' | 'laugh' | 'angry' | 'sad' | 'wow' | null;
  isBookmarked: boolean;
}

const mockPosts: FacebookPost[] = [
  {
    id: '1',
    author: { 
      name: 'Teez', 
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
      verified: true, 
      isVIP: true 
    },
    content: 'Just finished the most intense task in the Big Brother house! 🏠💪 The housemates really brought their A-game today. Can\'t wait to see who becomes the next Head of House! #BigBrother #TeamWork #Challenge',
    images: [
      'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=600&h=400&fit=crop',
      'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=600&h=400&fit=crop'
    ],
    timestamp: new Date(Date.now() - 1800000),
    privacy: 'public',
    location: 'Big Brother House',
    reactions: { like: 342, love: 89, laugh: 45, angry: 2, sad: 1, wow: 67 },
    comments: 128,
    shares: 34,
    userReaction: 'like',
    isBookmarked: false
  },
  {
    id: '2',
    author: { 
      name: 'Sarah Lagos', 
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face',
      verified: false 
    },
    content: 'Who else is obsessed with this season? The drama, the friendships, the competitions... everything is just *chef\'s kiss* 👨‍🍳💋 What\'s your favorite moment so far?',
    video: {
      url: 'https://example.com/video.mp4',
      thumbnail: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=600&h=400&fit=crop',
      duration: 45
    },
    timestamp: new Date(Date.now() - 3600000),
    privacy: 'public',
    reactions: { like: 156, love: 234, laugh: 78, angry: 5, sad: 3, wow: 23 },
    comments: 67,
    shares: 12,
    userReaction: 'love',
    isBookmarked: true
  },
  {
    id: '3',
    author: { 
      name: 'BigBrother Official', 
      avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&h=150&fit=crop&crop=face',
      verified: true 
    },
    content: 'ANNOUNCEMENT: Tomorrow at 8 PM WAT, we will have a special live eviction show! 📺✨ Make sure to tune in and see which housemate will be saying goodbye to the house. The tension is real! 🔥',
    timestamp: new Date(Date.now() - 7200000),
    privacy: 'public',
    reactions: { like: 567, love: 123, laugh: 45, angry: 12, sad: 34, wow: 89 },
    comments: 234,
    shares: 89,
    userReaction: null,
    isBookmarked: false
  }
];

interface FacebookStyleFeedProps {
  user?: { name: string; isAuth: boolean } | null;
  onAuthRequired?: () => void;
  onGoToLiveStream?: () => void;
}

export function FacebookStyleFeed({ user, onAuthRequired, onGoToLiveStream }: FacebookStyleFeedProps) {
  const [posts, setPosts] = useState<FacebookPost[]>(mockPosts);
  const [newPostContent, setNewPostContent] = useState('');
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [playingVideo, setPlayingVideo] = useState<string | null>(null);

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (hours < 1) return 'Just now';
    if (hours < 24) return `${hours}h`;
    if (days === 1) return 'Yesterday';
    return `${days}d`;
  };

  const getReactionIcon = (type: string) => {
    switch (type) {
      case 'like': return '👍';
      case 'love': return '❤️';
      case 'laugh': return '😂';
      case 'angry': return '😠';
      case 'sad': return '😢';
      case 'wow': return '😮';
      default: return '👍';
    }
  };

  const getPrivacyIcon = (privacy: string) => {
    switch (privacy) {
      case 'public': return <Globe className="w-3 h-3" />;
      case 'friends': return <Users className="w-3 h-3" />;
      case 'private': return <Users className="w-3 h-3" />;
      default: return <Globe className="w-3 h-3" />;
    }
  };

  const handleReaction = (postId: string, reactionType: 'like' | 'love' | 'laugh' | 'angry' | 'sad' | 'wow') => {
    if (!user?.isAuth) {
      onAuthRequired?.();
      return;
    }

    setPosts(prev => prev.map(post => {
      if (post.id === postId) {
        const currentReaction = post.userReaction;
        const newReactions = { ...post.reactions };
        
        // Remove previous reaction
        if (currentReaction) {
          newReactions[currentReaction] = Math.max(0, newReactions[currentReaction] - 1);
        }
        
        // Add new reaction if different from current
        const newUserReaction = currentReaction === reactionType ? null : reactionType;
        if (newUserReaction) {
          newReactions[newUserReaction] = newReactions[newUserReaction] + 1;
        }

        return {
          ...post,
          reactions: newReactions,
          userReaction: newUserReaction
        };
      }
      return post;
    }));
  };

  const handleShare = (postId: string) => {
    if (!user?.isAuth) {
      onAuthRequired?.();
      return;
    }

    setPosts(prev => prev.map(post => 
      post.id === postId 
        ? { ...post, shares: post.shares + 1 }
        : post
    ));
  };

  const handleBookmark = (postId: string) => {
    if (!user?.isAuth) {
      onAuthRequired?.();
      return;
    }

    setPosts(prev => prev.map(post => 
      post.id === postId 
        ? { ...post, isBookmarked: !post.isBookmarked }
        : post
    ));
  };

  const createPost = () => {
    if (!user?.isAuth) {
      onAuthRequired?.();
      return;
    }

    if (!newPostContent.trim()) return;

    const newPost: FacebookPost = {
      id: Date.now().toString(),
      author: { name: user.name, verified: false },
      content: newPostContent,
      timestamp: new Date(),
      privacy: 'public',
      reactions: { like: 0, love: 0, laugh: 0, angry: 0, sad: 0, wow: 0 },
      comments: 0,
      shares: 0,
      userReaction: null,
      isBookmarked: false
    };

    setPosts(prev => [newPost, ...prev]);
    setNewPostContent('');
    setShowCreatePost(false);
  };

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-950">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 shadow-sm">
        <div className="max-w-2xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">Big Brother Community</h1>
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="text-green-500 border-green-500">
                Live
              </Badge>
              <Button 
                onClick={onGoToLiveStream}
                size="sm" 
                className="bg-red-500 hover:bg-red-600 text-white"
              >
                Watch Live
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-4">
        {/* Create Post */}
        <Card className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <Avatar className="w-10 h-10">
                <AvatarImage src={user?.isAuth ? 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face' : undefined} />
                <AvatarFallback className="bg-primary text-white">
                  {user?.name?.charAt(0) || 'G'}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1">
                {!showCreatePost ? (
                  <Button
                    variant="outline"
                    onClick={() => user?.isAuth ? setShowCreatePost(true) : onAuthRequired?.()}
                    className="w-full justify-start text-gray-500 hover:bg-gray-50 dark:hover:bg-gray-800"
                  >
                    What's on your mind{user?.name ? `, ${user.name}` : ''}?
                  </Button>
                ) : (
                  <div className="space-y-3">
                    <textarea
                      value={newPostContent}
                      onChange={(e) => setNewPostContent(e.target.value)}
                      placeholder={`What's on your mind${user?.name ? `, ${user.name}` : ''}?`}
                      className="w-full p-3 border border-gray-200 dark:border-gray-700 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                      rows={3}
                    />
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="sm">
                          <Image className="w-4 h-4 mr-1" />
                          Photo
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Video className="w-4 h-4 mr-1" />
                          Video
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Smile className="w-4 h-4 mr-1" />
                          Feeling
                        </Button>
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => {
                            setShowCreatePost(false);
                            setNewPostContent('');
                          }}
                        >
                          Cancel
                        </Button>
                        <Button 
                          size="sm"
                          onClick={createPost}
                          disabled={!newPostContent.trim()}
                        >
                          Post
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Posts */}
        {posts.map((post) => (
          <Card key={post.id} className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800">
            <CardContent className="p-0">
              {/* Post Header */}
              <div className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={post.author.avatar} />
                      <AvatarFallback className="bg-primary text-white">
                        {post.author.name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-gray-900 dark:text-white">
                          {post.author.name}
                        </span>
                        {post.author.verified && (
                          <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-800 px-1 py-0">
                            ✓
                          </Badge>
                        )}
                        {post.author.isVIP && (
                          <Badge className="text-xs bg-yellow-500 text-black px-1 py-0">
                            VIP
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-1 text-sm text-gray-500 dark:text-gray-400">
                        <span>{formatTime(post.timestamp)}</span>
                        <span>•</span>
                        <div className="flex items-center gap-1">
                          {getPrivacyIcon(post.privacy)}
                        </div>
                        {post.location && (
                          <>
                            <span>•</span>
                            <div className="flex items-center gap-1">
                              <MapPin className="w-3 h-3" />
                              <span>{post.location}</span>
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <Button variant="ghost" size="sm">
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Post Content */}
              <div className="px-4 pb-3">
                <p className="text-gray-900 dark:text-white whitespace-pre-wrap leading-relaxed">
                  {post.content}
                </p>
              </div>

              {/* Media */}
              {post.images && post.images.length > 0 && (
                <div className={`grid gap-1 ${post.images.length === 1 ? 'grid-cols-1' : post.images.length === 2 ? 'grid-cols-2' : 'grid-cols-2'}`}>
                  {post.images.map((image, index) => (
                    <div key={index} className="relative aspect-square overflow-hidden">
                      <img 
                        src={image} 
                        alt="" 
                        className="w-full h-full object-cover hover:scale-105 transition-transform cursor-pointer"
                      />
                    </div>
                  ))}
                </div>
              )}

              {post.video && (
                <div className="relative">
                  <div className="relative aspect-video bg-black">
                    <img 
                      src={post.video.thumbnail} 
                      alt="" 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Button 
                        size="lg"
                        className="w-16 h-16 rounded-full bg-black/50 hover:bg-black/70"
                        onClick={() => setPlayingVideo(playingVideo === post.id ? null : post.id)}
                      >
                        {playingVideo === post.id ? (
                          <Pause className="w-8 h-8" />
                        ) : (
                          <Play className="w-8 h-8 ml-1" />
                        )}
                      </Button>
                    </div>
                    <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                      {Math.floor(post.video.duration / 60)}:{(post.video.duration % 60).toString().padStart(2, '0')}
                    </div>
                  </div>
                </div>
              )}

              {/* Reactions Summary */}
              <div className="px-4 py-3 border-t border-gray-100 dark:border-gray-800">
                <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
                  <div className="flex items-center gap-1">
                    {Object.entries(post.reactions)
                      .filter(([_, count]) => count > 0)
                      .slice(0, 3)
                      .map(([type, count]) => (
                        <span key={type} className="text-base">
                          {getReactionIcon(type)}
                        </span>
                      ))}
                    <span className="ml-1">
                      {Object.values(post.reactions).reduce((sum, count) => sum + count, 0)}
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <span>{post.comments} comments</span>
                    <span>{post.shares} shares</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="px-4 py-2 border-t border-gray-100 dark:border-gray-800">
                <div className="flex items-center justify-around">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => handleReaction(post.id, 'like')}
                    className={`flex-1 ${post.userReaction === 'like' ? 'text-blue-500' : 'text-gray-600 dark:text-gray-400'}`}
                  >
                    <ThumbsUp className="w-4 h-4 mr-2" />
                    Like
                  </Button>
                  
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="flex-1 text-gray-600 dark:text-gray-400"
                  >
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Comment
                  </Button>
                  
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => handleShare(post.id)}
                    className="flex-1 text-gray-600 dark:text-gray-400"
                  >
                    <Share className="w-4 h-4 mr-2" />
                    Share
                  </Button>
                  
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => handleBookmark(post.id)}
                    className={`${post.isBookmarked ? 'text-yellow-500' : 'text-gray-600 dark:text-gray-400'}`}
                  >
                    <Bookmark className={`w-4 h-4 ${post.isBookmarked ? 'fill-current' : ''}`} />
                  </Button>
                </div>
              </div>

              {/* Reaction Options */}
              <div className="px-4 pb-3">
                <div className="flex items-center gap-1 opacity-0 hover:opacity-100 transition-opacity">
                  {['like', 'love', 'laugh', 'wow', 'sad', 'angry'].map((reaction) => (
                    <Button
                      key={reaction}
                      variant="ghost"
                      size="sm"
                      onClick={() => handleReaction(post.id, reaction as any)}
                      className="p-1 text-xl hover:scale-125 transition-transform"
                    >
                      {getReactionIcon(reaction)}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
