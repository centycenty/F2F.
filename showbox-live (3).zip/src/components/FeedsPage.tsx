import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { UserProfile } from "./UserProfile";
import {
  Video,
  Upload,
  Play,
  Pause,
  Heart,
  MessageCircle,
  Share,
  Clock,
  User,
  Filter,
  Search,
  Plus,
  X,
  Volume2,
  VolumeX,
  Maximize,
  Flag,
  Eye,
  TrendingUp,
  Calendar,
  Tag,
  Camera,
  Zap,
  Gift,
  Megaphone
} from "lucide-react";
import { VideoPlayer } from './streaming/VideoPlayer';
import { FeedComments } from './streaming/FeedComments';
import { NotificationToast, useNotifications } from './streaming/NotificationToast';

interface FeedPost {
  id: string;
  author: {
    name: string;
    avatar?: string;
    verified?: boolean;
  };
  type: 'fun' | 'ad' | 'announcement';
  title: string;
  description: string;
  videoUrl?: string;
  thumbnail?: string;
  duration: number; // in seconds
  likes: number;
  comments: number;
  shares: number;
  views: number;
  createdAt: Date;
  tags: string[];
  isLiked?: boolean;
}

interface FeedsPageProps {
  user: { name: string; isAuth: boolean } | null;
  onAuthRequired: () => void;
  onGoToLiveStream: () => void;
}

const mockPosts: FeedPost[] = [
  {
    id: '1',
    author: { name: 'BigBro_Fan', verified: true },
    type: 'fun',
    title: 'My reaction to last night episode! 😱',
    description: 'OMG did you see what happened?! This is crazy!',
    duration: 15,
    likes: 1240,
    comments: 89,
    shares: 45,
    views: 5600,
    createdAt: new Date(Date.now() - 3600000),
    tags: ['reaction', 'biggerbro', 'episode'],
    isLiked: false
  },
  {
    id: '2',
    author: { name: 'NaijaBusiness', verified: false },
    type: 'ad',
    title: 'Best Jollof Rice in Lagos! 🍚',
    description: 'Visit our restaurant for authentic Nigerian cuisine. 15% off for Big Brother viewers!',
    duration: 25,
    likes: 567,
    comments: 23,
    shares: 78,
    views: 2300,
    createdAt: new Date(Date.now() - 7200000),
    tags: ['food', 'lagos', 'promo'],
    isLiked: true
  },
  {
    id: '3',
    author: { name: 'BB_Updates', verified: true },
    type: 'announcement',
    title: 'Special Live Event Tomorrow! 📺',
    description: 'Join us for a special live Q&A with evicted housemates. Don\'t miss it!',
    duration: 20,
    likes: 890,
    comments: 156,
    shares: 234,
    views: 4200,
    createdAt: new Date(Date.now() - 10800000),
    tags: ['announcement', 'live', 'qna'],
    isLiked: false
  },
  {
    id: '4',
    author: { name: 'TeezFanClub', verified: false },
    type: 'fun',
    title: 'Teez dance compilation! 🕺',
    description: 'All the best dance moments from our favorite housemate!',
    duration: 30,
    likes: 2100,
    comments: 145,
    shares: 89,
    views: 8900,
    createdAt: new Date(Date.now() - 14400000),
    tags: ['teez', 'dance', 'compilation'],
    isLiked: true
  }
];

export function FeedsPage({ user, onAuthRequired, onGoToLiveStream }: FeedsPageProps) {
  const [posts, setPosts] = useState<FeedPost[]>(mockPosts);
  const { notifications, removeNotification, success, error, info } = useNotifications();
  const [activeTab, setActiveTab] = useState<'all' | 'fun' | 'ad' | 'announcement'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [sortBy, setSortBy] = useState<'recent' | 'popular' | 'trending'>('recent');
  const [playingVideoId, setPlayingVideoId] = useState<string | null>(null);
  const [mutedVideos, setMutedVideos] = useState<Set<string>>(new Set());
  const [commentsOpen, setCommentsOpen] = useState<string | null>(null);
  const [showUserProfile, setShowUserProfile] = useState(false);
  const [selectedUser, setSelectedUser] = useState<string | null>(null);

  // Upload form state
  const [uploadForm, setUploadForm] = useState({
    title: '',
    description: '',
    type: 'fun' as 'fun' | 'ad' | 'announcement',
    tags: '',
    video: null as File | null
  });
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const filteredPosts = posts
    .filter(post => {
      const matchesTab = activeTab === 'all' || post.type === activeTab;
      const matchesSearch = searchTerm === '' || 
        post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
      return matchesTab && matchesSearch;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'popular':
          return b.likes - a.likes;
        case 'trending':
          return (b.likes + b.comments + b.shares) - (a.likes + a.comments + a.shares);
        case 'recent':
        default:
          return b.createdAt.getTime() - a.createdAt.getTime();
      }
    });

  const handleVideoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Check file type
    if (!file.type.startsWith('video/')) {
      alert('Please select a video file');
      return;
    }

    // Check file size (assume 30 seconds max ≈ 50MB max)
    if (file.size > 50 * 1024 * 1024) {
      alert('Video file too large. Please ensure video is under 30 seconds.');
      return;
    }

    // Create video element to check duration
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.onloadedmetadata = () => {
      if (video.duration > 30) {
        alert('Video must be 30 seconds or less');
        return;
      }
      setUploadForm(prev => ({ ...prev, video: file }));
    };
    video.src = URL.createObjectURL(file);
  };

  const handleUploadSubmit = async () => {
    if (!user?.isAuth) {
      onAuthRequired();
      return;
    }

    if (!uploadForm.video || !uploadForm.title.trim()) {
      alert('Please fill in all required fields');
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    // Simulate upload progress
    const progressInterval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + 10;
      });
    }, 200);

    // Simulate upload delay
    setTimeout(() => {
      const newPost: FeedPost = {
        id: Date.now().toString(),
        author: { name: user.name, verified: false },
        type: uploadForm.type,
        title: uploadForm.title,
        description: uploadForm.description,
        duration: 15, // Mock duration
        likes: 0,
        comments: 0,
        shares: 0,
        views: 0,
        createdAt: new Date(),
        tags: uploadForm.tags.split(',').map(tag => tag.trim()).filter(Boolean),
        isLiked: false
      };

      setPosts(prev => [newPost, ...prev]);
      setIsUploading(false);
      setUploadProgress(0);
      setShowUploadModal(false);
      setUploadForm({
        title: '',
        description: '',
        type: 'fun',
        tags: '',
        video: null
      });

      success('Upload Complete!', 'Your video has been posted to the community feeds.');
    }, 2000);
  };

  const handleLike = (postId: string) => {
    if (!user?.isAuth) {
      onAuthRequired();
      return;
    }

    setPosts(prev => prev.map(post => {
      if (post.id === postId) {
        const isLiked = !post.isLiked;
        if (isLiked) {
          info('Liked!', 'You liked this post');
        }
        return {
          ...post,
          isLiked,
          likes: isLiked ? post.likes + 1 : post.likes - 1
        };
      }
      return post;
    }));
  };

  const handleShare = (post: FeedPost) => {
    if (!user?.isAuth) {
      onAuthRequired();
      return;
    }

    // Simulate sharing
    navigator.clipboard?.writeText(`Check out this ${post.type}: ${post.title}`);
    setPosts(prev => prev.map(p =>
      p.id === post.id ? { ...p, shares: p.shares + 1 } : p
    ));

    success('Shared!', 'Link copied to clipboard');
  };

  const handleComment = (postId: string) => {
    if (!user?.isAuth) {
      onAuthRequired();
      return;
    }
    setCommentsOpen(postId);
  };

  const handleProfileClick = (username: string) => {
    setSelectedUser(username);
    setShowUserProfile(true);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'fun': return <Zap className="w-4 h-4" />;
      case 'ad': return <Gift className="w-4 h-4" />;
      case 'announcement': return <Megaphone className="w-4 h-4" />;
      default: return <Video className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'fun': return 'bg-blue-500';
      case 'ad': return 'bg-green-500';
      case 'announcement': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (hours < 1) return 'Just now';
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-black/90 backdrop-blur-sm border-b border-gray-800">
        <div className="max-w-6xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h1 className="text-xl font-bold">Community Feeds</h1>
              <Badge variant="outline" className="text-green-400 border-green-400">
                Free to Watch
              </Badge>

              {/* Live Stream Button */}
              <Button
                onClick={onGoToLiveStream}
                className="bg-red-500 hover:bg-red-600 text-white animate-pulse"
              >
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-white rounded-full" />
                  Watch Live Stream
                </div>
              </Button>
            </div>
            
            <div className="flex items-center gap-3">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search posts..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 w-64 bg-gray-900 border-gray-700"
                />
              </div>

              {/* Sort */}
              <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
                <SelectTrigger className="w-32 bg-gray-900 border-gray-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="recent">Recent</SelectItem>
                  <SelectItem value="popular">Popular</SelectItem>
                  <SelectItem value="trending">Trending</SelectItem>
                </SelectContent>
              </Select>

              {/* Upload Button */}
              <Button 
                onClick={() => setShowUploadModal(true)}
                className="bg-primary hover:bg-primary/90"
              >
                <Plus className="w-4 h-4 mr-2" />
                Upload
              </Button>
            </div>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={(value: any) => setActiveTab(value)} className="mt-4">
            <TabsList className="bg-gray-900">
              <TabsTrigger value="all" className="flex items-center gap-2">
                <Video className="w-4 h-4" />
                All
              </TabsTrigger>
              <TabsTrigger value="fun" className="flex items-center gap-2">
                <Zap className="w-4 h-4" />
                Fun
              </TabsTrigger>
              <TabsTrigger value="ad" className="flex items-center gap-2">
                <Gift className="w-4 h-4" />
                Ads
              </TabsTrigger>
              <TabsTrigger value="announcement" className="flex items-center gap-2">
                <Megaphone className="w-4 h-4" />
                Announcements
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {/* Live Stream Promotion Banner */}
      <div className="max-w-6xl mx-auto px-4 pt-4">
        <Card className="bg-gradient-to-r from-red-500/20 to-pink-500/20 border-red-500/30 mb-6">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                <div>
                  <h3 className="font-semibold text-red-400">🔴 Live Competition Happening Now!</h3>
                  <p className="text-sm text-gray-300">Join <span className="font-medium text-white">8,234 viewers</span> watching the Big Brother house live</p>
                </div>
              </div>
              <Button
                onClick={onGoToLiveStream}
                className="bg-red-500 hover:bg-red-600"
              >
                Watch Live
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 py-2">
        {filteredPosts.length === 0 ? (
          <div className="text-center py-12">
            <Video className="w-16 h-16 mx-auto mb-4 text-gray-600" />
            <h3 className="text-lg font-medium mb-2">No posts found</h3>
            <p className="text-gray-400 mb-6">Be the first to share something!</p>
            <Button onClick={() => setShowUploadModal(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Post
            </Button>
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredPosts.map((post) => (
              <Card key={post.id} className="bg-gray-900 border-gray-700 overflow-hidden">
                <div className="relative">
                  {/* Video Player */}
                  <div className="relative aspect-video">
                    <VideoPlayer
                      title={post.title}
                      duration={post.duration}
                      isPlaying={playingVideoId === post.id}
                      isMuted={mutedVideos.has(post.id)}
                      onPlay={() => setPlayingVideoId(post.id)}
                      onPause={() => setPlayingVideoId(null)}
                      onToggleMute={() => {
                        setMutedVideos(prev => {
                          const newSet = new Set(prev);
                          if (newSet.has(post.id)) {
                            newSet.delete(post.id);
                          } else {
                            newSet.add(post.id);
                          }
                          return newSet;
                        });
                      }}
                      onLike={() => handleLike(post.id)}
                      onComment={() => handleComment(post.id)}
                      onShare={() => handleShare(post)}
                      onReport={() => {}}
                      likes={post.likes}
                      comments={post.comments}
                      views={post.views}
                      isLiked={post.isLiked}
                      className="w-full h-full"
                    />

                    {/* Type Badge */}
                    <Badge
                      className={`absolute top-2 left-2 text-white ${getTypeColor(post.type)} z-10`}
                    >
                      {getTypeIcon(post.type)}
                      <span className="ml-1 capitalize">{post.type}</span>
                    </Badge>

                    {/* Verified Badge */}
                    {post.author.verified && (
                      <Badge variant="secondary" className="absolute top-2 right-2 bg-blue-500 z-10">
                        ✓
                      </Badge>
                    )}
                  </div>
                </div>

                <CardContent className="p-4">
                  {/* Author */}
                  <div className="flex items-center gap-2 mb-3">
                    <button
                      onClick={() => handleProfileClick(post.author.name)}
                      className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center hover:scale-105 transition-transform"
                    >
                      <User className="w-4 h-4" />
                    </button>
                    <div>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleProfileClick(post.author.name)}
                          className="font-medium text-sm hover:text-primary transition-colors cursor-pointer"
                        >
                          {post.author.name}
                        </button>
                        {post.author.verified && (
                          <Badge variant="outline" className="text-xs px-1 py-0 border-blue-500 text-blue-400">
                            ✓
                          </Badge>
                        )}
                      </div>
                      <div className="text-xs text-gray-400">{formatTime(post.createdAt)}</div>
                    </div>
                  </div>

                  {/* Content */}
                  <h3 className="font-medium mb-2 line-clamp-2">{post.title}</h3>
                  <p className="text-sm text-gray-400 mb-3 line-clamp-2">{post.description}</p>

                  {/* Tags */}
                  {post.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-3">
                      {post.tags.slice(0, 3).map((tag, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          #{tag}
                        </Badge>
                      ))}
                      {post.tags.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{post.tags.length - 3}
                        </Badge>
                      )}
                    </div>
                  )}

                  {/* Stats */}
                  <div className="flex items-center justify-between text-sm text-gray-400 mb-3">
                    <div className="flex items-center gap-4">
                      <span className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        {formatNumber(post.views)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {post.duration}s
                      </span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleLike(post.id)}
                        className={`p-1 ${post.isLiked ? 'text-red-500' : 'text-gray-400'}`}
                      >
                        <Heart className="w-4 h-4" fill={post.isLiked ? 'currentColor' : 'none'} />
                        <span className="ml-1 text-xs">{formatNumber(post.likes)}</span>
                      </Button>

                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleComment(post.id)}
                        className="p-1 text-gray-400"
                      >
                        <MessageCircle className="w-4 h-4" />
                        <span className="ml-1 text-xs">{formatNumber(post.comments)}</span>
                      </Button>

                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleShare(post)}
                        className="p-1 text-gray-400"
                      >
                        <Share className="w-4 h-4" />
                        <span className="ml-1 text-xs">{formatNumber(post.shares)}</span>
                      </Button>
                    </div>

                    <Button variant="ghost" size="sm" className="p-1 text-gray-400">
                      <Flag className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <Card className="w-full max-w-lg bg-gray-900 border-gray-700 text-white">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Upload New Video</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowUploadModal(false)}
                  disabled={isUploading}
                >
                  <X className="w-4 h-4" />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {!user?.isAuth ? (
                <div className="text-center py-6">
                  <Video className="w-12 h-12 mx-auto mb-3 text-gray-600" />
                  <h3 className="font-medium mb-2">Sign up to upload</h3>
                  <p className="text-gray-400 mb-4">Join our community to share your videos!</p>
                  <Button onClick={onAuthRequired} className="w-full">
                    Sign Up / Login
                  </Button>
                </div>
              ) : (
                <>
                  {/* Video Upload */}
                  <div>
                    <Label>Video (Max 30 seconds)</Label>
                    <div 
                      className="border-2 border-dashed border-gray-600 rounded-lg p-6 text-center cursor-pointer hover:border-gray-500 transition-colors"
                      onClick={() => videoInputRef.current?.click()}
                    >
                      <Camera className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                      <p className="text-sm text-gray-400">
                        {uploadForm.video ? uploadForm.video.name : 'Click to select video file'}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">MP4, WebM up to 50MB</p>
                    </div>
                    <input
                      ref={videoInputRef}
                      type="file"
                      accept="video/*"
                      onChange={handleVideoUpload}
                      className="hidden"
                    />
                  </div>

                  {/* Type */}
                  <div>
                    <Label>Content Type</Label>
                    <Select 
                      value={uploadForm.type} 
                      onValueChange={(value: any) => setUploadForm(prev => ({ ...prev, type: value }))}
                    >
                      <SelectTrigger className="bg-gray-800 border-gray-600">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="fun">Fun Content</SelectItem>
                        <SelectItem value="ad">Advertisement</SelectItem>
                        <SelectItem value="announcement">Announcement</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Title */}
                  <div>
                    <Label>Title *</Label>
                    <Input
                      value={uploadForm.title}
                      onChange={(e) => setUploadForm(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Enter video title..."
                      className="bg-gray-800 border-gray-600"
                      maxLength={100}
                    />
                  </div>

                  {/* Description */}
                  <div>
                    <Label>Description</Label>
                    <Textarea
                      value={uploadForm.description}
                      onChange={(e) => setUploadForm(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Describe your video..."
                      className="bg-gray-800 border-gray-600"
                      maxLength={300}
                    />
                  </div>

                  {/* Tags */}
                  <div>
                    <Label>Tags (comma separated)</Label>
                    <Input
                      value={uploadForm.tags}
                      onChange={(e) => setUploadForm(prev => ({ ...prev, tags: e.target.value }))}
                      placeholder="fun, biggerbro, reaction..."
                      className="bg-gray-800 border-gray-600"
                    />
                  </div>

                  {/* Upload Progress */}
                  {isUploading && (
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm">Uploading...</span>
                        <span className="text-sm">{uploadProgress}%</span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div 
                          className="bg-primary h-2 rounded-full transition-all duration-300"
                          style={{ width: `${uploadProgress}%` }}
                        />
                      </div>
                    </div>
                  )}

                  {/* Submit */}
                  <Button 
                    onClick={handleUploadSubmit}
                    disabled={isUploading || !uploadForm.video || !uploadForm.title.trim()}
                    className="w-full"
                  >
                    {isUploading ? 'Uploading...' : 'Upload Video'}
                  </Button>
                </>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* Comments Modal */}
      {commentsOpen && (
        <FeedComments
          postId={commentsOpen}
          user={user}
          onAuthRequired={onAuthRequired}
          isOpen={!!commentsOpen}
          onClose={() => setCommentsOpen(null)}
        />
      )}

      {/* User Profile Modal */}
      {showUserProfile && (
        <div className="fixed inset-0 z-50">
          <UserProfile
            onBack={() => setShowUserProfile(false)}
          />
        </div>
      )}

      {/* Notifications */}
      <NotificationToast
        notifications={notifications}
        onRemove={removeNotification}
      />
    </div>
  );
}
