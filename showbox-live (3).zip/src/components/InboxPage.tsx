import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Search, MessageCircle, Bell, Heart, UserPlus, Award,
  Crown, Video, Clock, CheckCircle, X, MoreHorizontal,
  Reply, Forward, Archive, Trash2
} from 'lucide-react';

interface Message {
  id: string;
  type: 'message' | 'notification' | 'request';
  sender: {
    name: string;
    avatar?: string;
    verified?: boolean;
    isVIP?: boolean;
  };
  content: string;
  timestamp: Date;
  read: boolean;
  category?: 'like' | 'follow' | 'comment' | 'mention' | 'system' | 'live' | 'request';
}

const mockMessages: Message[] = [
  {
    id: '1',
    type: 'message',
    sender: { name: 'Teez', verified: true, isVIP: true },
    content: 'Hey! Thanks for following my journey in the house! 🏠',
    timestamp: new Date(Date.now() - 300000),
    read: false
  },
  {
    id: '2',
    type: 'message',
    sender: { name: 'Sarah_Lagos', verified: false },
    content: 'Your latest video was amazing! Can you do a tutorial? 😍',
    timestamp: new Date(Date.now() - 900000),
    read: false
  },
  {
    id: '3',
    type: 'notification',
    sender: { name: 'BigBrother_Official', verified: true },
    content: 'You have been selected for tomorrow\'s HOH challenge! 🏆',
    timestamp: new Date(Date.now() - 1800000),
    read: true,
    category: 'system'
  },
  {
    id: '4',
    type: 'notification',
    sender: { name: 'MR.SURE', verified: false },
    content: 'liked your video "Morning routine in the house"',
    timestamp: new Date(Date.now() - 3600000),
    read: true,
    category: 'like'
  },
  {
    id: '5',
    type: 'notification',
    sender: { name: 'ENOGIE', verified: false },
    content: 'started following you',
    timestamp: new Date(Date.now() - 7200000),
    read: true,
    category: 'follow'
  },
  {
    id: '6',
    type: 'request',
    sender: { name: 'Viewer_123', verified: false },
    content: 'wants to join your live stream',
    timestamp: new Date(Date.now() - 10800000),
    read: false,
    category: 'request'
  }
];

export function InboxPage() {
  const [activeTab, setActiveTab] = useState<'all' | 'messages' | 'notifications' | 'requests'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMessage, setSelectedMessage] = useState<string | null>(null);

  const filteredMessages = mockMessages.filter(message => {
    const matchesTab = activeTab === 'all' || 
      (activeTab === 'messages' && message.type === 'message') ||
      (activeTab === 'notifications' && message.type === 'notification') ||
      (activeTab === 'requests' && message.type === 'request');
    
    const matchesSearch = searchTerm === '' || 
      message.sender.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      message.content.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesTab && matchesSearch;
  });

  const unreadCount = mockMessages.filter(m => !m.read).length;

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'now';
    if (minutes < 60) return `${minutes}m`;
    if (hours < 24) return `${hours}h`;
    return `${days}d`;
  };

  const getCategoryIcon = (category?: string) => {
    switch (category) {
      case 'like': return <Heart className="w-4 h-4 text-red-400" />;
      case 'follow': return <UserPlus className="w-4 h-4 text-blue-400" />;
      case 'comment': return <MessageCircle className="w-4 h-4 text-green-400" />;
      case 'system': return <Crown className="w-4 h-4 text-yellow-400" />;
      case 'live': return <Video className="w-4 h-4 text-red-500" />;
      case 'request': return <Bell className="w-4 h-4 text-purple-400" />;
      default: return <MessageCircle className="w-4 h-4 text-gray-400" />;
    }
  };

  const getTabCount = (tab: string) => {
    switch (tab) {
      case 'messages': return mockMessages.filter(m => m.type === 'message').length;
      case 'notifications': return mockMessages.filter(m => m.type === 'notification').length;
      case 'requests': return mockMessages.filter(m => m.type === 'request').length;
      default: return mockMessages.length;
    }
  };

  const markAsRead = (messageId: string) => {
    // Implementation would update the message read status
    console.log('Mark as read:', messageId);
  };

  const handleMessageAction = (action: string, messageId: string) => {
    console.log(`Action ${action} on message ${messageId}`);
  };

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-black/90 backdrop-blur-sm border-b border-gray-800">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <h1 className="text-xl font-bold">Inbox</h1>
              {unreadCount > 0 && (
                <Badge className="bg-red-500 text-white">
                  {unreadCount} new
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm">
                <Archive className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="sm">
                <MoreHorizontal className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Search messages..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-gray-900 border-gray-700"
            />
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="px-4 py-2 border-b border-gray-800">
        <Tabs value={activeTab} onValueChange={(value: any) => setActiveTab(value)}>
          <TabsList className="bg-gray-900 w-full">
            <TabsTrigger value="all" className="flex items-center gap-2 flex-1">
              All
              <Badge variant="outline" className="text-xs">
                {getTabCount('all')}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="messages" className="flex items-center gap-2 flex-1">
              <MessageCircle className="w-4 h-4" />
              Messages
              <Badge variant="outline" className="text-xs">
                {getTabCount('messages')}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="notifications" className="flex items-center gap-2 flex-1">
              <Bell className="w-4 h-4" />
              Activity
              <Badge variant="outline" className="text-xs">
                {getTabCount('notifications')}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="requests" className="flex items-center gap-2 flex-1">
              <UserPlus className="w-4 h-4" />
              Requests
              <Badge variant="outline" className="text-xs">
                {getTabCount('requests')}
              </Badge>
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Messages List */}
      <ScrollArea className="flex-1">
        <div className="space-y-2 p-4">
          {filteredMessages.length === 0 ? (
            <div className="text-center py-12">
              <MessageCircle className="w-16 h-16 mx-auto mb-4 text-gray-600" />
              <h3 className="text-lg font-medium mb-2">No messages found</h3>
              <p className="text-gray-400">Your inbox is empty or no matches for your search.</p>
            </div>
          ) : (
            filteredMessages.map((message) => (
              <Card 
                key={message.id} 
                className={`
                  cursor-pointer transition-all hover:bg-gray-800/50
                  ${!message.read ? 'bg-gray-900 border-blue-500/30' : 'bg-gray-900/50 border-gray-700'}
                  ${selectedMessage === message.id ? 'ring-2 ring-blue-500' : ''}
                `}
                onClick={() => {
                  setSelectedMessage(message.id);
                  if (!message.read) markAsRead(message.id);
                }}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    {/* Avatar */}
                    <div className="relative flex-shrink-0">
                      <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center">
                        <span className="font-bold text-lg">
                          {message.sender.name.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      {message.sender.isVIP && (
                        <Crown className="absolute -bottom-1 -right-1 w-4 h-4 text-yellow-400" />
                      )}
                      {message.category && (
                        <div className="absolute -top-1 -right-1 bg-black rounded-full p-1">
                          {getCategoryIcon(message.category)}
                        </div>
                      )}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium truncate">
                            {message.sender.name}
                          </span>
                          {message.sender.verified && (
                            <CheckCircle className="w-4 h-4 text-blue-400" />
                          )}
                          <Badge 
                            variant="outline" 
                            className={`text-xs ${
                              message.type === 'message' ? 'border-green-500 text-green-400' :
                              message.type === 'notification' ? 'border-blue-500 text-blue-400' :
                              'border-purple-500 text-purple-400'
                            }`}
                          >
                            {message.type}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-gray-400">
                          <span>{formatTime(message.timestamp)}</span>
                          {!message.read && (
                            <div className="w-2 h-2 bg-blue-500 rounded-full" />
                          )}
                        </div>
                      </div>

                      <p className="text-sm text-gray-300 line-clamp-2 mb-2">
                        {message.content}
                      </p>

                      {/* Actions */}
                      {selectedMessage === message.id && (
                        <div className="flex items-center gap-2 mt-3">
                          {message.type === 'message' && (
                            <>
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleMessageAction('reply', message.id);
                                }}
                              >
                                <Reply className="w-3 h-3 mr-1" />
                                Reply
                              </Button>
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleMessageAction('forward', message.id);
                                }}
                              >
                                <Forward className="w-3 h-3 mr-1" />
                                Forward
                              </Button>
                            </>
                          )}
                          {message.type === 'request' && (
                            <>
                              <Button 
                                size="sm" 
                                className="bg-green-600 hover:bg-green-700"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleMessageAction('accept', message.id);
                                }}
                              >
                                <CheckCircle className="w-3 h-3 mr-1" />
                                Accept
                              </Button>
                              <Button 
                                size="sm" 
                                variant="destructive"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleMessageAction('decline', message.id);
                                }}
                              >
                                <X className="w-3 h-3 mr-1" />
                                Decline
                              </Button>
                            </>
                          )}
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleMessageAction('delete', message.id);
                            }}
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
