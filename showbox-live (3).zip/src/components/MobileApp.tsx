import { useState } from 'react';
import { BottomNavigation } from './BottomNavigation';
import { FacebookStyleFeed } from './FacebookStyleFeed';
import { InboxPage } from './InboxPage';
import { UploadPage } from './UploadPage';
import { UserProfile } from './UserProfile';
import { AuthModal } from './streaming/AuthModal';
import { AdminThemeProvider } from './streaming/AdminThemeProvider';
import { LocalStreamProvider } from './streaming/LocalStreamProvider';
import { StreamingErrorHandler } from './streaming/StreamingErrorHandler';

export function MobileApp() {
  const [activeTab, setActiveTab] = useState<'feed' | 'inbox' | 'upload' | 'profile'>('feed');
  const [user, setUser] = useState<{ name: string; isAuth: boolean } | null>(null);
  const [showAuth, setShowAuth] = useState(false);
  const [showLiveStream, setShowLiveStream] = useState(false);

  const handleAuthRequired = () => {
    setShowAuth(true);
  };

  const handleGoToLiveStream = () => {
    setShowLiveStream(true);
  };

  const handleUploadComplete = (post: any) => {
    console.log('Upload completed:', post);
    // Switch back to feeds to show the new post
    setActiveTab('feed');
  };

  const renderCurrentPage = () => {
    switch (activeTab) {
      case 'feed':
        return (
          <FacebookStyleFeed
            user={user}
            onAuthRequired={handleAuthRequired}
            onGoToLiveStream={handleGoToLiveStream}
          />
        );
      case 'inbox':
        return <InboxPage />;
      case 'upload':
        return (
          <UploadPage
            user={user}
            onAuthRequired={handleAuthRequired}
            onUploadComplete={handleUploadComplete}
          />
        );
      case 'profile':
        return (
          <UserProfile
            onBack={() => setActiveTab('feed')}
            user={{
              id: '1',
              username: user?.name ? `@${user.name.toLowerCase().replace(/\s+/g, '_')}` : '@guest',
              displayName: user?.name || 'Guest User',
              bio: '🎭 Big Brother Fan | 🎵 Content Creator | ✨ Living my best life!',
              avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
              isVerified: false,
              isVIP: user?.isAuth || false,
              followers: 1200,
              following: 450,
              likes: 15600,
              posts: 23,
              joinDate: 'January 2024',
              location: 'Nigeria',
              website: 'myprofile.com',
              isFollowing: false,
              isOwnProfile: true
            }}
          />
        );
      default:
        return <FacebookStyleFeed user={user} onAuthRequired={handleAuthRequired} onGoToLiveStream={handleGoToLiveStream} />;
    }
  };

  // Show live stream if activated
  if (showLiveStream) {
    return (
      <AdminThemeProvider>
        <LocalStreamProvider>
          <StreamingErrorHandler>
            <div className="min-h-screen bg-black text-white relative overflow-hidden">
              {/* Live Stream Interface would go here */}
              <div className="flex items-center justify-center h-screen">
                <div className="text-center">
                  <h2 className="text-2xl font-bold mb-4">🔴 Live Stream Mode</h2>
                  <p className="text-gray-400 mb-6">Live streaming interface would be rendered here</p>
                  <button
                    onClick={() => setShowLiveStream(false)}
                    className="bg-red-500 hover:bg-red-600 px-6 py-3 rounded-lg font-medium"
                  >
                    ← Back to Feeds
                  </button>
                </div>
              </div>
            </div>
          </StreamingErrorHandler>
        </LocalStreamProvider>
      </AdminThemeProvider>
    );
  }

  return (
    <AdminThemeProvider>
      <div className="min-h-screen bg-black text-white">
        {/* Main Content */}
        <div className="pb-20">
          {renderCurrentPage()}
        </div>

        {/* Bottom Navigation */}
        <BottomNavigation
          activeTab={activeTab}
          onTabChange={setActiveTab}
          notificationCounts={{
            inbox: 17,
            friends: 99
          }}
        />

        {/* Auth Modal */}
        <AuthModal
          isOpen={showAuth}
          onClose={() => setShowAuth(false)}
          onAuth={(userData) => {
            setUser(userData);
            setShowAuth(false);
          }}
        />
      </div>
    </AdminThemeProvider>
  );
}
