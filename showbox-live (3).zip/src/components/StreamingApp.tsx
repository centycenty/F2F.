import { useState, useEffect } from "react";
import { Heart, MessageCircle, Users, Settings, Vote, Crown, Wifi, WifiOff, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FloatingInteractions } from "./streaming/FloatingInteractions";
import { StreamGrid } from "./streaming/StreamGrid";
import { FeedsPage } from "./FeedsPage";
import { LocalStreamProvider } from "./streaming/LocalStreamProvider";
import { LocalStreamGrid } from "./streaming/LocalStreamGrid";
import { LocalStreamControls } from "./streaming/LocalStreamControls";
import { StreamingErrorHandler } from "./streaming/StreamingErrorHandler";
import { ModeratorPanel } from "./streaming/ModeratorPanel";
import { VotingModal } from "./streaming/VotingModal";
import { CommentsSection } from "./streaming/CommentsSection";
import { AuthModal } from "./streaming/AuthModal";
import { EnhancedAdminModal } from "./streaming/EnhancedAdminModal";
import { LiveStreamRequestModal } from "./streaming/LiveStreamRequestModal";
import { AdminThemeProvider } from "./streaming/AdminThemeProvider";
import { useRoomConnection } from "@/hooks/useRoomConnection";

export function StreamingApp() {
  const [isLive, setIsLive] = useState(true);
  const [likes, setLikes] = useState(12450);
  const [viewers, setViewers] = useState(8234);
  const [showVoting, setShowVoting] = useState(false);
  const [showModerator, setShowModerator] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [showAdmin, setShowAdmin] = useState(false);
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [user, setUser] = useState<{ name: string; isAuth: boolean } | null>(null);
  const [streamRequests, setStreamRequests] = useState<any[]>([]);
  const [floatingHearts, setFloatingHearts] = useState<Array<{ id: number; x: number; y: number }>>([]);
  const [floatingComments, setFloatingComments] = useState<Array<{ id: number; user: string; message: string; x: number; y: number }>>([]);
  const [useLiveStream, setUseLiveStream] = useState(false);

  const handleLike = () => {
    if (!user?.isAuth) {
      setShowAuth(true);
      return;
    }
    
    setLikes(prev => prev + 1);
    
    // Add floating heart
    const heartId = Date.now();
    const x = Math.random() * 200 + 50;
    const y = Math.random() * 100 + 50;
    
    setFloatingHearts(prev => [...prev, { id: heartId, x, y }]);
    
    // Remove heart after animation
    setTimeout(() => {
      setFloatingHearts(prev => prev.filter(heart => heart.id !== heartId));
    }, 3000);
  };

  const handleComment = () => {
    if (!user?.isAuth) {
      setShowAuth(true);
      return;
    }
  };

  const handleRequestSubmitted = (request: any) => {
    setStreamRequests(prev => [...prev, request]);
    console.log('Stream request submitted:', request);
  };

  const handleRequestClick = () => {
    setShowRequestModal(true);
  };

  const handleNewComment = (comment: { id: number; user: string; message: string }) => {
    // Add floating comment with random position
    const x = Math.random() * 30 + 10; // 10-40% from left
    const y = Math.random() * 60 + 20; // 20-80% from top

    const floatingComment = {
      ...comment,
      x,
      y
    };

    setFloatingComments(prev => [...prev, floatingComment]);

    // Remove floating comment after animation
    setTimeout(() => {
      setFloatingComments(prev => prev.filter(fc => fc.id !== comment.id));
    }, 4000);
  };

  useEffect(() => {
    // Simulate viewer count changes
    const interval = setInterval(() => {
      setViewers(prev => prev + Math.floor(Math.random() * 20) - 10);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      // Only handle if no input is focused
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      switch (e.key) {
        case 'l':
        case 'L':
          // Toggle between feeds and live stream
          setUseLiveStream(prev => !prev);
          break;
        case 'Escape':
          // Go back to feeds if in live stream
          if (useLiveStream) {
            setUseLiveStream(false);
          }
          break;
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [useLiveStream]);

  const toggleLiveStream = async () => {
    setUseLiveStream(!useLiveStream);
  };

  const StreamContent = () => {
    if (useLiveStream) {
      return (
        <>
          <LocalStreamGrid
            user={user}
            onAuthRequired={() => setShowAuth(true)}
            onShowRequestModal={() => setShowRequestModal(true)}
          />
          <LocalStreamControls />
        </>
      );
    }
    return <FeedsPage
      user={user}
      onAuthRequired={() => setShowAuth(true)}
      onGoToLiveStream={() => setUseLiveStream(true)}
    />;
  };

  return (
    <AdminThemeProvider>
      <LocalStreamProvider>
      <StreamingErrorHandler>
        <div className="min-h-screen bg-black text-white relative overflow-hidden">
        {/* Main Stream Area */}
        <div className="relative h-screen">
          <StreamContent />
          
          {/* Live Indicator */}
          {isLive && useLiveStream && (
            <div className="absolute top-4 left-4 flex items-center gap-2 bg-red-500/90 px-4 py-2 rounded-full animate-pulse border border-red-400">
              <div className="w-3 h-3 bg-white rounded-full animate-pulse" />
              <span className="text-sm font-bold">🔴 LIVE COMPETITION</span>
            </div>
          )}

          {/* Feeds Mode Indicator */}
          {!useLiveStream && (
            <div className="absolute top-4 left-4 flex items-center gap-2 bg-blue-500/90 px-4 py-2 rounded-full border border-blue-400">
              <span className="text-sm font-bold">📱 Community Feeds</span>
            </div>
          )}

          {/* Navigation & Stream Toggle */}
          <div className="absolute top-4 right-4 flex items-center gap-3">
            {useLiveStream && (
              <Button
                variant="ghost"
                size="sm"
                className="bg-black/50 backdrop-blur-sm hover:bg-black/70"
                onClick={() => setUseLiveStream(false)}
              >
                ← Back to Feeds
              </Button>
            )}

            <StreamToggleButton
              useLiveStream={useLiveStream}
              toggleLiveStream={toggleLiveStream}
              user={user}
              onAuthRequired={() => setShowAuth(true)}
            />
            <div className="flex items-center gap-2 bg-black/50 px-3 py-1 rounded-full backdrop-blur-sm">
              <Users className="w-4 h-4" />
              <span className="text-sm font-medium">{viewers.toLocaleString()}</span>
            </div>
          </div>

          {/* Live Stream Interactive Elements - Only show when streaming */}
          {useLiveStream && (
            <>
              {/* Floating Interactions */}
              <FloatingInteractions hearts={floatingHearts} comments={floatingComments} />

              {/* Bottom Controls */}
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <div className="flex items-end justify-between">
                  {/* Comments Section */}
                  <div className="flex-1 max-w-md">
                    <CommentsSection
                      user={user}
                      onAuthRequired={() => setShowAuth(true)}
                      onNewComment={handleNewComment}
                    />
                  </div>

                  {/* Action Buttons */}
                <div className="flex flex-col gap-3 ml-4 relative z-50">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm hover:bg-white/20"
                      onClick={handleLike}
                    >
                      <Heart className="w-6 h-6" fill="currentColor" />
                    </Button>
                    <span className="text-xs text-center">{likes.toLocaleString()}</span>

                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm hover:bg-white/20"
                      onClick={handleComment}
                    >
                      <MessageCircle className="w-6 h-6" />
                    </Button>

                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-12 h-12 rounded-full bg-blue-500/80 backdrop-blur-sm hover:bg-blue-500 border-2 border-blue-300"
                      onClick={handleRequestClick}
                      title="Request to join competition"
                    >
                      <UserPlus className="w-6 h-6" />
                    </Button>

                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm hover:bg-white/20"
                      onClick={() => setShowVoting(true)}
                    >
                      <Vote className="w-6 h-6" />
                    </Button>

                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-12 h-12 rounded-full bg-yellow-500/80 backdrop-blur-sm hover:bg-yellow-500 border-2 border-yellow-300 cursor-pointer"
                      style={{ pointerEvents: 'auto' }}
                      onClick={() => {
                        console.log("Crown button clicked!");
                        setShowModerator(true);
                      }}
                    >
                      <Crown className="w-6 h-6" />
                    </Button>

                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-12 h-12 rounded-full bg-red-500/80 backdrop-blur-sm hover:bg-red-500 border-2 border-red-300"
                      onClick={() => setShowAdmin(true)}
                    >
                      <Settings className="w-6 h-6" />
                    </Button>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Modals */}
        <VotingModal 
          isOpen={showVoting} 
          onClose={() => setShowVoting(false)}
          userAuth={user?.isAuth || false}
          onAuthRequired={() => setShowAuth(true)}
        />
        
        <ModeratorPanel 
          isOpen={showModerator} 
          onClose={() => setShowModerator(false)} 
        />
        
        <AuthModal
          isOpen={showAuth}
          onClose={() => setShowAuth(false)}
          onAuth={(userData) => setUser(userData)}
        />

        <EnhancedAdminModal
          isOpen={showAdmin}
          onClose={() => setShowAdmin(false)}
        />

        <LiveStreamRequestModal
          isOpen={showRequestModal}
          onClose={() => setShowRequestModal(false)}
          user={user}
          onAuthRequired={() => setShowAuth(true)}
          onRequestSubmitted={handleRequestSubmitted}
        />
        </div>
      </StreamingErrorHandler>
      </LocalStreamProvider>
    </AdminThemeProvider>
  );
}

// Separate component for stream toggle to handle authentication
function StreamToggleButton({ 
  useLiveStream, 
  toggleLiveStream, 
  user, 
  onAuthRequired 
}: {
  useLiveStream: boolean;
  toggleLiveStream: () => void;
  user: { name: string; isAuth: boolean } | null;
  onAuthRequired: () => void;
}) {
  const { connectToRoom, disconnectFromRoom, isConnected, isConnecting } = useRoomConnection();

  const handleToggle = async () => {
    if (!useLiveStream) {
      // Switching to live stream mode
      if (!user?.isAuth) {
        onAuthRequired();
        return;
      }
      toggleLiveStream();
      await connectToRoom('bigbrother-house', user.name);
    } else {
      // Switching back to feeds
      disconnectFromRoom();
      toggleLiveStream();
    }
  };

  return (
    <Button
      variant="ghost"
      size="sm"
      className="bg-black/50 backdrop-blur-sm hover:bg-black/70"
      onClick={handleToggle}
      disabled={isConnecting}
    >
      {useLiveStream ? (
        <Wifi className="w-4 h-4 mr-2" />
      ) : (
        <WifiOff className="w-4 h-4 mr-2" />
      )}
      {isConnecting ? 'Connecting...' : useLiveStream ? 'Exit Live Stream' : 'Join Live Stream'}
    </Button>
  );
}
