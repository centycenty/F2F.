import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { 
  Upload, Video, Image, Mic, Camera, X, Play, Pause,
  Volume2, VolumeX, RotateCcw, Crop, Filter, Zap,
  Gift, Megaphone, Clock, CheckCircle, AlertTriangle
} from 'lucide-react';

interface UploadPageProps {
  user?: { name: string; isAuth: boolean } | null;
  onAuthRequired?: () => void;
  onUploadComplete?: (post: any) => void;
}

export function UploadPage({ user, onAuthRequired, onUploadComplete }: UploadPageProps) {
  const [uploadType, setUploadType] = useState<'video' | 'photo' | 'audio'>('video');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'fun' as 'fun' | 'ad' | 'announcement',
    tags: '',
    privacy: 'public' as 'public' | 'friends' | 'private'
  });

  // Video player state
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    const isVideo = file.type.startsWith('video/');
    const isImage = file.type.startsWith('image/');
    const isAudio = file.type.startsWith('audio/');

    if (!isVideo && !isImage && !isAudio) {
      alert('Please select a valid media file');
      return;
    }

    // Set upload type based on file
    if (isVideo) setUploadType('video');
    else if (isImage) setUploadType('photo');
    else if (isAudio) setUploadType('audio');

    // Validate file size (50MB max)
    if (file.size > 50 * 1024 * 1024) {
      alert('File size must be less than 50MB');
      return;
    }

    // For video, check duration
    if (isVideo) {
      const video = document.createElement('video');
      video.preload = 'metadata';
      video.onloadedmetadata = () => {
        if (video.duration > 30) {
          alert('Video must be 30 seconds or less');
          return;
        }
        setSelectedFile(file);
        setPreview(URL.createObjectURL(file));
      };
      video.src = URL.createObjectURL(file);
    } else {
      setSelectedFile(file);
      setPreview(URL.createObjectURL(file));
    }
  };

  const handleUpload = async () => {
    if (!user?.isAuth) {
      onAuthRequired?.();
      return;
    }

    if (!selectedFile || !formData.title.trim()) {
      alert('Please select a file and enter a title');
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsUploading(false);
          
          // Create new post
          const newPost = {
            id: Date.now().toString(),
            author: { name: user.name, verified: false },
            type: formData.category,
            title: formData.title,
            description: formData.description,
            duration: uploadType === 'video' ? 15 : 0,
            likes: 0,
            comments: 0,
            shares: 0,
            views: 0,
            createdAt: new Date(),
            tags: formData.tags.split(',').map(tag => tag.trim()).filter(Boolean),
            isLiked: false,
            privacy: formData.privacy
          };

          onUploadComplete?.(newPost);
          
          // Reset form
          setSelectedFile(null);
          setPreview(null);
          setFormData({
            title: '',
            description: '',
            category: 'fun',
            tags: '',
            privacy: 'public'
          });
          
          return 0;
        }
        return prev + Math.random() * 15;
      });
    }, 200);
  };

  const removeFile = () => {
    setSelectedFile(null);
    setPreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'fun': return <Zap className="w-4 h-4" />;
      case 'ad': return <Gift className="w-4 h-4" />;
      case 'announcement': return <Megaphone className="w-4 h-4" />;
      default: return <Video className="w-4 h-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'fun': return 'bg-blue-500';
      case 'ad': return 'bg-green-500';
      case 'announcement': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-black text-white pb-20">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-black/90 backdrop-blur-sm border-b border-gray-800">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold">Create Post</h1>
            <Badge variant="outline" className="text-blue-400 border-blue-400">
              Share Your Moment
            </Badge>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto p-4 space-y-6">
        {/* Upload Type Selector */}
        <Card className="bg-gray-900 border-gray-700">
          <CardHeader>
            <CardTitle className="text-lg">What would you like to share?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-3">
              <Button
                variant={uploadType === 'video' ? 'default' : 'outline'}
                onClick={() => setUploadType('video')}
                className="flex flex-col items-center gap-2 h-20"
              >
                <Video className="w-6 h-6" />
                <span className="text-sm">Video</span>
              </Button>
              <Button
                variant={uploadType === 'photo' ? 'default' : 'outline'}
                onClick={() => setUploadType('photo')}
                className="flex flex-col items-center gap-2 h-20"
              >
                <Image className="w-6 h-6" />
                <span className="text-sm">Photo</span>
              </Button>
              <Button
                variant={uploadType === 'audio' ? 'default' : 'outline'}
                onClick={() => setUploadType('audio')}
                className="flex flex-col items-center gap-2 h-20"
              >
                <Mic className="w-6 h-6" />
                <span className="text-sm">Audio</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* File Upload Area */}
        <Card className="bg-gray-900 border-gray-700">
          <CardContent className="p-6">
            {!selectedFile ? (
              <div className="border-2 border-dashed border-gray-600 rounded-lg p-8 text-center hover:border-gray-500 transition-colors">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept={
                    uploadType === 'video' ? 'video/*' :
                    uploadType === 'photo' ? 'image/*' :
                    'audio/*'
                  }
                  onChange={handleFileSelect}
                  className="hidden"
                />
                <div className="flex flex-col items-center gap-4">
                  <div className="w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center">
                    {uploadType === 'video' && <Video className="w-8 h-8 text-blue-400" />}
                    {uploadType === 'photo' && <Image className="w-8 h-8 text-green-400" />}
                    {uploadType === 'audio' && <Mic className="w-8 h-8 text-purple-400" />}
                  </div>
                  <div>
                    <h3 className="text-lg font-medium mb-2">
                      Upload your {uploadType}
                    </h3>
                    <p className="text-gray-400 mb-4">
                      {uploadType === 'video' && 'Max 30 seconds, up to 50MB'}
                      {uploadType === 'photo' && 'JPG, PNG, or GIF up to 50MB'}
                      {uploadType === 'audio' && 'MP3, WAV up to 50MB'}
                    </p>
                  </div>
                  <Button onClick={() => fileInputRef.current?.click()} className="bg-primary hover:bg-primary/90">
                    <Upload className="w-4 h-4 mr-2" />
                    Choose File
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Preview */}
                <div className="relative rounded-lg overflow-hidden bg-gray-800">
                  {uploadType === 'video' && preview && (
                    <div className="relative aspect-video">
                      <video
                        ref={videoRef}
                        src={preview}
                        className="w-full h-full object-cover"
                        muted={isMuted}
                        onClick={() => {
                          if (videoRef.current) {
                            if (isPlaying) {
                              videoRef.current.pause();
                            } else {
                              videoRef.current.play();
                            }
                            setIsPlaying(!isPlaying);
                          }
                        }}
                      />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Button
                          variant="ghost"
                          size="lg"
                          className="w-16 h-16 rounded-full bg-black/50 hover:bg-black/70"
                        >
                          {isPlaying ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8" />}
                        </Button>
                      </div>
                      <div className="absolute bottom-2 right-2 flex gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            setIsMuted(!isMuted);
                          }}
                          className="bg-black/50 hover:bg-black/70"
                        >
                          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                        </Button>
                      </div>
                    </div>
                  )}

                  {uploadType === 'photo' && preview && (
                    <div className="relative">
                      <img src={preview} alt="Preview" className="w-full max-h-96 object-cover" />
                      <div className="absolute bottom-2 right-2 flex gap-2">
                        <Button variant="ghost" size="sm" className="bg-black/50 hover:bg-black/70">
                          <Crop className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="bg-black/50 hover:bg-black/70">
                          <Filter className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  )}

                  {uploadType === 'audio' && preview && (
                    <div className="p-8 text-center">
                      <div className="w-16 h-16 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Mic className="w-8 h-8 text-purple-400" />
                      </div>
                      <h3 className="font-medium mb-2">{selectedFile?.name}</h3>
                      <p className="text-gray-400 text-sm">
                        {(selectedFile?.size ? selectedFile.size / 1024 / 1024 : 0).toFixed(1)} MB
                      </p>
                    </div>
                  )}

                  {/* Remove Button */}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={removeFile}
                    className="absolute top-2 right-2 bg-black/50 hover:bg-black/70"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>

                {/* File Info */}
                <div className="text-sm text-gray-400">
                  <span className="font-medium">{selectedFile?.name}</span> • 
                  <span className="ml-1">{(selectedFile?.size ? selectedFile.size / 1024 / 1024 : 0).toFixed(1)} MB</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Post Details Form */}
        {selectedFile && (
          <Card className="bg-gray-900 border-gray-700">
            <CardHeader>
              <CardTitle className="text-lg">Post Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Title */}
              <div>
                <Label htmlFor="title">Title *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Give your post a catchy title..."
                  className="bg-gray-800 border-gray-600"
                  maxLength={100}
                />
                <div className="text-xs text-gray-400 mt-1">{formData.title.length}/100</div>
              </div>

              {/* Description */}
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Tell your audience about this post..."
                  className="bg-gray-800 border-gray-600"
                  maxLength={300}
                />
                <div className="text-xs text-gray-400 mt-1">{formData.description.length}/300</div>
              </div>

              {/* Category */}
              <div>
                <Label>Category</Label>
                <Select 
                  value={formData.category} 
                  onValueChange={(value: any) => setFormData(prev => ({ ...prev, category: value }))}
                >
                  <SelectTrigger className="bg-gray-800 border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fun">
                      <div className="flex items-center gap-2">
                        <Zap className="w-4 h-4 text-blue-400" />
                        Fun Content
                      </div>
                    </SelectItem>
                    <SelectItem value="ad">
                      <div className="flex items-center gap-2">
                        <Gift className="w-4 h-4 text-green-400" />
                        Advertisement
                      </div>
                    </SelectItem>
                    <SelectItem value="announcement">
                      <div className="flex items-center gap-2">
                        <Megaphone className="w-4 h-4 text-orange-400" />
                        Announcement
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Privacy */}
              <div>
                <Label>Privacy</Label>
                <Select 
                  value={formData.privacy} 
                  onValueChange={(value: any) => setFormData(prev => ({ ...prev, privacy: value }))}
                >
                  <SelectTrigger className="bg-gray-800 border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="public">🌍 Public - Everyone can see</SelectItem>
                    <SelectItem value="friends">👥 Friends - Only followers</SelectItem>
                    <SelectItem value="private">🔒 Private - Only you</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Tags */}
              <div>
                <Label htmlFor="tags">Tags (comma separated)</Label>
                <Input
                  id="tags"
                  value={formData.tags}
                  onChange={(e) => setFormData(prev => ({ ...prev, tags: e.target.value }))}
                  placeholder="bigbrother, fun, reaction, house..."
                  className="bg-gray-800 border-gray-600"
                />
              </div>

              {/* Upload Progress */}
              {isUploading && (
                <div className="bg-gray-800 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Uploading...</span>
                    <span className="text-sm">{Math.round(uploadProgress)}%</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div 
                      className="bg-primary h-2 rounded-full transition-all duration-300"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                  <div className="flex items-center gap-2 mt-2 text-xs text-gray-400">
                    <Clock className="w-3 h-3" />
                    <span>Processing your {uploadType}...</span>
                  </div>
                </div>
              )}

              {/* Submit Button */}
              <Button
                onClick={handleUpload}
                disabled={isUploading || !selectedFile || !formData.title.trim()}
                className="w-full bg-primary hover:bg-primary/90"
                size="lg"
              >
                {isUploading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Uploading...
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4 mr-2" />
                    Share Post
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Tips Card */}
        <Card className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-blue-500/30">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-blue-500/20 rounded-full flex items-center justify-center flex-shrink-0">
                <CheckCircle className="w-4 h-4 text-blue-400" />
              </div>
              <div>
                <h3 className="font-medium text-blue-400 mb-2">Tips for Great Content</h3>
                <ul className="text-sm text-blue-200 space-y-1">
                  <li>• Keep videos under 30 seconds for maximum engagement</li>
                  <li>• Add relevant tags to help people discover your content</li>
                  <li>• Write engaging descriptions that tell a story</li>
                  <li>• Choose the right category for better reach</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
