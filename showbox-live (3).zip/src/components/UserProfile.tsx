import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ArrowLeft, Settings, Share, MoreHorizontal, Play, Heart, 
  MessageCircle, Bookmark, UserPlus, UserCheck, Crown, 
  Calendar, MapPin, Link, CheckCircle, Lock, Grid, 
  Video, TrendingUp, Award, Star
} from 'lucide-react';

interface UserProfileProps {
  onBack: () => void;
  user?: {
    id: string;
    username: string;
    displayName: string;
    bio: string;
    avatar: string;
    isVerified: boolean;
    isVIP: boolean;
    followers: number;
    following: number;
    likes: number;
    posts: number;
    joinDate: string;
    location?: string;
    website?: string;
    isFollowing: boolean;
    isOwnProfile: boolean;
  };
}

interface UserPost {
  id: string;
  thumbnail: string;
  duration: string;
  views: number;
  likes: number;
  isPrivate?: boolean;
  title: string;
  category: 'fun' | 'ad' | 'announcement';
}

const mockUser = {
  id: '1',
  username: '@teez_official',
  displayName: 'Teez',
  bio: '🎭 Big Brother Housemate | 🎵 Music Lover | ✨ Living my best life in the house!',
  avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
  isVerified: true,
  isVIP: true,
  followers: 45600,
  following: 1200,
  likes: 892000,
  posts: 156,
  joinDate: 'January 2024',
  location: 'Big Brother House',
  website: 'teezofficial.com',
  isFollowing: false,
  isOwnProfile: false
};

const mockPosts: UserPost[] = [
  {
    id: '1',
    thumbnail: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=300&h=400&fit=crop',
    duration: '0:15',
    views: 12400,
    likes: 890,
    title: 'Dancing in the house!',
    category: 'fun'
  },
  {
    id: '2',
    thumbnail: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=400&fit=crop',
    duration: '0:30',
    views: 8900,
    likes: 567,
    title: 'My morning routine',
    category: 'fun'
  },
  {
    id: '3',
    thumbnail: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=300&h=400&fit=crop',
    duration: '0:22',
    views: 15600,
    likes: 1200,
    title: 'Cooking challenge!',
    category: 'fun'
  },
  {
    id: '4',
    thumbnail: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=300&h=400&fit=crop',
    duration: '0:18',
    views: 7800,
    likes: 456,
    title: 'Diary room thoughts',
    category: 'announcement'
  },
  {
    id: '5',
    thumbnail: 'https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=300&h=400&fit=crop',
    duration: '0:25',
    views: 11200,
    likes: 789,
    title: 'House tour',
    category: 'fun'
  },
  {
    id: '6',
    thumbnail: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=300&h=400&fit=crop',
    duration: '0:12',
    views: 9500,
    likes: 623,
    title: 'Workout time!',
    category: 'fun'
  }
];

export function UserProfile({ onBack, user = mockUser }: UserProfileProps) {
  const [isFollowing, setIsFollowing] = useState(user.isFollowing);
  const [activeTab, setActiveTab] = useState('posts');

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const toggleFollow = () => {
    setIsFollowing(!isFollowing);
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'fun': return 'bg-blue-500';
      case 'ad': return 'bg-green-500';
      case 'announcement': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-black/90 backdrop-blur-sm border-b border-gray-800">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={onBack}
              className="p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="font-semibold">{user.displayName}</h1>
              <p className="text-sm text-gray-400">{user.username}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" className="p-2">
              <Share className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="sm" className="p-2">
              <MoreHorizontal className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Profile Section */}
      <div className="px-4 py-6">
        <div className="flex items-start gap-4 mb-6">
          {/* Avatar */}
          <div className="relative">
            <img
              src={user.avatar}
              alt={user.displayName}
              className="w-20 h-20 rounded-full object-cover border-2 border-gray-600"
            />
            {user.isVIP && (
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-yellow-500 rounded-full flex items-center justify-center">
                <Crown className="w-3 h-3 text-black" />
              </div>
            )}
          </div>

          {/* Stats */}
          <div className="flex-1">
            <div className="flex items-center gap-4 mb-4">
              <div className="text-center">
                <div className="font-bold text-lg">{formatNumber(user.posts)}</div>
                <div className="text-xs text-gray-400">Posts</div>
              </div>
              <div className="text-center">
                <div className="font-bold text-lg">{formatNumber(user.followers)}</div>
                <div className="text-xs text-gray-400">Followers</div>
              </div>
              <div className="text-center">
                <div className="font-bold text-lg">{formatNumber(user.following)}</div>
                <div className="text-xs text-gray-400">Following</div>
              </div>
              <div className="text-center">
                <div className="font-bold text-lg">{formatNumber(user.likes)}</div>
                <div className="text-xs text-gray-400">Likes</div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2">
              {user.isOwnProfile ? (
                <>
                  <Button variant="outline" className="flex-1 border-gray-600">
                    <Settings className="w-4 h-4 mr-2" />
                    Edit Profile
                  </Button>
                  <Button variant="outline" className="border-gray-600">
                    <Share className="w-4 h-4" />
                  </Button>
                </>
              ) : (
                <>
                  <Button
                    onClick={toggleFollow}
                    className={`flex-1 ${
                      isFollowing 
                        ? 'bg-gray-700 hover:bg-gray-600' 
                        : 'bg-primary hover:bg-primary/90'
                    }`}
                  >
                    {isFollowing ? (
                      <>
                        <UserCheck className="w-4 h-4 mr-2" />
                        Following
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4 mr-2" />
                        Follow
                      </>
                    )}
                  </Button>
                  <Button variant="outline" className="border-gray-600">
                    <MessageCircle className="w-4 h-4" />
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Profile Info */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <h2 className="font-semibold">{user.displayName}</h2>
            {user.isVerified && (
              <CheckCircle className="w-4 h-4 text-blue-400" />
            )}
            {user.isVIP && (
              <Badge className="bg-yellow-500 text-black text-xs">
                VIP
              </Badge>
            )}
          </div>

          <p className="text-gray-300 leading-relaxed">{user.bio}</p>

          <div className="flex flex-wrap gap-4 text-sm text-gray-400">
            {user.location && (
              <div className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                <span>{user.location}</span>
              </div>
            )}
            {user.website && (
              <div className="flex items-center gap-1">
                <Link className="w-4 h-4" />
                <span className="text-blue-400">{user.website}</span>
              </div>
            )}
            <div className="flex items-center gap-1">
              <Calendar className="w-4 h-4" />
              <span>Joined {user.joinDate}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-gray-900 mx-4">
          <TabsTrigger value="posts" className="flex items-center gap-2">
            <Grid className="w-4 h-4" />
            Posts
          </TabsTrigger>
          <TabsTrigger value="trending" className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Trending
          </TabsTrigger>
          <TabsTrigger value="liked" className="flex items-center gap-2">
            <Heart className="w-4 h-4" />
            Liked
          </TabsTrigger>
        </TabsList>

        {/* Posts Grid */}
        <TabsContent value="posts" className="px-4 pt-4">
          <div className="grid grid-cols-3 gap-1">
            {mockPosts.map((post) => (
              <div key={post.id} className="relative aspect-square group cursor-pointer">
                <img
                  src={post.thumbnail}
                  alt={post.title}
                  className="w-full h-full object-cover rounded-sm"
                />
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <Play className="w-8 h-8 text-white" />
                </div>

                {/* Duration */}
                <div className="absolute bottom-1 right-1 bg-black/70 text-white text-xs px-1 rounded">
                  {post.duration}
                </div>

                {/* Category indicator */}
                <div className={`absolute top-1 left-1 w-2 h-2 rounded-full ${getCategoryColor(post.category)}`} />

                {/* Stats overlay on hover */}
                <div className="absolute inset-0 bg-black/80 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-2">
                  <div className="flex items-center gap-2 text-xs text-white">
                    <div className="flex items-center gap-1">
                      <Play className="w-3 h-3" />
                      {formatNumber(post.views)}
                    </div>
                    <div className="flex items-center gap-1">
                      <Heart className="w-3 h-3" />
                      {formatNumber(post.likes)}
                    </div>
                  </div>
                </div>

                {post.isPrivate && (
                  <div className="absolute top-1 right-1">
                    <Lock className="w-3 h-3 text-gray-400" />
                  </div>
                )}
              </div>
            ))}
          </div>

          {mockPosts.length === 0 && (
            <div className="text-center py-12">
              <Video className="w-12 h-12 mx-auto mb-4 text-gray-600" />
              <h3 className="font-medium mb-2">No posts yet</h3>
              <p className="text-sm text-gray-400">When you post videos, they'll appear here.</p>
            </div>
          )}
        </TabsContent>

        {/* Trending Tab */}
        <TabsContent value="trending" className="px-4 pt-4">
          <div className="grid grid-cols-3 gap-1">
            {mockPosts.slice(0, 3).map((post) => (
              <div key={post.id} className="relative aspect-square group cursor-pointer">
                <img
                  src={post.thumbnail}
                  alt={post.title}
                  className="w-full h-full object-cover rounded-sm"
                />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <TrendingUp className="w-8 h-8 text-white" />
                </div>
                <div className="absolute top-1 left-1">
                  <Badge className="bg-red-500 text-white text-xs">
                    Trending
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        {/* Liked Tab */}
        <TabsContent value="liked" className="px-4 pt-4">
          <div className="text-center py-12">
            <Heart className="w-12 h-12 mx-auto mb-4 text-gray-600" />
            <h3 className="font-medium mb-2">Liked videos are private</h3>
            <p className="text-sm text-gray-400">Only you can see videos you've liked.</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
