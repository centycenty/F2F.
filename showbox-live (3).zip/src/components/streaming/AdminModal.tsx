import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Shield, 
  Users, 
  Crown,
  Eye,
  MessageSquare,
  Vote,
  Mic,
  Camera,
  Settings,
  UserPlus,
  UserMinus,
  Ban,
  UnlockIcon,
  LockIcon,
  Search,
  Filter,
  MoreHorizontal,
  Edit,
  Trash2,
  AlertTriangle,
  CheckCircle,
  Clock,
  Globe,
  User
} from "lucide-react";

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface UserRole {
  id: string;
  name: string;
  color: string;
  permissions: Permission[];
}

interface Permission {
  id: string;
  name: string;
  description: string;
  category: 'streaming' | 'moderation' | 'interaction' | 'admin';
}

interface AppUser {
  id: string;
  name: string;
  email: string;
  role: string;
  status: 'online' | 'offline' | 'banned' | 'suspended';
  joinedAt: Date;
  lastActive: Date;
  permissions: string[];
  stats: {
    comments: number;
    votes: number;
    warnings: number;
    viewTime: number;
  };
}

const defaultPermissions: Permission[] = [
  // Streaming Permissions
  { id: 'stream_view', name: 'View Stream', description: 'Can watch the live stream', category: 'streaming' },
  { id: 'stream_participate', name: 'Participate in Stream', description: 'Can join as a participant', category: 'streaming' },
  { id: 'stream_audio', name: 'Use Audio', description: 'Can use microphone', category: 'streaming' },
  { id: 'stream_video', name: 'Use Video', description: 'Can use camera', category: 'streaming' },
  { id: 'stream_screen_share', name: 'Screen Share', description: 'Can share screen', category: 'streaming' },
  
  // Interaction Permissions
  { id: 'chat_send', name: 'Send Messages', description: 'Can send chat messages', category: 'interaction' },
  { id: 'chat_react', name: 'React to Messages', description: 'Can like/react to messages', category: 'interaction' },
  { id: 'vote_participate', name: 'Vote in Polls', description: 'Can participate in voting', category: 'interaction' },
  { id: 'vote_create', name: 'Create Polls', description: 'Can create new polls', category: 'interaction' },
  { id: 'suggestions_send', name: 'Send Suggestions', description: 'Can suggest tasks/activities', category: 'interaction' },
  
  // Moderation Permissions
  { id: 'mod_mute_users', name: 'Mute Users', description: 'Can mute other users', category: 'moderation' },
  { id: 'mod_kick_users', name: 'Kick Users', description: 'Can remove users from stream', category: 'moderation' },
  { id: 'mod_ban_users', name: 'Ban Users', description: 'Can permanently ban users', category: 'moderation' },
  { id: 'mod_delete_messages', name: 'Delete Messages', description: 'Can delete chat messages', category: 'moderation' },
  { id: 'mod_warn_users', name: 'Issue Warnings', description: 'Can issue warnings to users', category: 'moderation' },
  { id: 'mod_view_reports', name: 'View Reports', description: 'Can view user reports', category: 'moderation' },
  { id: 'mod_control_stream', name: 'Control Stream', description: 'Can control stream layout/settings', category: 'moderation' },
  
  // Admin Permissions
  { id: 'admin_user_management', name: 'User Management', description: 'Can manage user accounts', category: 'admin' },
  { id: 'admin_role_management', name: 'Role Management', description: 'Can create/edit roles', category: 'admin' },
  { id: 'admin_system_settings', name: 'System Settings', description: 'Can modify system settings', category: 'admin' },
  { id: 'admin_analytics', name: 'View Analytics', description: 'Can view system analytics', category: 'admin' },
  { id: 'admin_emergency_controls', name: 'Emergency Controls', description: 'Can use emergency stop functions', category: 'admin' },
];

const defaultRoles: UserRole[] = [
  {
    id: 'super_admin',
    name: 'Super Admin',
    color: 'bg-red-500',
    permissions: defaultPermissions.map(p => p)
  },
  {
    id: 'admin',
    name: 'Administrator',
    color: 'bg-purple-500',
    permissions: defaultPermissions.filter(p => 
      p.category !== 'admin' || ['admin_user_management', 'admin_analytics'].includes(p.id)
    )
  },
  {
    id: 'moderator',
    name: 'Moderator',
    color: 'bg-blue-500',
    permissions: defaultPermissions.filter(p => 
      p.category === 'streaming' || p.category === 'moderation' || p.category === 'interaction'
    )
  },
  {
    id: 'participant',
    name: 'Participant',
    color: 'bg-green-500',
    permissions: defaultPermissions.filter(p => 
      p.category === 'streaming' || (p.category === 'interaction' && p.id !== 'vote_create')
    )
  },
  {
    id: 'vip_audience',
    name: 'VIP Audience',
    color: 'bg-yellow-500',
    permissions: defaultPermissions.filter(p => 
      p.id === 'stream_view' || p.category === 'interaction'
    )
  },
  {
    id: 'audience',
    name: 'Audience',
    color: 'bg-gray-500',
    permissions: defaultPermissions.filter(p => 
      ['stream_view', 'chat_send', 'chat_react', 'vote_participate'].includes(p.id)
    )
  },
  {
    id: 'restricted',
    name: 'Restricted',
    color: 'bg-orange-500',
    permissions: defaultPermissions.filter(p => p.id === 'stream_view')
  }
];

const mockUsers: AppUser[] = [
  {
    id: '1',
    name: 'Teez',
    email: 'teez@example.com',
    role: 'participant',
    status: 'online',
    joinedAt: new Date('2024-01-15'),
    lastActive: new Date(),
    permissions: ['stream_view', 'stream_participate', 'stream_audio', 'stream_video', 'chat_send', 'vote_participate'],
    stats: { comments: 145, votes: 23, warnings: 0, viewTime: 2340 }
  },
  {
    id: '2',
    name: 'Sarah Lagos',
    email: 'sarah@example.com',
    role: 'vip_audience',
    status: 'online',
    joinedAt: new Date('2024-01-10'),
    lastActive: new Date(Date.now() - 300000),
    permissions: ['stream_view', 'chat_send', 'chat_react', 'vote_participate', 'vote_create'],
    stats: { comments: 89, votes: 156, warnings: 0, viewTime: 4560 }
  },
  {
    id: '3',
    name: 'BigBrother Mod',
    email: 'mod@example.com',
    role: 'moderator',
    status: 'online',
    joinedAt: new Date('2024-01-01'),
    lastActive: new Date(Date.now() - 60000),
    permissions: ['mod_mute_users', 'mod_kick_users', 'mod_warn_users', 'mod_control_stream'],
    stats: { comments: 45, votes: 12, warnings: 0, viewTime: 8900 }
  },
  {
    id: '4',
    name: 'Viewer123',
    email: 'viewer@example.com',
    role: 'audience',
    status: 'offline',
    joinedAt: new Date('2024-01-20'),
    lastActive: new Date(Date.now() - 1800000),
    permissions: ['stream_view', 'chat_send', 'vote_participate'],
    stats: { comments: 12, votes: 8, warnings: 1, viewTime: 1200 }
  }
];

export function AdminModal({ isOpen, onClose }: AdminModalProps) {
  const [users, setUsers] = useState<AppUser[]>(mockUsers);
  const [roles, setRoles] = useState<UserRole[]>(defaultRoles);
  const [selectedUser, setSelectedUser] = useState<AppUser | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterRole, setFilterRole] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [editingRole, setEditingRole] = useState<UserRole | null>(null);

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = filterRole === "all" || user.role === filterRole;
    const matchesStatus = filterStatus === "all" || user.status === filterStatus;
    return matchesSearch && matchesRole && matchesStatus;
  });

  const updateUserRole = (userId: string, newRole: string) => {
    setUsers(users.map(user => 
      user.id === userId 
        ? { 
            ...user, 
            role: newRole,
            permissions: roles.find(r => r.id === newRole)?.permissions.map(p => p.id) || []
          }
        : user
    ));
  };

  const updateUserStatus = (userId: string, newStatus: 'online' | 'offline' | 'banned' | 'suspended') => {
    setUsers(users.map(user => 
      user.id === userId ? { ...user, status: newStatus } : user
    ));
  };

  const toggleUserPermission = (userId: string, permissionId: string) => {
    setUsers(users.map(user => {
      if (user.id === userId) {
        const hasPermission = user.permissions.includes(permissionId);
        return {
          ...user,
          permissions: hasPermission 
            ? user.permissions.filter(p => p !== permissionId)
            : [...user.permissions, permissionId]
        };
      }
      return user;
    }));
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'online': return <div className="w-2 h-2 bg-green-400 rounded-full" />;
      case 'offline': return <div className="w-2 h-2 bg-gray-400 rounded-full" />;
      case 'banned': return <Ban className="w-4 h-4 text-red-500" />;
      case 'suspended': return <Clock className="w-4 h-4 text-orange-500" />;
      default: return <div className="w-2 h-2 bg-gray-400 rounded-full" />;
    }
  };

  const getRoleColor = (roleId: string) => {
    return roles.find(r => r.id === roleId)?.color || 'bg-gray-500';
  };

  const getRoleName = (roleId: string) => {
    return roles.find(r => r.id === roleId)?.name || 'Unknown';
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'streaming': return <Camera className="w-4 h-4" />;
      case 'interaction': return <MessageSquare className="w-4 h-4" />;
      case 'moderation': return <Shield className="w-4 h-4" />;
      case 'admin': return <Crown className="w-4 h-4" />;
      default: return <Settings className="w-4 h-4" />;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[95vh] overflow-hidden bg-card">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Crown className="w-6 h-6 text-yellow-500" />
            Admin Panel - User Rights Management
            <Badge variant="destructive" className="ml-2">ADMIN ONLY</Badge>
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="users" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="users">User Management</TabsTrigger>
            <TabsTrigger value="roles">Role Management</TabsTrigger>
            <TabsTrigger value="permissions">Permissions</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          {/* User Management Tab */}
          <TabsContent value="users" className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search users..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-8 w-64"
                  />
                </div>
                <Select value={filterRole} onValueChange={setFilterRole}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Filter by role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Roles</SelectItem>
                    {roles.map(role => (
                      <SelectItem key={role.id} value={role.id}>{role.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="online">Online</SelectItem>
                    <SelectItem value="offline">Offline</SelectItem>
                    <SelectItem value="banned">Banned</SelectItem>
                    <SelectItem value="suspended">Suspended</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button className="flex items-center gap-2">
                <UserPlus className="w-4 h-4" />
                Add User
              </Button>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              {/* Users List */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Users ({filteredUsers.length})</span>
                    <Button variant="outline" size="sm">
                      <Filter className="w-4 h-4" />
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96">
                    <div className="space-y-2">
                      {filteredUsers.map(user => (
                        <div
                          key={user.id}
                          className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                            selectedUser?.id === user.id ? 'border-primary bg-primary/5' : 'border-border hover:bg-muted/50'
                          }`}
                          onClick={() => setSelectedUser(user)}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <div className="flex items-center gap-1">
                                {getStatusIcon(user.status)}
                                <span className="font-medium">{user.name}</span>
                              </div>
                              <Badge 
                                className={`text-white text-xs ${getRoleColor(user.role)}`}
                              >
                                {getRoleName(user.role)}
                              </Badge>
                            </div>
                            {user.stats.warnings > 0 && (
                              <Badge variant="destructive" className="text-xs">
                                {user.stats.warnings} warn
                              </Badge>
                            )}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {user.email}
                          </div>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground mt-1">
                            <span>{user.stats.comments} comments</span>
                            <span>{user.stats.votes} votes</span>
                            <span>{Math.floor(user.stats.viewTime / 60)}h viewed</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* User Details */}
              <Card>
                <CardHeader>
                  <CardTitle>
                    {selectedUser ? `${selectedUser.name} - Details` : 'Select a user'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {selectedUser ? (
                    <ScrollArea className="h-96">
                      <div className="space-y-4">
                        {/* User Info */}
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <Label>Status</Label>
                            <Select 
                              value={selectedUser.status} 
                              onValueChange={(value) => updateUserStatus(selectedUser.id, value as any)}
                            >
                              <SelectTrigger className="w-32">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="online">Online</SelectItem>
                                <SelectItem value="offline">Offline</SelectItem>
                                <SelectItem value="suspended">Suspended</SelectItem>
                                <SelectItem value="banned">Banned</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="flex items-center justify-between">
                            <Label>Role</Label>
                            <Select 
                              value={selectedUser.role} 
                              onValueChange={(value) => updateUserRole(selectedUser.id, value)}
                            >
                              <SelectTrigger className="w-40">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {roles.map(role => (
                                  <SelectItem key={role.id} value={role.id}>
                                    {role.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        {/* User Stats */}
                        <div className="grid grid-cols-2 gap-3 pt-3 border-t">
                          <div className="text-center p-2 bg-muted rounded">
                            <div className="text-lg font-bold">{selectedUser.stats.comments}</div>
                            <div className="text-xs text-muted-foreground">Comments</div>
                          </div>
                          <div className="text-center p-2 bg-muted rounded">
                            <div className="text-lg font-bold">{selectedUser.stats.votes}</div>
                            <div className="text-xs text-muted-foreground">Votes</div>
                          </div>
                          <div className="text-center p-2 bg-muted rounded">
                            <div className="text-lg font-bold">{selectedUser.stats.warnings}</div>
                            <div className="text-xs text-muted-foreground">Warnings</div>
                          </div>
                          <div className="text-center p-2 bg-muted rounded">
                            <div className="text-lg font-bold">{Math.floor(selectedUser.stats.viewTime / 60)}h</div>
                            <div className="text-xs text-muted-foreground">View Time</div>
                          </div>
                        </div>

                        {/* Individual Permissions */}
                        <div className="pt-3 border-t">
                          <Label className="text-sm font-medium mb-3 block">Individual Permissions</Label>
                          <div className="space-y-2">
                            {defaultPermissions.map(permission => (
                              <div key={permission.id} className="flex items-center justify-between py-2">
                                <div className="flex items-center gap-2">
                                  {getCategoryIcon(permission.category)}
                                  <div>
                                    <div className="text-sm font-medium">{permission.name}</div>
                                    <div className="text-xs text-muted-foreground">{permission.description}</div>
                                  </div>
                                </div>
                                <Switch
                                  checked={selectedUser.permissions.includes(permission.id)}
                                  onCheckedChange={() => toggleUserPermission(selectedUser.id, permission.id)}
                                />
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex gap-2 pt-3 border-t">
                          <Button variant="outline" size="sm" className="flex-1">
                            <Edit className="w-4 h-4 mr-2" />
                            Edit
                          </Button>
                          <Button variant="destructive" size="sm">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </ScrollArea>
                  ) : (
                    <div className="text-center text-muted-foreground py-8">
                      <User className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p>Select a user to view details</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Role Management Tab */}
          <TabsContent value="roles" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Manage User Roles</h3>
              <Button>
                <UserPlus className="w-4 h-4 mr-2" />
                Create Role
              </Button>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {roles.map(role => (
                <Card key={role.id}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${role.color}`} />
                        {role.name}
                      </div>
                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="text-sm text-muted-foreground">
                        {role.permissions.length} permissions
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {role.permissions.slice(0, 3).map(permission => (
                          <Badge key={permission.id} variant="outline" className="text-xs">
                            {permission.name}
                          </Badge>
                        ))}
                        {role.permissions.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{role.permissions.length - 3} more
                          </Badge>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {users.filter(u => u.role === role.id).length} users assigned
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Permissions Tab */}
          <TabsContent value="permissions" className="space-y-4">
            <div className="grid gap-4">
              {['streaming', 'interaction', 'moderation', 'admin'].map(category => (
                <Card key={category}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 capitalize">
                      {getCategoryIcon(category)}
                      {category} Permissions
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-3 md:grid-cols-2">
                      {defaultPermissions
                        .filter(p => p.category === category)
                        .map(permission => (
                          <div key={permission.id} className="flex items-start gap-3 p-3 border rounded">
                            <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
                            <div>
                              <div className="font-medium">{permission.name}</div>
                              <div className="text-sm text-muted-foreground">{permission.description}</div>
                              <div className="text-xs text-muted-foreground mt-1">
                                Used by {roles.filter(r => r.permissions.some(p => p.id === permission.id)).length} roles
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Users</p>
                      <p className="text-2xl font-bold">{users.length}</p>
                    </div>
                    <Users className="w-8 h-8 text-primary" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Online Now</p>
                      <p className="text-2xl font-bold">{users.filter(u => u.status === 'online').length}</p>
                    </div>
                    <Globe className="w-8 h-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Active Warnings</p>
                      <p className="text-2xl font-bold">{users.reduce((sum, u) => sum + u.stats.warnings, 0)}</p>
                    </div>
                    <AlertTriangle className="w-8 h-8 text-yellow-500" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Banned Users</p>
                      <p className="text-2xl font-bold">{users.filter(u => u.status === 'banned').length}</p>
                    </div>
                    <Ban className="w-8 h-8 text-red-500" />
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>User Distribution by Role</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {roles.map(role => {
                    const userCount = users.filter(u => u.role === role.id).length;
                    const percentage = (userCount / users.length) * 100;
                    return (
                      <div key={role.id} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className={`w-3 h-3 rounded-full ${role.color}`} />
                          <span>{role.name}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-32 bg-muted rounded-full h-2">
                            <div 
                              className={`h-2 rounded-full ${role.color}`}
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                          <span className="text-sm font-medium w-12 text-right">{userCount}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
