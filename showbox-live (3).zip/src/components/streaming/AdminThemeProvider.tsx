import React, { createContext, useContext, useEffect, useState } from 'react';

interface ThemeConfig {
  primaryColor: string;
  secondaryColor: string;
  backgroundColor: string;
  accentColor: string;
  textColor: string;
  cardBackground: string;
  gradientFrom: string;
  gradientTo: string;
  name: string;
}

interface ContentAssets {
  logo: string;
  backgroundImage: string;
  emptyBoxImage: string;
  animations: {
    entry: string;
    exit: string;
    idle: string;
  };
}

interface VoiceSettings {
  enabled: boolean;
  voice: string;
  speed: number;
  pitch: number;
  effects: {
    echo: boolean;
    reverb: boolean;
    distortion: boolean;
  };
  phrases: {
    welcome: string;
    eviction: string;
    task: string;
    diary: string;
    warning: string;
  };
}

interface ServerConfig {
  provider: 'livekit' | 'agora' | 'webrtc' | 'mock';
  url: string;
  apiKey: string;
  secret: string;
  region: string;
}

interface AdminThemeContextType {
  theme: ThemeConfig;
  assets: ContentAssets;
  voice: VoiceSettings;
  server: ServerConfig;
  setTheme: (theme: ThemeConfig) => void;
  setAssets: (assets: ContentAssets) => void;
  setVoice: (voice: VoiceSettings) => void;
  setServer: (server: ServerConfig) => void;
  applyTheme: () => void;
  speak: (text: string, type?: keyof VoiceSettings['phrases']) => void;
  presetThemes: ThemeConfig[];
}

const defaultTheme: ThemeConfig = {
  primaryColor: '#3b82f6',
  secondaryColor: '#10b981',
  backgroundColor: '#000000',
  accentColor: '#f59e0b',
  textColor: '#ffffff',
  cardBackground: '#1f2937',
  gradientFrom: '#1e1b4b',
  gradientTo: '#7c2d12',
  name: 'Default Dark'
};

const bigBrotherTheme: ThemeConfig = {
  primaryColor: '#dc2626',
  secondaryColor: '#fbbf24',
  backgroundColor: '#0f0f23',
  accentColor: '#f59e0b',
  textColor: '#ffffff',
  cardBackground: '#1e1b4b',
  gradientFrom: '#7c2d12',
  gradientTo: '#1e1b4b',
  name: 'Big Brother'
};

const luxuryTheme: ThemeConfig = {
  primaryColor: '#d97706',
  secondaryColor: '#059669',
  backgroundColor: '#1c1917',
  accentColor: '#fbbf24',
  textColor: '#fbbf24',
  cardBackground: '#292524',
  gradientFrom: '#451a03',
  gradientTo: '#1c1917',
  name: 'Luxury Gold'
};

const defaultAssets: ContentAssets = {
  logo: '',
  backgroundImage: '',
  emptyBoxImage: '',
  animations: {
    entry: 'fadeIn',
    exit: 'fadeOut',
    idle: 'pulse'
  }
};

const defaultVoice: VoiceSettings = {
  enabled: true,
  voice: 'en-US-Standard-D',
  speed: 1.0,
  pitch: 0.8,
  effects: {
    echo: true,
    reverb: true,
    distortion: false
  },
  phrases: {
    welcome: 'Welcome to the Big Brother house.',
    eviction: 'The votes have been counted and verified.',
    task: 'Housemates, please gather in the lounge for your next task.',
    diary: 'Please come to the diary room.',
    warning: 'This is an official warning from Big Brother.'
  }
};

const defaultServer: ServerConfig = {
  provider: 'mock',
  url: 'ws://localhost:7880',
  apiKey: '',
  secret: '',
  region: 'us-east-1'
};

const AdminThemeContext = createContext<AdminThemeContextType | null>(null);

export function AdminThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<ThemeConfig>(defaultTheme);
  const [assets, setAssets] = useState<ContentAssets>(defaultAssets);
  const [voice, setVoice] = useState<VoiceSettings>(defaultVoice);
  const [server, setServer] = useState<ServerConfig>(defaultServer);

  const presetThemes = [defaultTheme, bigBrotherTheme, luxuryTheme];

  const applyTheme = () => {
    const root = document.documentElement;
    root.style.setProperty('--primary', theme.primaryColor);
    root.style.setProperty('--secondary', theme.secondaryColor);
    root.style.setProperty('--background', theme.backgroundColor);
    root.style.setProperty('--accent', theme.accentColor);
    root.style.setProperty('--foreground', theme.textColor);
    root.style.setProperty('--card', theme.cardBackground);
    root.style.setProperty('--gradient-from', theme.gradientFrom);
    root.style.setProperty('--gradient-to', theme.gradientTo);
  };

  const speak = (text: string, type?: keyof VoiceSettings['phrases']) => {
    if (!voice.enabled) return;

    const speechText = type ? voice.phrases[type] : text;
    
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(speechText);
      
      // Find the selected voice
      const voices = speechSynthesis.getVoices();
      const selectedVoice = voices.find(v => v.name.includes(voice.voice)) || voices[0];
      
      if (selectedVoice) {
        utterance.voice = selectedVoice;
      }
      
      utterance.rate = voice.speed;
      utterance.pitch = voice.pitch;
      
      // Apply voice effects (simplified)
      if (voice.effects.echo || voice.effects.reverb) {
        utterance.volume = 0.8;
      }
      
      speechSynthesis.speak(utterance);
    }
  };

  useEffect(() => {
    applyTheme();
  }, [theme]);

  // Load saved settings
  useEffect(() => {
    const savedTheme = localStorage.getItem('admin-theme');
    const savedAssets = localStorage.getItem('admin-assets');
    const savedVoice = localStorage.getItem('admin-voice');
    const savedServer = localStorage.getItem('admin-server');

    if (savedTheme) setTheme(JSON.parse(savedTheme));
    if (savedAssets) setAssets(JSON.parse(savedAssets));
    if (savedVoice) setVoice(JSON.parse(savedVoice));
    if (savedServer) setServer(JSON.parse(savedServer));
  }, []);

  // Save settings
  useEffect(() => {
    localStorage.setItem('admin-theme', JSON.stringify(theme));
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('admin-assets', JSON.stringify(assets));
  }, [assets]);

  useEffect(() => {
    localStorage.setItem('admin-voice', JSON.stringify(voice));
  }, [voice]);

  useEffect(() => {
    localStorage.setItem('admin-server', JSON.stringify(server));
  }, [server]);

  const value: AdminThemeContextType = {
    theme,
    assets,
    voice,
    server,
    setTheme,
    setAssets,
    setVoice,
    setServer,
    applyTheme,
    speak,
    presetThemes
  };

  return (
    <AdminThemeContext.Provider value={value}>
      {children}
    </AdminThemeContext.Provider>
  );
}

export function useAdminTheme() {
  const context = useContext(AdminThemeContext);
  if (!context) {
    throw new Error('useAdminTheme must be used within AdminThemeProvider');
  }
  return context;
}
