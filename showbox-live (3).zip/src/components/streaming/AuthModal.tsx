import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { User, Mail, Heart } from "lucide-react";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuth: (user: { name: string; isAuth: boolean }) => void;
}

export function AuthModal({ isOpen, onClose, onAuth }: AuthModalProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleQuickSignup = async () => {
    if (!formData.name.trim()) return;
    
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const userData = {
      name: formData.name,
      isAuth: true,
    };
    
    onAuth(userData);
    setIsLoading(false);
    onClose();
    setFormData({ name: "", email: "" });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleQuickSignup();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md bg-card">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-center">
            <Heart className="w-5 h-5 text-primary" />
            Join the Show!
          </DialogTitle>
        </DialogHeader>

        <Card className="border-0 shadow-none">
          <CardContent className="p-0 space-y-6">
            <div className="text-center text-sm text-muted-foreground">
              Quick signup to like, comment, and vote on BigBrotherNaija
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="flex items-center gap-2">
                  <User className="w-4 h-4" />
                  Display Name
                </Label>
                <Input
                  id="name"
                  placeholder="Enter your display name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  onKeyPress={handleKeyPress}
                  className="text-base"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  Email (Optional)
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your@email.com"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  onKeyPress={handleKeyPress}
                  className="text-base"
                />
              </div>
            </div>

            <div className="space-y-3">
              <Button 
                onClick={handleQuickSignup}
                disabled={!formData.name.trim() || isLoading}
                className="w-full text-base py-6"
                size="lg"
              >
                {isLoading ? "Joining..." : "Join & Start Interacting"}
              </Button>
              
              <div className="text-xs text-center text-muted-foreground">
                By joining, you can like, comment, and vote on your favorite housemates and tasks
              </div>
            </div>

            <div className="text-center">
              <Button 
                variant="ghost" 
                onClick={onClose}
                className="text-muted-foreground hover:text-foreground"
              >
                Continue as guest (view only)
              </Button>
            </div>
          </CardContent>
        </Card>
      </DialogContent>
    </Dialog>
  );
}