import { useState, useEffect, useRef } from "react";
import { Send, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface Comment {
  id: number;
  user: string;
  message: string;
  timestamp: Date;
  isLocal?: boolean;
}

interface CommentsSectionProps {
  user: { name: string; isAuth: boolean } | null;
  onAuthRequired: () => void;
  onNewComment?: (comment: Comment) => void;
}

const initialComments: Comment[] = [
  { id: 1, user: "sarah_lagos", message: "Teez is killing it! 🔥", timestamp: new Date(Date.now() - 30000) },
  { id: 2, user: "naija_boy", message: "Big Bella for the win!", timestamp: new Date(Date.now() - 25000) },
  { id: 3, user: "queen_bee", message: "This season is so intense 😍", timestamp: new Date(Date.now() - 20000) },
  { id: 4, user: "lagos_vibes", message: "Who's voting for cooking challenge?", timestamp: new Date(Date.now() - 15000) },
  { id: 5, user: "bb_fan_2024", message: "Stream quality is amazing today! 📺", timestamp: new Date(Date.now() - 12000) },
  { id: 6, user: "viewer123", message: "Can't wait for tonight's task reveal", timestamp: new Date(Date.now() - 8000) },
];

const liveCommentTemplates = [
  "This is getting intense! 🔥",
  "Who else is rooting for [name]?",
  "The drama tonight! 😱",
  "Best season ever! 👑",
  "Voting now! 🗳️",
  "Can't believe what just happened!",
  "Stream quality is perfect today 📺",
  "Big Brother house is lit! 🏠",
  "Anyone else crying? 😭",
  "Plot twist incoming! 🌪️"
];

export function CommentsSection({ user, onAuthRequired, onNewComment }: CommentsSectionProps) {
  const [comments, setComments] = useState<Comment[]>(initialComments);
  const [newComment, setNewComment] = useState("");
  const [isScrolled, setIsScrolled] = useState(false);
  const commentsEndRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new comments arrive
  const scrollToBottom = () => {
    if (!isScrolled) {
      commentsEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [comments]);

  // Simulate live comments from other viewers
  useEffect(() => {
    const interval = setInterval(() => {
      const randomTemplate = liveCommentTemplates[Math.floor(Math.random() * liveCommentTemplates.length)];
      const randomUsers = ["viewer_" + Math.floor(Math.random() * 999), "bb_lover", "housemate_fan", "live_watcher"];
      const randomUser = randomUsers[Math.floor(Math.random() * randomUsers.length)];
      
      const simulatedComment: Comment = {
        id: Date.now() + Math.random(),
        user: randomUser,
        message: randomTemplate,
        timestamp: new Date(),
        isLocal: false
      };

      setComments(prev => [simulatedComment, ...prev].slice(0, 100)); // Keep only recent 100 comments
    }, 5000 + Math.random() * 10000); // Random interval between 5-15 seconds

    return () => clearInterval(interval);
  }, []);

  const handleSendComment = () => {
    if (!user?.isAuth) {
      onAuthRequired();
      return;
    }

    if (!newComment.trim()) return;

    const comment: Comment = {
      id: Date.now(),
      user: user.name,
      message: newComment,
      timestamp: new Date(),
      isLocal: true
    };

    setComments(prev => [comment, ...prev].slice(0, 100));
    setNewComment("");
    
    // Notify parent component of new comment for floating display
    onNewComment?.(comment);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendComment();
    }
  };

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
    const isAtBottom = scrollTop + clientHeight >= scrollHeight - 10;
    setIsScrolled(!isAtBottom);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="flex flex-col h-full max-h-80">
      {/* Comments List */}
      <div 
        ref={scrollContainerRef}
        className="flex-1 overflow-y-auto space-y-2 mb-3 max-h-60"
        onScroll={handleScroll}
      >
        <div className="flex flex-col-reverse">
          {comments.map((comment) => (
            <div
              key={comment.id}
              className={`flex items-start gap-2 p-2 rounded-lg text-sm ${
                comment.isLocal 
                  ? 'bg-primary/20 border border-primary/30 text-white'
                  : 'bg-gray-800/80 hover:bg-gray-700/80 text-white'
              } transition-colors`}
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className={`font-medium text-xs ${
                    comment.isLocal ? 'text-primary' : 'text-accent'
                  }`}>
                    {comment.user}
                    {comment.isLocal && ' (You)'}
                  </span>
                  <span className="text-xs text-gray-400">
                    {formatTime(comment.timestamp)}
                  </span>
                </div>
                <p className="text-white break-words">
                  {comment.message}
                </p>
              </div>
              
              {/* Heart reaction for other comments */}
              {!comment.isLocal && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 hover:bg-red-500/20"
                  onClick={() => {
                    // Could implement reactions here
                  }}
                >
                  <Heart className="w-3 h-3" />
                </Button>
              )}
            </div>
          ))}
        </div>
        <div ref={commentsEndRef} />
      </div>

      {/* Scroll indicator */}
      {isScrolled && (
        <Button
          variant="ghost"
          size="sm"
          onClick={scrollToBottom}
          className="mb-2 text-xs bg-primary/20 hover:bg-primary/30"
        >
          New messages ↓
        </Button>
      )}

      {/* Comment Input */}
      <div className="flex items-center gap-2 bg-gray-800/90 backdrop-blur-sm rounded-full p-2">
        <Input
          placeholder={user?.isAuth ? "Add a comment..." : "Sign up to comment"}
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          onKeyPress={handleKeyPress}
          className="border-0 bg-transparent text-white placeholder:text-gray-400 focus-visible:ring-0"
          disabled={!user?.isAuth}
          maxLength={200}
        />
        <Button
          size="icon"
          variant="ghost"
          onClick={handleSendComment}
          disabled={!user?.isAuth || !newComment.trim()}
          className="shrink-0 rounded-full hover:bg-white/20"
        >
          <Send className="w-4 h-4" />
        </Button>
      </div>
      
      {newComment.length > 180 && (
        <div className="text-xs text-gray-400 mt-1 text-right">
          {200 - newComment.length} characters left
        </div>
      )}
    </div>
  );
}
