import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { useAdminTheme } from "./AdminThemeProvider";
import {
  Crown, Palette, Database, Settings, Mic, Volume2, VolumeX,
  Upload, Download, Eye, Image, Sparkles, Zap, Server,
  Wifi, Radio, Music, Play, Pause, SkipForward, RotateCcw,
  Waveform, AudioWaveform, Camera, Video, Monitor, Layers,
  FileText, Save, RefreshCw, AlertTriangle, CheckCircle,
  Globe, Lock, Key, Shield, Users, MessageSquare, UserPlus,
  UserMinus, Ban, Search, Filter, MoreHorizontal, Edit, Trash2,
  Clock, User
} from "lucide-react";

interface EnhancedAdminModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface UserRole {
  id: string;
  name: string;
  color: string;
  permissions: Permission[];
}

interface Permission {
  id: string;
  name: string;
  description: string;
  category: 'streaming' | 'moderation' | 'interaction' | 'admin';
}

interface AppUser {
  id: string;
  name: string;
  email: string;
  role: string;
  status: 'online' | 'offline' | 'banned' | 'suspended';
  joinedAt: Date;
  lastActive: Date;
  permissions: string[];
  stats: {
    comments: number;
    votes: number;
    warnings: number;
    viewTime: number;
  };
}

const defaultPermissions: Permission[] = [
  // Streaming Permissions
  { id: 'stream_view', name: 'View Stream', description: 'Can watch the live stream', category: 'streaming' },
  { id: 'stream_participate', name: 'Participate in Stream', description: 'Can join as a participant', category: 'streaming' },
  { id: 'stream_audio', name: 'Use Audio', description: 'Can use microphone', category: 'streaming' },
  { id: 'stream_video', name: 'Use Video', description: 'Can use camera', category: 'streaming' },
  { id: 'stream_screen_share', name: 'Screen Share', description: 'Can share screen', category: 'streaming' },

  // Interaction Permissions
  { id: 'chat_send', name: 'Send Messages', description: 'Can send chat messages', category: 'interaction' },
  { id: 'chat_react', name: 'React to Messages', description: 'Can like/react to messages', category: 'interaction' },
  { id: 'vote_participate', name: 'Vote in Polls', description: 'Can participate in voting', category: 'interaction' },
  { id: 'vote_create', name: 'Create Polls', description: 'Can create new polls', category: 'interaction' },
  { id: 'suggestions_send', name: 'Send Suggestions', description: 'Can suggest tasks/activities', category: 'interaction' },

  // Moderation Permissions
  { id: 'mod_mute_users', name: 'Mute Users', description: 'Can mute other users', category: 'moderation' },
  { id: 'mod_kick_users', name: 'Kick Users', description: 'Can remove users from stream', category: 'moderation' },
  { id: 'mod_ban_users', name: 'Ban Users', description: 'Can permanently ban users', category: 'moderation' },
  { id: 'mod_delete_messages', name: 'Delete Messages', description: 'Can delete chat messages', category: 'moderation' },
  { id: 'mod_warn_users', name: 'Issue Warnings', description: 'Can issue warnings to users', category: 'moderation' },
  { id: 'mod_view_reports', name: 'View Reports', description: 'Can view user reports', category: 'moderation' },
  { id: 'mod_control_stream', name: 'Control Stream', description: 'Can control stream layout/settings', category: 'moderation' },

  // Admin Permissions
  { id: 'admin_user_management', name: 'User Management', description: 'Can manage user accounts', category: 'admin' },
  { id: 'admin_role_management', name: 'Role Management', description: 'Can create/edit roles', category: 'admin' },
  { id: 'admin_system_settings', name: 'System Settings', description: 'Can modify system settings', category: 'admin' },
  { id: 'admin_analytics', name: 'View Analytics', description: 'Can view system analytics', category: 'admin' },
  { id: 'admin_emergency_controls', name: 'Emergency Controls', description: 'Can use emergency stop functions', category: 'admin' },
];

const defaultRoles: UserRole[] = [
  {
    id: 'super_admin',
    name: 'Super Admin',
    color: 'bg-red-500',
    permissions: defaultPermissions.map(p => p)
  },
  {
    id: 'admin',
    name: 'Administrator',
    color: 'bg-purple-500',
    permissions: defaultPermissions.filter(p =>
      p.category !== 'admin' || ['admin_user_management', 'admin_analytics'].includes(p.id)
    )
  },
  {
    id: 'moderator',
    name: 'Moderator',
    color: 'bg-blue-500',
    permissions: defaultPermissions.filter(p =>
      p.category === 'streaming' || p.category === 'moderation' || p.category === 'interaction'
    )
  },
  {
    id: 'participant',
    name: 'Participant',
    color: 'bg-green-500',
    permissions: defaultPermissions.filter(p =>
      p.category === 'streaming' || (p.category === 'interaction' && p.id !== 'vote_create')
    )
  },
  {
    id: 'vip_audience',
    name: 'VIP Audience',
    color: 'bg-yellow-500',
    permissions: defaultPermissions.filter(p =>
      p.id === 'stream_view' || p.category === 'interaction'
    )
  },
  {
    id: 'audience',
    name: 'Audience',
    color: 'bg-gray-500',
    permissions: defaultPermissions.filter(p =>
      ['stream_view', 'chat_send', 'chat_react', 'vote_participate'].includes(p.id)
    )
  },
  {
    id: 'restricted',
    name: 'Restricted',
    color: 'bg-orange-500',
    permissions: defaultPermissions.filter(p => p.id === 'stream_view')
  }
];

const mockUsers: AppUser[] = [
  {
    id: '1',
    name: 'Teez',
    email: 'teez@example.com',
    role: 'participant',
    status: 'online',
    joinedAt: new Date('2024-01-15'),
    lastActive: new Date(),
    permissions: ['stream_view', 'stream_participate', 'stream_audio', 'stream_video', 'chat_send', 'vote_participate'],
    stats: { comments: 145, votes: 23, warnings: 0, viewTime: 2340 }
  },
  {
    id: '2',
    name: 'Sarah Lagos',
    email: 'sarah@example.com',
    role: 'vip_audience',
    status: 'online',
    joinedAt: new Date('2024-01-10'),
    lastActive: new Date(Date.now() - 300000),
    permissions: ['stream_view', 'chat_send', 'chat_react', 'vote_participate', 'vote_create'],
    stats: { comments: 89, votes: 156, warnings: 0, viewTime: 4560 }
  },
  {
    id: '3',
    name: 'BigBrother Mod',
    email: 'mod@example.com',
    role: 'moderator',
    status: 'online',
    joinedAt: new Date('2024-01-01'),
    lastActive: new Date(Date.now() - 60000),
    permissions: ['mod_mute_users', 'mod_kick_users', 'mod_warn_users', 'mod_control_stream'],
    stats: { comments: 45, votes: 12, warnings: 0, viewTime: 8900 }
  },
  {
    id: '4',
    name: 'Viewer123',
    email: 'viewer@example.com',
    role: 'audience',
    status: 'offline',
    joinedAt: new Date('2024-01-20'),
    lastActive: new Date(Date.now() - 1800000),
    permissions: ['stream_view', 'chat_send', 'vote_participate'],
    stats: { comments: 12, votes: 8, warnings: 1, viewTime: 1200 }
  }
];

interface VoicePreset {
  id: string;
  name: string;
  description: string;
  voice: string;
  speed: number;
  pitch: number;
  effects: {
    echo: boolean;
    reverb: boolean;
    distortion: boolean;
  };
}

const voicePresets: VoicePreset[] = [
  {
    id: 'bigbrother',
    name: 'Big Brother (Classic)',
    description: 'Deep, authoritative voice with echo',
    voice: 'en-US-Standard-D',
    speed: 0.8,
    pitch: 0.7,
    effects: { echo: true, reverb: true, distortion: false }
  },
  {
    id: 'bigbrother_female',
    name: 'Big Brother (Female)',
    description: 'Commanding female voice',
    voice: 'en-US-Standard-F',
    speed: 0.9,
    pitch: 0.8,
    effects: { echo: true, reverb: false, distortion: false }
  },
  {
    id: 'mysterious',
    name: 'Mysterious Voice',
    description: 'Distorted mysterious effect',
    voice: 'en-US-Standard-B',
    speed: 0.7,
    pitch: 0.6,
    effects: { echo: true, reverb: true, distortion: true }
  },
  {
    id: 'robot',
    name: 'Robot Voice',
    description: 'Robotic AI assistant',
    voice: 'en-US-Standard-C',
    speed: 1.0,
    pitch: 0.5,
    effects: { echo: false, reverb: false, distortion: true }
  },
  {
    id: 'normal',
    name: 'Normal Announcer',
    description: 'Clear, professional voice',
    voice: 'en-US-Standard-A',
    speed: 1.0,
    pitch: 1.0,
    effects: { echo: false, reverb: false, distortion: false }
  }
];

const streamingProviders = [
  { id: 'mock', name: 'Mock Server (Development)', description: 'Local development server' },
  { id: 'livekit', name: 'LiveKit', description: 'Real-time communication platform' },
  { id: 'agora', name: 'Agora.io', description: 'Video calling and live streaming' },
  { id: 'webrtc', name: 'WebRTC Direct', description: 'Direct peer-to-peer connection' },
  { id: 'twilio', name: 'Twilio Video', description: 'Enterprise video platform' },
  { id: 'zoom', name: 'Zoom SDK', description: 'Zoom video integration' }
];

export function EnhancedAdminModal({ isOpen, onClose }: EnhancedAdminModalProps) {
  const { theme, assets, voice, server, setTheme, setAssets, setVoice, setServer, speak, presetThemes } = useAdminTheme();

  // User Management State
  const [users, setUsers] = useState<AppUser[]>(mockUsers);
  const [roles, setRoles] = useState<UserRole[]>(defaultRoles);
  const [selectedUser, setSelectedUser] = useState<AppUser | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterRole, setFilterRole] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [editingRole, setEditingRole] = useState<UserRole | null>(null);

  // Theme and Voice State
  const [selectedVoicePreset, setSelectedVoicePreset] = useState<string>('bigbrother');
  const [isTestingVoice, setIsTestingVoice] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [customColors, setCustomColors] = useState({
    primary: theme.primaryColor,
    secondary: theme.secondaryColor,
    background: theme.backgroundColor,
    accent: theme.accentColor
  });

  // User Management Functions
  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = filterRole === "all" || user.role === filterRole;
    const matchesStatus = filterStatus === "all" || user.status === filterStatus;
    return matchesSearch && matchesRole && matchesStatus;
  });

  const updateUserRole = (userId: string, newRole: string) => {
    setUsers(users.map(user =>
      user.id === userId
        ? {
            ...user,
            role: newRole,
            permissions: roles.find(r => r.id === newRole)?.permissions.map(p => p.id) || []
          }
        : user
    ));
  };

  const updateUserStatus = (userId: string, newStatus: 'online' | 'offline' | 'banned' | 'suspended') => {
    setUsers(users.map(user =>
      user.id === userId ? { ...user, status: newStatus } : user
    ));
  };

  const toggleUserPermission = (userId: string, permissionId: string) => {
    setUsers(users.map(user => {
      if (user.id === userId) {
        const hasPermission = user.permissions.includes(permissionId);
        return {
          ...user,
          permissions: hasPermission
            ? user.permissions.filter(p => p !== permissionId)
            : [...user.permissions, permissionId]
        };
      }
      return user;
    }));
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'online': return <div className="w-2 h-2 bg-green-400 rounded-full" />;
      case 'offline': return <div className="w-2 h-2 bg-gray-400 rounded-full" />;
      case 'banned': return <Ban className="w-4 h-4 text-red-500" />;
      case 'suspended': return <Clock className="w-4 h-4 text-orange-500" />;
      default: return <div className="w-2 h-2 bg-gray-400 rounded-full" />;
    }
  };

  const getRoleColor = (roleId: string) => {
    return roles.find(r => r.id === roleId)?.color || 'bg-gray-500';
  };

  const getRoleName = (roleId: string) => {
    return roles.find(r => r.id === roleId)?.name || 'Unknown';
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'streaming': return <Camera className="w-4 h-4" />;
      case 'interaction': return <MessageSquare className="w-4 h-4" />;
      case 'moderation': return <Shield className="w-4 h-4" />;
      case 'admin': return <Crown className="w-4 h-4" />;
      default: return <Settings className="w-4 h-4" />;
    }
  };

  const handleVoicePresetChange = (presetId: string) => {
    const preset = voicePresets.find(p => p.id === presetId);
    if (preset) {
      setSelectedVoicePreset(presetId);
      setVoice({
        ...voice,
        voice: preset.voice,
        speed: preset.speed,
        pitch: preset.pitch,
        effects: preset.effects
      });
    }
  };

  const testVoice = async (text: string) => {
    setIsTestingVoice(true);
    speak(text);
    setTimeout(() => setIsTestingVoice(false), 2000);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>, type: string) => {
    const files = Array.from(event.target.files || []);
    if (files.length > 0) {
      const file = files[0];
      const url = URL.createObjectURL(file);
      
      setAssets({
        ...assets,
        [type]: url
      });
      
      setUploadedFiles(prev => [...prev, file]);
    }
  };

  const applyThemePreset = (preset: any) => {
    setTheme(preset);
    setCustomColors({
      primary: preset.primaryColor,
      secondary: preset.secondaryColor,
      background: preset.backgroundColor,
      accent: preset.accentColor
    });
  };

  const applyCustomTheme = () => {
    setTheme({
      ...theme,
      primaryColor: customColors.primary,
      secondaryColor: customColors.secondary,
      backgroundColor: customColors.background,
      accentColor: customColors.accent,
      name: 'Custom Theme'
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[95vh] overflow-hidden bg-card">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Crown className="w-6 h-6 text-yellow-500" />
            Enhanced Admin Control Panel
            <Badge variant="destructive" className="ml-2">ADMIN ONLY</Badge>
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="users" className="w-full">
          <TabsList className="grid w-full grid-cols-9 text-xs">
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="roles">Roles</TabsTrigger>
            <TabsTrigger value="permissions">Permissions</TabsTrigger>
            <TabsTrigger value="themes">Themes</TabsTrigger>
            <TabsTrigger value="content">Assets</TabsTrigger>
            <TabsTrigger value="voice">Voice</TabsTrigger>
            <TabsTrigger value="servers">Servers</TabsTrigger>
            <TabsTrigger value="animations">Effects</TabsTrigger>
            <TabsTrigger value="storage">Storage</TabsTrigger>
          </TabsList>

          {/* User Management Tab */}
          <TabsContent value="users" className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search users..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-8 w-64"
                  />
                </div>
                <Select value={filterRole} onValueChange={setFilterRole}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Filter by role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Roles</SelectItem>
                    {roles.map(role => (
                      <SelectItem key={role.id} value={role.id}>{role.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="online">Online</SelectItem>
                    <SelectItem value="offline">Offline</SelectItem>
                    <SelectItem value="banned">Banned</SelectItem>
                    <SelectItem value="suspended">Suspended</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button className="flex items-center gap-2">
                <UserPlus className="w-4 h-4" />
                Add User
              </Button>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              {/* Users List */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Users ({filteredUsers.length})</span>
                    <Button variant="outline" size="sm">
                      <Filter className="w-4 h-4" />
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96">
                    <div className="space-y-2">
                      {filteredUsers.map(user => (
                        <div
                          key={user.id}
                          className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                            selectedUser?.id === user.id ? 'border-primary bg-primary/5' : 'border-border hover:bg-muted/50'
                          }`}
                          onClick={() => setSelectedUser(user)}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <div className="flex items-center gap-1">
                                {getStatusIcon(user.status)}
                                <span className="font-medium">{user.name}</span>
                              </div>
                              <Badge
                                className={`text-white text-xs ${getRoleColor(user.role)}`}
                              >
                                {getRoleName(user.role)}
                              </Badge>
                            </div>
                            {user.stats.warnings > 0 && (
                              <Badge variant="destructive" className="text-xs">
                                {user.stats.warnings} warn
                              </Badge>
                            )}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {user.email}
                          </div>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground mt-1">
                            <span>{user.stats.comments} comments</span>
                            <span>{user.stats.votes} votes</span>
                            <span>{Math.floor(user.stats.viewTime / 60)}h viewed</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* User Details */}
              <Card>
                <CardHeader>
                  <CardTitle>
                    {selectedUser ? `${selectedUser.name} - Details` : 'Select a user'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {selectedUser ? (
                    <ScrollArea className="h-96">
                      <div className="space-y-4">
                        {/* User Info */}
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <Label>Status</Label>
                            <Select
                              value={selectedUser.status}
                              onValueChange={(value) => updateUserStatus(selectedUser.id, value as any)}
                            >
                              <SelectTrigger className="w-32">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="online">Online</SelectItem>
                                <SelectItem value="offline">Offline</SelectItem>
                                <SelectItem value="suspended">Suspended</SelectItem>
                                <SelectItem value="banned">Banned</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="flex items-center justify-between">
                            <Label>Role</Label>
                            <Select
                              value={selectedUser.role}
                              onValueChange={(value) => updateUserRole(selectedUser.id, value)}
                            >
                              <SelectTrigger className="w-40">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {roles.map(role => (
                                  <SelectItem key={role.id} value={role.id}>
                                    {role.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        {/* User Stats */}
                        <div className="grid grid-cols-2 gap-3 pt-3 border-t">
                          <div className="text-center p-2 bg-muted rounded">
                            <div className="text-lg font-bold">{selectedUser.stats.comments}</div>
                            <div className="text-xs text-muted-foreground">Comments</div>
                          </div>
                          <div className="text-center p-2 bg-muted rounded">
                            <div className="text-lg font-bold">{selectedUser.stats.votes}</div>
                            <div className="text-xs text-muted-foreground">Votes</div>
                          </div>
                          <div className="text-center p-2 bg-muted rounded">
                            <div className="text-lg font-bold">{selectedUser.stats.warnings}</div>
                            <div className="text-xs text-muted-foreground">Warnings</div>
                          </div>
                          <div className="text-center p-2 bg-muted rounded">
                            <div className="text-lg font-bold">{Math.floor(selectedUser.stats.viewTime / 60)}h</div>
                            <div className="text-xs text-muted-foreground">View Time</div>
                          </div>
                        </div>

                        {/* Individual Permissions */}
                        <div className="pt-3 border-t">
                          <Label className="text-sm font-medium mb-3 block">Individual Permissions</Label>
                          <div className="space-y-2">
                            {defaultPermissions.map(permission => (
                              <div key={permission.id} className="flex items-center justify-between py-2">
                                <div className="flex items-center gap-2">
                                  {getCategoryIcon(permission.category)}
                                  <div>
                                    <div className="text-sm font-medium">{permission.name}</div>
                                    <div className="text-xs text-muted-foreground">{permission.description}</div>
                                  </div>
                                </div>
                                <Switch
                                  checked={selectedUser.permissions.includes(permission.id)}
                                  onCheckedChange={() => toggleUserPermission(selectedUser.id, permission.id)}
                                />
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex gap-2 pt-3 border-t">
                          <Button variant="outline" size="sm" className="flex-1">
                            <Edit className="w-4 h-4 mr-2" />
                            Edit
                          </Button>
                          <Button variant="destructive" size="sm">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </ScrollArea>
                  ) : (
                    <div className="text-center text-muted-foreground py-8">
                      <User className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p>Select a user to view details</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Role Management Tab */}
          <TabsContent value="roles" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">Manage User Roles</h3>
              <Button>
                <UserPlus className="w-4 h-4 mr-2" />
                Create Role
              </Button>
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {roles.map(role => (
                <Card key={role.id}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${role.color}`} />
                        {role.name}
                      </div>
                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="text-sm text-muted-foreground">
                        {role.permissions.length} permissions
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {role.permissions.slice(0, 3).map(permission => (
                          <Badge key={permission.id} variant="outline" className="text-xs">
                            {permission.name}
                          </Badge>
                        ))}
                        {role.permissions.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{role.permissions.length - 3} more
                          </Badge>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {users.filter(u => u.role === role.id).length} users assigned
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Permissions Tab */}
          <TabsContent value="permissions" className="space-y-4">
            <div className="grid gap-4">
              {['streaming', 'interaction', 'moderation', 'admin'].map(category => (
                <Card key={category}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 capitalize">
                      {getCategoryIcon(category)}
                      {category} Permissions
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-3 md:grid-cols-2">
                      {defaultPermissions
                        .filter(p => p.category === category)
                        .map(permission => (
                          <div key={permission.id} className="flex items-start gap-3 p-3 border rounded">
                            <CheckCircle className="w-5 h-5 text-green-500 mt-0.5" />
                            <div>
                              <div className="font-medium">{permission.name}</div>
                              <div className="text-sm text-muted-foreground">{permission.description}</div>
                              <div className="text-xs text-muted-foreground mt-1">
                                Used by {roles.filter(r => r.permissions.some(p => p.id === permission.id)).length} roles
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Themes & UI Tab */}
          <TabsContent value="themes" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              {/* Theme Presets */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Palette className="w-5 h-5" />
                    Theme Presets
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-3">
                    {presetThemes.map((preset) => (
                      <div
                        key={preset.name}
                        className={`p-4 border rounded-lg cursor-pointer transition-all ${
                          theme.name === preset.name ? 'border-primary bg-primary/5' : 'border-border hover:bg-muted/50'
                        }`}
                        onClick={() => applyThemePreset(preset)}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">{preset.name}</span>
                          {theme.name === preset.name && (
                            <CheckCircle className="w-4 h-4 text-primary" />
                          )}
                        </div>
                        <div className="flex gap-2">
                          <div 
                            className="w-6 h-6 rounded border"
                            style={{ backgroundColor: preset.primaryColor }}
                          />
                          <div 
                            className="w-6 h-6 rounded border"
                            style={{ backgroundColor: preset.secondaryColor }}
                          />
                          <div 
                            className="w-6 h-6 rounded border"
                            style={{ backgroundColor: preset.accentColor }}
                          />
                          <div 
                            className="w-6 h-6 rounded border"
                            style={{ backgroundColor: preset.backgroundColor }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <Button onClick={() => speak('Theme applied successfully', 'welcome')} className="w-full">
                    <Sparkles className="w-4 h-4 mr-2" />
                    Apply Selected Theme
                  </Button>
                </CardContent>
              </Card>

              {/* Custom Color Picker */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Eye className="w-5 h-5" />
                    Custom Colors
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label>Primary Color</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          type="color"
                          value={customColors.primary}
                          onChange={(e) => setCustomColors({...customColors, primary: e.target.value})}
                          className="w-12 h-8 p-1 border rounded"
                        />
                        <Input
                          value={customColors.primary}
                          onChange={(e) => setCustomColors({...customColors, primary: e.target.value})}
                          className="w-20 text-xs"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <Label>Secondary Color</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          type="color"
                          value={customColors.secondary}
                          onChange={(e) => setCustomColors({...customColors, secondary: e.target.value})}
                          className="w-12 h-8 p-1 border rounded"
                        />
                        <Input
                          value={customColors.secondary}
                          onChange={(e) => setCustomColors({...customColors, secondary: e.target.value})}
                          className="w-20 text-xs"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <Label>Background</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          type="color"
                          value={customColors.background}
                          onChange={(e) => setCustomColors({...customColors, background: e.target.value})}
                          className="w-12 h-8 p-1 border rounded"
                        />
                        <Input
                          value={customColors.background}
                          onChange={(e) => setCustomColors({...customColors, background: e.target.value})}
                          className="w-20 text-xs"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <Label>Accent Color</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          type="color"
                          value={customColors.accent}
                          onChange={(e) => setCustomColors({...customColors, accent: e.target.value})}
                          className="w-12 h-8 p-1 border rounded"
                        />
                        <Input
                          value={customColors.accent}
                          onChange={(e) => setCustomColors({...customColors, accent: e.target.value})}
                          className="w-20 text-xs"
                        />
                      </div>
                    </div>
                  </div>

                  <Button onClick={applyCustomTheme} className="w-full">
                    <Zap className="w-4 h-4 mr-2" />
                    Apply Custom Colors
                  </Button>

                  {/* Preview */}
                  <div className="p-4 rounded-lg border" style={{
                    backgroundColor: customColors.background,
                    color: '#ffffff',
                    borderColor: customColors.primary
                  }}>
                    <div className="text-sm font-medium mb-2">Theme Preview</div>
                    <div className="flex gap-2">
                      <div 
                        className="px-3 py-1 rounded text-white text-xs"
                        style={{ backgroundColor: customColors.primary }}
                      >
                        Primary
                      </div>
                      <div 
                        className="px-3 py-1 rounded text-white text-xs"
                        style={{ backgroundColor: customColors.secondary }}
                      >
                        Secondary
                      </div>
                      <div 
                        className="px-3 py-1 rounded text-black text-xs"
                        style={{ backgroundColor: customColors.accent }}
                      >
                        Accent
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Content Assets Tab */}
          <TabsContent value="content" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              {/* Asset Upload */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Upload className="w-5 h-5" />
                    Upload Assets
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div>
                      <Label>Logo/Branding</Label>
                      <div className="flex items-center gap-2 mt-1">
                        <Input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleFileUpload(e, 'logo')}
                          className="flex-1"
                        />
                        <Button variant="outline" size="sm">
                          <Image className="w-4 h-4" />
                        </Button>
                      </div>
                      {assets.logo && (
                        <div className="mt-2 p-2 bg-muted rounded">
                          <img src={assets.logo} alt="Logo" className="max-h-12" />
                        </div>
                      )}
                    </div>

                    <div>
                      <Label>Background Image</Label>
                      <div className="flex items-center gap-2 mt-1">
                        <Input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleFileUpload(e, 'backgroundImage')}
                          className="flex-1"
                        />
                        <Button variant="outline" size="sm">
                          <Monitor className="w-4 h-4" />
                        </Button>
                      </div>
                      {assets.backgroundImage && (
                        <div className="mt-2 p-2 bg-muted rounded">
                          <img src={assets.backgroundImage} alt="Background" className="max-h-20 w-full object-cover rounded" />
                        </div>
                      )}
                    </div>

                    <div>
                      <Label>Empty Box Placeholder</Label>
                      <div className="flex items-center gap-2 mt-1">
                        <Input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleFileUpload(e, 'emptyBoxImage')}
                          className="flex-1"
                        />
                        <Button variant="outline" size="sm">
                          <Video className="w-4 h-4" />
                        </Button>
                      </div>
                      {assets.emptyBoxImage && (
                        <div className="mt-2 p-2 bg-muted rounded">
                          <img src={assets.emptyBoxImage} alt="Empty box" className="max-h-16" />
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <Button className="w-full">
                      <Save className="w-4 h-4 mr-2" />
                      Save All Assets
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Current Assets */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="w-5 h-5" />
                    Current Assets
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-80">
                    <div className="space-y-3">
                      <div className="p-3 border rounded">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">Logo</span>
                          <Badge variant={assets.logo ? "default" : "secondary"}>
                            {assets.logo ? "Uploaded" : "Default"}
                          </Badge>
                        </div>
                        {assets.logo ? (
                          <img src={assets.logo} alt="Logo" className="max-h-8" />
                        ) : (
                          <div className="text-sm text-muted-foreground">No custom logo uploaded</div>
                        )}
                      </div>

                      <div className="p-3 border rounded">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">Background</span>
                          <Badge variant={assets.backgroundImage ? "default" : "secondary"}>
                            {assets.backgroundImage ? "Custom" : "Default"}
                          </Badge>
                        </div>
                        {assets.backgroundImage ? (
                          <img src={assets.backgroundImage} alt="Background" className="max-h-16 w-full object-cover rounded" />
                        ) : (
                          <div className="text-sm text-muted-foreground">Using default gradient background</div>
                        )}
                      </div>

                      <div className="p-3 border rounded">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">Empty Box Placeholder</span>
                          <Badge variant={assets.emptyBoxImage ? "default" : "secondary"}>
                            {assets.emptyBoxImage ? "Custom" : "Default"}
                          </Badge>
                        </div>
                        {assets.emptyBoxImage ? (
                          <img src={assets.emptyBoxImage} alt="Empty box" className="max-h-12" />
                        ) : (
                          <div className="text-sm text-muted-foreground">Using default empty state</div>
                        )}
                      </div>

                      <div className="p-3 border rounded">
                        <div className="font-medium mb-2">Animation Settings</div>
                        <div className="text-sm space-y-1">
                          <div>Entry: <Badge variant="outline">{assets.animations.entry}</Badge></div>
                          <div>Exit: <Badge variant="outline">{assets.animations.exit}</Badge></div>
                          <div>Idle: <Badge variant="outline">{assets.animations.idle}</Badge></div>
                        </div>
                      </div>
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Voice & Audio Tab */}
          <TabsContent value="voice" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              {/* Voice Presets */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Mic className="w-5 h-5" />
                    Big Brother Voice Presets
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    {voicePresets.map((preset) => (
                      <div
                        key={preset.id}
                        className={`p-3 border rounded-lg cursor-pointer transition-all ${
                          selectedVoicePreset === preset.id ? 'border-primary bg-primary/5' : 'border-border hover:bg-muted/50'
                        }`}
                        onClick={() => handleVoicePresetChange(preset.id)}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium">{preset.name}</span>
                          {selectedVoicePreset === preset.id && (
                            <CheckCircle className="w-4 h-4 text-primary" />
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground mb-2">{preset.description}</div>
                        <div className="flex items-center gap-2 text-xs">
                          <Badge variant="outline">Speed: {preset.speed}x</Badge>
                          <Badge variant="outline">Pitch: {preset.pitch}</Badge>
                          {preset.effects.echo && <Badge variant="outline">Echo</Badge>}
                          {preset.effects.reverb && <Badge variant="outline">Reverb</Badge>}
                          {preset.effects.distortion && <Badge variant="outline">Distortion</Badge>}
                        </div>
                      </div>
                    ))}
                  </div>

                  <Button 
                    onClick={() => testVoice('This is Big Brother. Housemates, please gather in the lounge.')} 
                    disabled={isTestingVoice}
                    className="w-full"
                  >
                    {isTestingVoice ? (
                      <>
                        <AudioWaveform className="w-4 h-4 mr-2 animate-pulse" />
                        Testing Voice...
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 mr-2" />
                        Test Voice
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {/* Voice Customization */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Volume2 className="w-5 h-5" />
                    Voice Customization
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label>Voice Effects Enabled</Label>
                      <Switch
                        checked={voice.enabled}
                        onCheckedChange={(checked) => setVoice({...voice, enabled: checked})}
                      />
                    </div>

                    <div>
                      <Label>Speed: {voice.speed}x</Label>
                      <Slider
                        value={[voice.speed]}
                        onValueChange={(values) => setVoice({...voice, speed: values[0]})}
                        max={2}
                        min={0.5}
                        step={0.1}
                        className="mt-2"
                      />
                    </div>

                    <div>
                      <Label>Pitch: {voice.pitch}</Label>
                      <Slider
                        value={[voice.pitch]}
                        onValueChange={(values) => setVoice({...voice, pitch: values[0]})}
                        max={2}
                        min={0.3}
                        step={0.1}
                        className="mt-2"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Audio Effects</Label>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Echo</span>
                          <Switch
                            checked={voice.effects.echo}
                            onCheckedChange={(checked) => setVoice({
                              ...voice, 
                              effects: {...voice.effects, echo: checked}
                            })}
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Reverb</span>
                          <Switch
                            checked={voice.effects.reverb}
                            onCheckedChange={(checked) => setVoice({
                              ...voice, 
                              effects: {...voice.effects, reverb: checked}
                            })}
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Distortion</span>
                          <Switch
                            checked={voice.effects.distortion}
                            onCheckedChange={(checked) => setVoice({
                              ...voice, 
                              effects: {...voice.effects, distortion: checked}
                            })}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t space-y-2">
                    <Button 
                      variant="outline" 
                      onClick={() => testVoice(voice.phrases.welcome)} 
                      className="w-full"
                    >
                      Test Welcome Message
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => testVoice(voice.phrases.eviction)} 
                      className="w-full"
                    >
                      Test Eviction Announcement
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => testVoice(voice.phrases.task)} 
                      className="w-full"
                    >
                      Test Task Announcement
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Voice Phrases */}
            <Card>
              <CardHeader>
                <CardTitle>Custom Voice Phrases</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <Label>Welcome Message</Label>
                    <Textarea
                      value={voice.phrases.welcome}
                      onChange={(e) => setVoice({
                        ...voice,
                        phrases: {...voice.phrases, welcome: e.target.value}
                      })}
                      placeholder="Welcome to the Big Brother house..."
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label>Eviction Announcement</Label>
                    <Textarea
                      value={voice.phrases.eviction}
                      onChange={(e) => setVoice({
                        ...voice,
                        phrases: {...voice.phrases, eviction: e.target.value}
                      })}
                      placeholder="The votes have been counted..."
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label>Task Announcement</Label>
                    <Textarea
                      value={voice.phrases.task}
                      onChange={(e) => setVoice({
                        ...voice,
                        phrases: {...voice.phrases, task: e.target.value}
                      })}
                      placeholder="Housemates, please gather..."
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label>Warning Message</Label>
                    <Textarea
                      value={voice.phrases.warning}
                      onChange={(e) => setVoice({
                        ...voice,
                        phrases: {...voice.phrases, warning: e.target.value}
                      })}
                      placeholder="This is an official warning..."
                      className="mt-1"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Streaming Servers Tab */}
          <TabsContent value="servers" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              {/* Server Selection */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Server className="w-5 h-5" />
                    Streaming Server Configuration
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Server Provider</Label>
                    <Select 
                      value={server.provider} 
                      onValueChange={(value) => setServer({...server, provider: value as any})}
                    >
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {streamingProviders.map(provider => (
                          <SelectItem key={provider.id} value={provider.id}>
                            {provider.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <div className="text-sm text-muted-foreground mt-1">
                      {streamingProviders.find(p => p.id === server.provider)?.description}
                    </div>
                  </div>

                  <div>
                    <Label>Server URL</Label>
                    <Input
                      value={server.url}
                      onChange={(e) => setServer({...server, url: e.target.value})}
                      placeholder="wss://your-server.com"
                      className="mt-1"
                    />
                  </div>

                  <div>
                    <Label>API Key</Label>
                    <div className="flex items-center gap-2 mt-1">
                      <Input
                        type="password"
                        value={server.apiKey}
                        onChange={(e) => setServer({...server, apiKey: e.target.value})}
                        placeholder="Your API key"
                        className="flex-1"
                      />
                      <Button variant="outline" size="sm">
                        <Key className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div>
                    <Label>Secret Key</Label>
                    <div className="flex items-center gap-2 mt-1">
                      <Input
                        type="password"
                        value={server.secret}
                        onChange={(e) => setServer({...server, secret: e.target.value})}
                        placeholder="Your secret key"
                        className="flex-1"
                      />
                      <Button variant="outline" size="sm">
                        <Lock className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div>
                    <Label>Region</Label>
                    <Select 
                      value={server.region} 
                      onValueChange={(value) => setServer({...server, region: value})}
                    >
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="us-east-1">US East (N. Virginia)</SelectItem>
                        <SelectItem value="us-west-2">US West (Oregon)</SelectItem>
                        <SelectItem value="eu-west-1">Europe (Ireland)</SelectItem>
                        <SelectItem value="ap-southeast-1">Asia Pacific (Singapore)</SelectItem>
                        <SelectItem value="ap-south-1">Asia Pacific (Mumbai)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex gap-2 pt-4 border-t">
                    <Button className="flex-1">
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Test Connection
                    </Button>
                    <Button className="flex-1">
                      <Save className="w-4 h-4 mr-2" />
                      Save Config
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Server Status */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Wifi className="w-5 h-5" />
                    Server Status
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span>Connection Status</span>
                      <Badge variant="default" className="bg-green-500">
                        <div className="w-2 h-2 bg-white rounded-full mr-1" />
                        Connected
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between">
                      <span>Server Latency</span>
                      <Badge variant="outline">23ms</Badge>
                    </div>

                    <div className="flex items-center justify-between">
                      <span>Active Streams</span>
                      <Badge variant="outline">6 streams</Badge>
                    </div>

                    <div className="flex items-center justify-between">
                      <span>Server Load</span>
                      <Badge variant="outline">12% CPU</Badge>
                    </div>

                    <div className="flex items-center justify-between">
                      <span>Bandwidth Usage</span>
                      <Badge variant="outline">2.4 MB/s</Badge>
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <div className="text-sm font-medium mb-2">Recent Activity</div>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-green-400 rounded-full" />
                        <span>Stream started: Teez</span>
                        <span className="text-muted-foreground">2m ago</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-blue-400 rounded-full" />
                        <span>User joined: Sarah_Lagos</span>
                        <span className="text-muted-foreground">5m ago</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-yellow-400 rounded-full" />
                        <span>Quality adjusted: Auto HD</span>
                        <span className="text-muted-foreground">8m ago</span>
                      </div>
                    </div>
                  </div>

                  <Button variant="outline" className="w-full">
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Refresh Status
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Animations & Effects Tab */}
          <TabsContent value="animations" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5" />
                    Participant Box Animations
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Entry Animation</Label>
                    <Select 
                      value={assets.animations.entry}
                      onValueChange={(value) => setAssets({
                        ...assets,
                        animations: {...assets.animations, entry: value}
                      })}
                    >
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="fadeIn">Fade In</SelectItem>
                        <SelectItem value="slideIn">Slide In</SelectItem>
                        <SelectItem value="zoomIn">Zoom In</SelectItem>
                        <SelectItem value="bounceIn">Bounce In</SelectItem>
                        <SelectItem value="flipIn">Flip In</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Exit Animation</Label>
                    <Select 
                      value={assets.animations.exit}
                      onValueChange={(value) => setAssets({
                        ...assets,
                        animations: {...assets.animations, exit: value}
                      })}
                    >
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="fadeOut">Fade Out</SelectItem>
                        <SelectItem value="slideOut">Slide Out</SelectItem>
                        <SelectItem value="zoomOut">Zoom Out</SelectItem>
                        <SelectItem value="bounceOut">Bounce Out</SelectItem>
                        <SelectItem value="flipOut">Flip Out</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Idle Animation</Label>
                    <Select 
                      value={assets.animations.idle}
                      onValueChange={(value) => setAssets({
                        ...assets,
                        animations: {...assets.animations, idle: value}
                      })}
                    >
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        <SelectItem value="pulse">Pulse</SelectItem>
                        <SelectItem value="glow">Glow</SelectItem>
                        <SelectItem value="shake">Shake</SelectItem>
                        <SelectItem value="float">Float</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="pt-4 border-t">
                    <Button className="w-full">
                      <Play className="w-4 h-4 mr-2" />
                      Preview Animations
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Layers className="w-5 h-5" />
                    Special Effects
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Particle Effects</div>
                        <div className="text-sm text-muted-foreground">Floating hearts, stars, etc.</div>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Screen Transitions</div>
                        <div className="text-sm text-muted-foreground">Smooth screen changes</div>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Vote Animations</div>
                        <div className="text-sm text-muted-foreground">Animated voting results</div>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Eviction Effects</div>
                        <div className="text-sm text-muted-foreground">Dramatic eviction visuals</div>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Sound Effects</div>
                        <div className="text-sm text-muted-foreground">Button clicks, notifications</div>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <div className="space-y-2">
                      <Button variant="outline" className="w-full">
                        <Music className="w-4 h-4 mr-2" />
                        Upload Sound Effects
                      </Button>
                      <Button variant="outline" className="w-full">
                        <Download className="w-4 h-4 mr-2" />
                        Export Effects Pack
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Data Management Tab */}
          <TabsContent value="storage" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="w-5 h-5" />
                    Content Storage
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span>User Data</span>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">2.4 MB</Badge>
                        <Button variant="outline" size="sm">
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span>Video Assets</span>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">156 MB</Badge>
                        <Button variant="outline" size="sm">
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span>Audio Files</span>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">23 MB</Badge>
                        <Button variant="outline" size="sm">
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span>Chat Logs</span>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">890 KB</Badge>
                        <Button variant="outline" size="sm">
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span>Voting Data</span>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">124 KB</Badge>
                        <Button variant="outline" size="sm">
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t space-y-2">
                    <Button className="w-full">
                      <Download className="w-4 h-4 mr-2" />
                      Export All Data
                    </Button>
                    <Button variant="destructive" className="w-full">
                      <AlertTriangle className="w-4 h-4 mr-2" />
                      Clear All Data
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="w-5 h-5" />
                    System Backup
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div>
                      <div className="font-medium mb-1">Last Backup</div>
                      <div className="text-sm text-muted-foreground">Today, 3:24 AM</div>
                    </div>

                    <div>
                      <div className="font-medium mb-1">Backup Size</div>
                      <div className="text-sm text-muted-foreground">247 MB</div>
                    </div>

                    <div>
                      <div className="font-medium mb-1">Auto Backup</div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Every 6 hours</span>
                        <Switch defaultChecked />
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t space-y-2">
                    <Button className="w-full">
                      <Save className="w-4 h-4 mr-2" />
                      Create Backup Now
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Upload className="w-4 h-4 mr-2" />
                      Restore from Backup
                    </Button>
                    <Button variant="outline" className="w-full">
                      <FileText className="w-4 h-4 mr-2" />
                      View Backup History
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
