import { useRef, useEffect, useState } from 'react';
import { Mic, MicOff, Camera, CameraOff, Crown, Star, Volume2, VolumeX } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useAdminTheme } from './AdminThemeProvider';

interface Participant {
  id: string;
  name: string;
  videoEnabled: boolean;
  audioEnabled: boolean;
  isLocal: boolean;
  stream?: MediaStream;
  role?: string;
  isVIP?: boolean;
}

interface EnhancedVideoTileProps {
  participant: Participant;
  isMain?: boolean;
  className?: string;
  showControls?: boolean;
  onMute?: () => void;
  onVideoToggle?: () => void;
}

export function EnhancedVideoTile({ 
  participant, 
  isMain = false, 
  className = "",
  showControls = false,
  onMute,
  onVideoToggle
}: EnhancedVideoTileProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [animationClass, setAnimationClass] = useState('');
  const { theme, assets, voice } = useAdminTheme();

  useEffect(() => {
    if (videoRef.current && participant.stream) {
      videoRef.current.srcObject = participant.stream;
      setIsLoading(false);
    }
  }, [participant.stream]);

  useEffect(() => {
    // Apply entry animation
    setAnimationClass(getAnimationClass(assets.animations.entry));
    
    // Apply idle animation after entry
    const timer = setTimeout(() => {
      setAnimationClass(getAnimationClass(assets.animations.idle));
    }, 1000);

    return () => clearTimeout(timer);
  }, [assets.animations]);

  const getAnimationClass = (animation: string) => {
    switch (animation) {
      case 'fadeIn': return 'animate-in fade-in duration-500';
      case 'slideIn': return 'animate-in slide-in-from-bottom-4 duration-500';
      case 'zoomIn': return 'animate-in zoom-in-95 duration-500';
      case 'bounceIn': return 'animate-bounce';
      case 'flipIn': return 'animate-in flip-in-x duration-500';
      case 'pulse': return 'animate-pulse';
      case 'glow': return 'animate-pulse shadow-lg shadow-primary/50';
      case 'shake': return 'animate-bounce';
      case 'float': return 'animate-pulse';
      default: return '';
    }
  };

  const getRoleIcon = () => {
    if (participant.isVIP) return <Crown className="w-3 h-3 text-yellow-400" />;
    if (participant.role === 'moderator') return <Star className="w-3 h-3 text-blue-400" />;
    return null;
  };

  const getRoleBadgeColor = () => {
    if (participant.isVIP) return 'bg-yellow-500';
    if (participant.role === 'moderator') return 'bg-blue-500';
    if (participant.role === 'participant') return 'bg-green-500';
    return 'bg-gray-500';
  };

  return (
    <div 
      className={`relative rounded-lg overflow-hidden border-2 transition-all duration-300 ${
        isMain ? 'border-primary shadow-lg shadow-primary/20' : 'border-gray-600 hover:border-gray-400'
      } ${animationClass} ${className}`}
      style={{
        background: assets.backgroundImage 
          ? `url(${assets.backgroundImage}) center/cover` 
          : `linear-gradient(135deg, ${theme.gradientFrom}, ${theme.gradientTo})`
      }}
    >
      {/* Video Element */}
      {participant.videoEnabled && participant.stream ? (
        <video
          ref={videoRef}
          autoPlay
          muted
          playsInline
          className={`w-full h-full object-cover ${isMain ? 'min-h-[400px]' : 'h-32'}`}
        />
      ) : (
        <div className={`w-full ${isMain ? 'min-h-[400px]' : 'h-32'} flex items-center justify-center`}>
          {assets.emptyBoxImage ? (
            <img 
              src={assets.emptyBoxImage} 
              alt="No video" 
              className="w-16 h-16 opacity-50"
            />
          ) : (
            <div className="flex flex-col items-center gap-2">
              <div 
                className="w-12 h-12 rounded-full flex items-center justify-center text-xl font-bold"
                style={{ backgroundColor: theme.primaryColor, color: theme.textColor }}
              >
                {participant.name.charAt(0).toUpperCase()}
              </div>
              <CameraOff className="w-6 h-6 text-gray-400" />
            </div>
          )}
        </div>
      )}

      {/* Loading Overlay */}
      {isLoading && (
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
          <div className="flex flex-col items-center gap-2">
            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            <span className="text-sm text-white">Connecting...</span>
          </div>
        </div>
      )}

      {/* Participant Info Overlay */}
      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span 
              className="font-medium text-sm"
              style={{ color: theme.textColor }}
            >
              {participant.name}
            </span>
            {getRoleIcon()}
            {participant.isLocal && (
              <Badge variant="outline" className="text-xs">You</Badge>
            )}
          </div>
          
          <div className="flex items-center gap-1">
            <div className={`p-1 rounded ${participant.audioEnabled ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
              {participant.audioEnabled ? (
                <Mic className="w-3 h-3 text-green-400" />
              ) : (
                <MicOff className="w-3 h-3 text-red-400" />
              )}
            </div>
            <div className={`p-1 rounded ${participant.videoEnabled ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
              {participant.videoEnabled ? (
                <Camera className="w-3 h-3 text-green-400" />
              ) : (
                <CameraOff className="w-3 h-3 text-red-400" />
              )}
            </div>
          </div>
        </div>

        {/* Role Badge */}
        {(participant.role || participant.isVIP) && (
          <div className="mt-1">
            <Badge 
              className={`text-white text-xs ${getRoleBadgeColor()}`}
            >
              {participant.isVIP ? 'VIP' : participant.role}
            </Badge>
          </div>
        )}
      </div>

      {/* Control Buttons (for moderators) */}
      {showControls && !participant.isLocal && (
        <div className="absolute top-2 right-2 flex gap-1">
          <button
            onClick={onMute}
            className="p-1 bg-black/50 rounded hover:bg-black/70 transition-colors"
            title="Toggle Mute"
          >
            {participant.audioEnabled ? (
              <Volume2 className="w-3 h-3 text-white" />
            ) : (
              <VolumeX className="w-3 h-3 text-red-400" />
            )}
          </button>
          <button
            onClick={onVideoToggle}
            className="p-1 bg-black/50 rounded hover:bg-black/70 transition-colors"
            title="Toggle Video"
          >
            {participant.videoEnabled ? (
              <Camera className="w-3 h-3 text-white" />
            ) : (
              <CameraOff className="w-3 h-3 text-red-400" />
            )}
          </button>
        </div>
      )}

      {/* Main Participant Indicator */}
      {isMain && (
        <div className="absolute top-2 left-2">
          <Badge 
            className="text-white text-xs"
            style={{ backgroundColor: theme.primaryColor }}
          >
            Main Screen
          </Badge>
        </div>
      )}

      {/* Live Status Indicator */}
      <div className="absolute top-2 left-2">
        <div className="flex items-center gap-1">
          <div className={`w-2 h-2 rounded-full ${
            participant.videoEnabled || participant.audioEnabled ? 'bg-green-400 animate-pulse' : 'bg-gray-400'
          }`} />
          {(participant.videoEnabled || participant.audioEnabled) && (
            <span className="text-xs text-white bg-black/50 px-1 rounded">LIVE</span>
          )}
        </div>
      </div>

      {/* Special Effects Border for VIP/Important participants */}
      {(participant.isVIP || isMain) && (
        <div 
          className="absolute inset-0 pointer-events-none border-2 rounded-lg animate-pulse"
          style={{ borderColor: theme.accentColor }}
        />
      )}
    </div>
  );
}
