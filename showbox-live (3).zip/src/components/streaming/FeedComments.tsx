import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Send, 
  Heart, 
  Reply, 
  MoreHorizontal, 
  Flag, 
  Trash2,
  User,
  Pin,
  Shield
} from 'lucide-react';

interface Comment {
  id: string;
  author: {
    name: string;
    avatar?: string;
    verified?: boolean;
    role?: 'admin' | 'moderator' | 'user';
  };
  content: string;
  timestamp: Date;
  likes: number;
  isLiked: boolean;
  replies: Comment[];
  isPinned?: boolean;
  isEdited?: boolean;
}

interface FeedCommentsProps {
  postId: string;
  user: { name: string; isAuth: boolean } | null;
  onAuthRequired: () => void;
  isOpen: boolean;
  onClose: () => void;
}

const mockComments: Comment[] = [
  {
    id: '1',
    author: { name: 'BigBro_Mod', verified: true, role: 'moderator' },
    content: 'Welcome to the community feeds! Remember to follow our guidelines.',
    timestamp: new Date(Date.now() - 7200000),
    likes: 45,
    isLiked: false,
    replies: [],
    isPinned: true
  },
  {
    id: '2',
    author: { name: 'Sarah_Lagos', verified: false, role: 'user' },
    content: 'This is so cool! Love the new feeds feature 🎉',
    timestamp: new Date(Date.now() - 3600000),
    likes: 12,
    isLiked: true,
    replies: [
      {
        id: '2-1',
        author: { name: 'TeezFan', verified: false, role: 'user' },
        content: 'Totally agree! Can\'t wait to share my own videos',
        timestamp: new Date(Date.now() - 3300000),
        likes: 3,
        isLiked: false,
        replies: []
      }
    ]
  },
  {
    id: '3',
    author: { name: 'VideoCreator', verified: true, role: 'user' },
    content: 'Great content! How do I get verified on here?',
    timestamp: new Date(Date.now() - 1800000),
    likes: 8,
    isLiked: false,
    replies: []
  }
];

export function FeedComments({ postId, user, onAuthRequired, isOpen, onClose }: FeedCommentsProps) {
  const [comments, setComments] = useState<Comment[]>(mockComments);
  const [newComment, setNewComment] = useState('');
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen && scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [isOpen, comments]);

  const handleSubmitComment = () => {
    if (!user?.isAuth) {
      onAuthRequired();
      return;
    }

    if (!newComment.trim()) return;

    const comment: Comment = {
      id: Date.now().toString(),
      author: { 
        name: user.name, 
        verified: false, 
        role: 'user' 
      },
      content: newComment,
      timestamp: new Date(),
      likes: 0,
      isLiked: false,
      replies: []
    };

    setComments(prev => [...prev, comment]);
    setNewComment('');
  };

  const handleSubmitReply = (parentId: string) => {
    if (!user?.isAuth) {
      onAuthRequired();
      return;
    }

    if (!replyText.trim()) return;

    const reply: Comment = {
      id: `${parentId}-${Date.now()}`,
      author: { 
        name: user.name, 
        verified: false, 
        role: 'user' 
      },
      content: replyText,
      timestamp: new Date(),
      likes: 0,
      isLiked: false,
      replies: []
    };

    setComments(prev => prev.map(comment => 
      comment.id === parentId 
        ? { ...comment, replies: [...comment.replies, reply] }
        : comment
    ));
    setReplyText('');
    setReplyingTo(null);
  };

  const handleLikeComment = (commentId: string, isReply = false, parentId?: string) => {
    if (!user?.isAuth) {
      onAuthRequired();
      return;
    }

    if (isReply && parentId) {
      setComments(prev => prev.map(comment => {
        if (comment.id === parentId) {
          return {
            ...comment,
            replies: comment.replies.map(reply => 
              reply.id === commentId 
                ? { 
                    ...reply, 
                    isLiked: !reply.isLiked,
                    likes: reply.isLiked ? reply.likes - 1 : reply.likes + 1
                  }
                : reply
            )
          };
        }
        return comment;
      }));
    } else {
      setComments(prev => prev.map(comment => 
        comment.id === commentId 
          ? { 
              ...comment, 
              isLiked: !comment.isLiked,
              likes: comment.isLiked ? comment.likes - 1 : comment.likes + 1
            }
          : comment
      ));
    }
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (hours < 1) return 'Just now';
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  };

  const getRoleIcon = (role?: string) => {
    switch (role) {
      case 'admin': return <Shield className="w-3 h-3 text-red-500" />;
      case 'moderator': return <Shield className="w-3 h-3 text-blue-500" />;
      default: return null;
    }
  };

  const getRoleBadgeColor = (role?: string) => {
    switch (role) {
      case 'admin': return 'bg-red-500';
      case 'moderator': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gray-900 border border-gray-700 rounded-lg w-full max-w-2xl h-[600px] flex flex-col text-white">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <h3 className="font-semibold">Comments ({comments.length})</h3>
          <Button variant="ghost" size="sm" onClick={onClose}>
            ×
          </Button>
        </div>

        {/* Comments List */}
        <ScrollArea ref={scrollAreaRef} className="flex-1 p-4">
          <div className="space-y-4">
            {comments.map((comment) => (
              <div key={comment.id} className="space-y-3">
                {/* Main Comment */}
                <div className={`flex gap-3 ${comment.isPinned ? 'bg-blue-500/10 p-3 rounded-lg border border-blue-500/20' : ''}`}>
                  <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center flex-shrink-0">
                    <User className="w-4 h-4" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-sm">{comment.author.name}</span>
                      {comment.author.verified && (
                        <div className="w-3 h-3 bg-blue-500 rounded-full flex items-center justify-center">
                          <span className="text-white text-xs">✓</span>
                        </div>
                      )}
                      {getRoleIcon(comment.author.role)}
                      {comment.isPinned && <Pin className="w-3 h-3 text-blue-500" />}
                      <span className="text-xs text-gray-400">{formatTime(comment.timestamp)}</span>
                      {comment.isEdited && <span className="text-xs text-gray-400">(edited)</span>}
                    </div>
                    
                    <p className="text-sm mb-2">{comment.content}</p>
                    
                    <div className="flex items-center gap-3 text-xs">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleLikeComment(comment.id)}
                        className={`p-1 h-auto ${comment.isLiked ? 'text-red-500' : 'text-gray-400'}`}
                      >
                        <Heart className="w-3 h-3" fill={comment.isLiked ? 'currentColor' : 'none'} />
                        <span className="ml-1">{comment.likes}</span>
                      </Button>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setReplyingTo(comment.id)}
                        className="p-1 h-auto text-gray-400"
                      >
                        <Reply className="w-3 h-3" />
                        <span className="ml-1">Reply</span>
                      </Button>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        className="p-1 h-auto text-gray-400"
                      >
                        <Flag className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Replies */}
                {comment.replies.length > 0 && (
                  <div className="ml-11 space-y-3">
                    {comment.replies.map((reply) => (
                      <div key={reply.id} className="flex gap-3">
                        <div className="w-6 h-6 bg-gradient-to-br from-gray-600 to-gray-700 rounded-full flex items-center justify-center flex-shrink-0">
                          <User className="w-3 h-3" />
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium text-sm">{reply.author.name}</span>
                            {reply.author.verified && (
                              <div className="w-3 h-3 bg-blue-500 rounded-full flex items-center justify-center">
                                <span className="text-white text-xs">✓</span>
                              </div>
                            )}
                            <span className="text-xs text-gray-400">{formatTime(reply.timestamp)}</span>
                          </div>
                          
                          <p className="text-sm mb-2">{reply.content}</p>
                          
                          <div className="flex items-center gap-3 text-xs">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleLikeComment(reply.id, true, comment.id)}
                              className={`p-1 h-auto ${reply.isLiked ? 'text-red-500' : 'text-gray-400'}`}
                            >
                              <Heart className="w-3 h-3" fill={reply.isLiked ? 'currentColor' : 'none'} />
                              <span className="ml-1">{reply.likes}</span>
                            </Button>
                            
                            <Button
                              variant="ghost"
                              size="sm"
                              className="p-1 h-auto text-gray-400"
                            >
                              <Flag className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Reply Input */}
                {replyingTo === comment.id && (
                  <div className="ml-11 flex gap-2">
                    <Input
                      value={replyText}
                      onChange={(e) => setReplyText(e.target.value)}
                      placeholder="Write a reply..."
                      className="bg-gray-800 border-gray-600 text-sm"
                      onKeyPress={(e) => e.key === 'Enter' && handleSubmitReply(comment.id)}
                    />
                    <Button
                      size="sm"
                      onClick={() => handleSubmitReply(comment.id)}
                      disabled={!replyText.trim()}
                    >
                      <Send className="w-3 h-3" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setReplyingTo(null)}
                    >
                      Cancel
                    </Button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </ScrollArea>

        {/* Comment Input */}
        <div className="p-4 border-t border-gray-700">
          {user?.isAuth ? (
            <div className="flex gap-2">
              <Input
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Add a comment..."
                className="bg-gray-800 border-gray-600"
                onKeyPress={(e) => e.key === 'Enter' && handleSubmitComment()}
                maxLength={500}
              />
              <Button
                onClick={handleSubmitComment}
                disabled={!newComment.trim()}
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          ) : (
            <div className="text-center py-3">
              <p className="text-gray-400 mb-3">Sign up to join the conversation</p>
              <Button onClick={onAuthRequired} size="sm">
                Sign Up / Login
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
