import { Heart, MessageCircle } from "lucide-react";
import { useEffect, useState } from "react";

interface FloatingHeart {
  id: number;
  x: number;
  y: number;
}

interface FloatingComment {
  id: number;
  user: string;
  message: string;
  x: number;
  y: number;
}

interface FloatingInteractionsProps {
  hearts: FloatingHeart[];
  comments?: FloatingComment[];
}

export function FloatingInteractions({ hearts, comments = [] }: FloatingInteractionsProps) {
  const [displayComments, setDisplayComments] = useState<Array<FloatingComment & { timestamp: number }>>([]);

  // Manage floating comments lifecycle
  useEffect(() => {
    comments.forEach(comment => {
      const commentWithTimestamp = { ...comment, timestamp: Date.now() };
      setDisplayComments(prev => [...prev, commentWithTimestamp]);

      // Remove comment after 4 seconds
      setTimeout(() => {
        setDisplayComments(prev => prev.filter(c => c.id !== comment.id));
      }, 4000);
    });
  }, [comments]);

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {/* Floating Hearts */}
      {hearts.map((heart) => (
        <div
          key={heart.id}
          className="absolute floating-heart z-[1000]"
          style={{
            left: `${heart.x}px`,
            bottom: `${heart.y}px`,
          }}
        >
          <Heart 
            className="w-6 h-6 text-red-500 drop-shadow-lg" 
            fill="currentColor" 
          />
        </div>
      ))}

      {/* Floating Comments */}
      {displayComments.map((comment) => (
        <div
          key={comment.id}
          className="absolute floating-comment z-[1001]"
          style={{
            left: `${comment.x}%`,
            top: `${comment.y}%`,
          }}
        >
          <div className="bg-gray-900/95 backdrop-blur-sm rounded-full px-4 py-2 max-w-xs shadow-lg border border-white/20 text-white">
            <div className="flex items-center gap-2">
              <MessageCircle className="w-3 h-3 text-blue-400 flex-shrink-0" />
              <div className="min-w-0">
                <span className="text-xs font-medium text-blue-300 block truncate">
                  {comment.user}:
                </span>
                <span className="text-xs text-white block truncate">
                  {comment.message}
                </span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
