import React from 'react';
import { LiveKitRoom } from '@livekit/components-react';
import '@livekit/components-styles';

interface LiveKitProviderProps {
  children: React.ReactNode;
  serverUrl: string;
  token: string;
  roomName: string;
}

export function LiveKitProvider({ 
  children, 
  serverUrl, 
  token, 
  roomName 
}: LiveKitProviderProps) {
  return (
    <LiveKitRoom
      video={true}
      audio={true}
      token={token}
      serverUrl={serverUrl}
      data-lk-theme="default"
      style={{ height: '100vh' }}
      className="bg-black"
    >
      {children}
    </LiveKitRoom>
  );
}