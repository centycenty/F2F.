import { useParticipants } from '@livekit/components-react';
import { VideoTile } from './VideoTile';

export function LiveStreamGrid() {
  const participants = useParticipants();

  // If no participants, show placeholder
  if (participants.length === 0) {
    return (
      <div className="flex items-center justify-center h-full text-white">
        <div className="text-center">
          <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-2xl">📺</span>
          </div>
          <h3 className="text-lg font-medium mb-2">No Live Stream</h3>
          <p className="text-gray-400">Waiting for housemates to join...</p>
        </div>
      </div>
    );
  }

  const [mainParticipant, ...otherParticipants] = participants;

  return (
    <div className="relative h-full">
      {/* Main Participant - Full Screen */}
      <div className="absolute inset-0">
        <VideoTile participant={mainParticipant} isMain={true} />
      </div>

      {/* Other Participants - TikTok Style Stack */}
      <div className="absolute top-4 right-4 flex flex-col gap-2 z-10">
        {otherParticipants.map((participant) => (
          <div key={participant.sid} className="w-16 h-20 border-2 border-white/20 rounded-lg overflow-hidden">
            <VideoTile participant={participant} isMain={false} />
          </div>
        ))}
      </div>
    </div>
  );
}