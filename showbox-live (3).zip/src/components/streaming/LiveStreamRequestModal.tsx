import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Video, 
  Mic, 
  Clock, 
  User, 
  Send,
  CheckCircle,
  AlertTriangle,
  Info,
  X
} from 'lucide-react';

interface LiveStreamRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: { name: string; isAuth: boolean } | null;
  onAuthRequired: () => void;
  onRequestSubmitted: (request: StreamRequest) => void;
}

interface StreamRequest {
  id: string;
  userName: string;
  email: string;
  requestType: 'participant' | 'guest' | 'interview';
  reason: string;
  experience: string;
  availability: string;
  status: 'pending' | 'approved' | 'rejected';
  submittedAt: Date;
}

export function LiveStreamRequestModal({
  isOpen,
  onClose,
  user,
  onAuthRequired,
  onRequestSubmitted
}: LiveStreamRequestModalProps) {
  console.log('LiveStreamRequestModal rendered', { isOpen, user });
  const [formData, setFormData] = useState({
    email: '',
    requestType: 'participant' as 'participant' | 'guest' | 'interview',
    reason: '',
    experience: '',
    availability: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = async () => {
    if (!user?.isAuth) {
      onAuthRequired();
      return;
    }

    if (!formData.reason.trim() || !formData.email.trim()) {
      alert('Please fill in all required fields');
      return;
    }

    setIsSubmitting(true);

    // Simulate submission delay
    setTimeout(() => {
      const request: StreamRequest = {
        id: Date.now().toString(),
        userName: user.name,
        email: formData.email,
        requestType: formData.requestType,
        reason: formData.reason,
        experience: formData.experience,
        availability: formData.availability,
        status: 'pending',
        submittedAt: new Date()
      };

      onRequestSubmitted(request);
      setIsSubmitting(false);
      setShowSuccess(true);

      // Auto close after showing success
      setTimeout(() => {
        setShowSuccess(false);
        onClose();
        setFormData({
          email: '',
          requestType: 'participant',
          reason: '',
          experience: '',
          availability: ''
        });
      }, 3000);
    }, 2000);
  };

  const getRequestTypeInfo = (type: string) => {
    switch (type) {
      case 'participant':
        return {
          title: 'Become a Participant',
          description: 'Join the house as a full participant in the competition',
          icon: <User className="w-5 h-5" />,
          color: 'bg-blue-500'
        };
      case 'guest':
        return {
          title: 'Guest Appearance',
          description: 'Make a special guest appearance on the live stream',
          icon: <Video className="w-5 h-5" />,
          color: 'bg-green-500'
        };
      case 'interview':
        return {
          title: 'Interview Opportunity',
          description: 'Request an interview slot during the show',
          icon: <Mic className="w-5 h-5" />,
          color: 'bg-purple-500'
        };
      default:
        return {
          title: 'Stream Request',
          description: 'Request to join the live stream',
          icon: <Video className="w-5 h-5" />,
          color: 'bg-gray-500'
        };
    }
  };

  if (showSuccess) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-md bg-gray-900 border-gray-700">
          <div className="text-center py-6">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">Request Submitted!</h3>
            <p className="text-gray-300 mb-4">
              Your live stream request has been sent to the moderators for review.
            </p>
            <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3 mb-4">
              <p className="text-green-400 text-sm">
                You'll be notified once your request is reviewed. This usually takes 5-10 minutes.
              </p>
            </div>
            <Button onClick={onClose} className="w-full">
              Continue Watching
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-auto bg-gray-900 border-gray-700">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Video className="w-5 h-5 text-primary" />
            Request to Join Live Stream
          </DialogTitle>
        </DialogHeader>

        {!user?.isAuth ? (
          <div className="text-center py-8">
            <User className="w-16 h-16 mx-auto mb-4 text-gray-600" />
            <h3 className="text-lg font-medium mb-2">Sign Up Required</h3>
            <p className="text-gray-400 mb-6">
              You need to create an account to request joining the live stream
            </p>
            <Button onClick={onAuthRequired} className="w-full">
              Sign Up / Login
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Request Type Selection */}
            <div>
              <Label className="text-sm font-medium mb-3 block">Request Type</Label>
              <div className="grid gap-3 md:grid-cols-3">
                {(['participant', 'guest', 'interview'] as const).map((type) => {
                  const info = getRequestTypeInfo(type);
                  return (
                    <Card
                      key={type}
                      className={`cursor-pointer transition-all ${
                        formData.requestType === type
                          ? 'border-primary bg-primary/10'
                          : 'border-gray-700 hover:border-gray-600'
                      }`}
                      onClick={() => setFormData(prev => ({ ...prev, requestType: type }))}
                    >
                      <CardContent className="p-4 text-center">
                        <div className={`w-10 h-10 ${info.color} rounded-full flex items-center justify-center mx-auto mb-2`}>
                          {info.icon}
                        </div>
                        <h4 className="font-medium text-sm mb-1">{info.title}</h4>
                        <p className="text-xs text-gray-400">{info.description}</p>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>

            {/* User Info */}
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={user.name}
                  disabled
                  className="bg-gray-800 border-gray-600"
                />
              </div>
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  placeholder="your.email@example.com"
                  className="bg-gray-800 border-gray-600"
                />
              </div>
            </div>

            {/* Reason */}
            <div>
              <Label htmlFor="reason">Why do you want to join the live stream? *</Label>
              <Textarea
                id="reason"
                value={formData.reason}
                onChange={(e) => setFormData(prev => ({ ...prev, reason: e.target.value }))}
                placeholder="Tell us why you'd like to join and what you'd bring to the show..."
                className="bg-gray-800 border-gray-600 min-h-[100px]"
                maxLength={500}
              />
              <div className="text-right text-xs text-gray-400 mt-1">
                {formData.reason.length}/500 characters
              </div>
            </div>

            {/* Experience */}
            <div>
              <Label htmlFor="experience">Relevant Experience (Optional)</Label>
              <Textarea
                id="experience"
                value={formData.experience}
                onChange={(e) => setFormData(prev => ({ ...prev, experience: e.target.value }))}
                placeholder="Any relevant experience with streaming, reality TV, entertainment, etc."
                className="bg-gray-800 border-gray-600"
                maxLength={300}
              />
            </div>

            {/* Availability */}
            <div>
              <Label htmlFor="availability">When are you available?</Label>
              <Input
                id="availability"
                value={formData.availability}
                onChange={(e) => setFormData(prev => ({ ...prev, availability: e.target.value }))}
                placeholder="e.g., Weekends, Evenings, Anytime, etc."
                className="bg-gray-800 border-gray-600"
              />
            </div>

            {/* Info Box */}
            <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
              <div className="flex gap-3">
                <Info className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-medium text-blue-400 mb-1">Request Review Process</h4>
                  <ul className="text-sm text-blue-200 space-y-1">
                    <li>• Your request will be reviewed by our moderation team</li>
                    <li>• Review typically takes 5-10 minutes during live shows</li>
                    <li>• You'll be notified via email and in-app notification</li>
                    <li>• If approved, you'll receive instructions to join</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <div className="flex gap-3">
              <Button
                onClick={handleSubmit}
                disabled={isSubmitting || !formData.reason.trim() || !formData.email.trim()}
                className="flex-1"
              >
                {isSubmitting ? (
                  <>
                    <Clock className="w-4 h-4 mr-2 animate-spin" />
                    Submitting Request...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Submit Request
                  </>
                )}
              </Button>
              <Button variant="outline" onClick={onClose} className="border-gray-600">
                Cancel
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
