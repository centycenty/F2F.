import { Button } from '@/components/ui/button';
import { Camera, CameraOff, Mic, MicOff, PhoneOff } from 'lucide-react';
import { useLocalStream } from './LocalStreamProvider';

export function LocalStreamControls() {
  const { 
    localParticipant, 
    toggleCamera, 
    toggleMicrophone, 
    disconnect,
    isConnected 
  } = useLocalStream();

  if (!isConnected || !localParticipant) {
    return null;
  }

  return (
    <div className="absolute bottom-20 left-1/2 transform -translate-x-1/2 flex gap-4 z-10">
      {/* Microphone Toggle */}
      <Button
        variant="ghost"
        size="icon"
        className={`w-12 h-12 rounded-full backdrop-blur-sm transition-all ${
          localParticipant.audioEnabled 
            ? 'bg-white/10 hover:bg-white/20' 
            : 'bg-red-500/80 hover:bg-red-500'
        }`}
        onClick={toggleMicrophone}
      >
        {localParticipant.audioEnabled ? (
          <Mic className="w-6 h-6 text-white" />
        ) : (
          <MicOff className="w-6 h-6 text-white" />
        )}
      </Button>

      {/* Camera Toggle */}
      <Button
        variant="ghost"
        size="icon"
        className={`w-12 h-12 rounded-full backdrop-blur-sm transition-all ${
          localParticipant.videoEnabled 
            ? 'bg-white/10 hover:bg-white/20' 
            : 'bg-red-500/80 hover:bg-red-500'
        }`}
        onClick={toggleCamera}
      >
        {localParticipant.videoEnabled ? (
          <Camera className="w-6 h-6 text-white" />
        ) : (
          <CameraOff className="w-6 h-6 text-white" />
        )}
      </Button>

      {/* Disconnect */}
      <Button
        variant="ghost"
        size="icon"
        className="w-12 h-12 rounded-full bg-red-500/80 hover:bg-red-500 backdrop-blur-sm transition-all"
        onClick={disconnect}
      >
        <PhoneOff className="w-6 h-6 text-white" />
      </Button>
    </div>
  );
}
