import { useState } from 'react';
import { useLocalStream } from './LocalStreamProvider';
import { LocalVideoTile } from './LocalVideoTile';
import { EnhancedVideoTile } from './EnhancedVideoTile';
import { LiveStreamRequestModal } from './LiveStreamRequestModal';
import { Button } from '@/components/ui/button';
import { Users, Wifi, Grid3X3, Maximize, Video, UserPlus } from 'lucide-react';

interface LocalStreamGridProps {
  user?: { name: string; isAuth: boolean } | null;
  onAuthRequired?: () => void;
  onShowRequestModal?: () => void;
}

export function LocalStreamGrid({ user, onAuthRequired, onShowRequestModal }: LocalStreamGridProps = {}) {
  const [streamRequests, setStreamRequests] = useState<any[]>([]);

  const {
    participants,
    isConnected,
    isStreamActive,
    mainParticipantId,
    setMainParticipant,
    viewMode,
    setViewMode
  } = useLocalStream();

  console.log('LocalStreamGrid render:', {
    isConnected,
    isStreamActive,
    participantsCount: participants.length
  });

  const handleRequestSubmitted = (request: any) => {
    setStreamRequests(prev => [...prev, request]);
    // You could also send this to a real backend API
    console.log('Stream request submitted:', request);
  };

  // If not connected and stream not active, show placeholder
  if (!isConnected && !isStreamActive) {
    return (
      <>
        <div className="flex items-center justify-center h-full text-white">
          <div className="text-center max-w-md mx-auto">
            <div className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Video className="w-10 h-10 text-primary" />
            </div>
            <h3 className="text-xl font-medium mb-3">🔴 Live Competition Active</h3>
            <p className="text-gray-400 mb-6">
              Watch the live stream! Use the request button on the right to join as a participant.
            </p>

            {streamRequests.length > 0 && (
              <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                <p className="text-blue-400 text-sm">
                  📋 You have {streamRequests.length} pending request{streamRequests.length > 1 ? 's' : ''}
                </p>
              </div>
            )}
          </div>
        </div>


      </>
    );
  }

  // If no participants, show waiting message
  if (participants.length === 0) {
    return (
      <div className="flex items-center justify-center h-full text-white">
        <div className="text-center">
          <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <Users className="w-8 h-8 text-primary" />
          </div>
          <h3 className="text-lg font-medium mb-2">No Participants</h3>
          <p className="text-gray-400">Waiting for others to join...</p>
        </div>
      </div>
    );
  }

  const mainParticipant = participants.find(p => p.id === mainParticipantId) || participants[0];
  const otherParticipants = participants.filter(p => p.id !== mainParticipant.id);

  // Grid View - Equal sized tiles
  if (viewMode === 'grid') {
    const gridCols = participants.length <= 2 ? 2 : participants.length <= 4 ? 2 : 3;
    const gridClass = `grid-cols-${gridCols}`;
    
    return (
      <div className="relative h-full">
        {/* View Mode Toggle */}
        <div className="absolute top-4 left-4 z-20">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setViewMode('spotlight')}
            className="bg-black/50 backdrop-blur-sm hover:bg-black/70"
          >
            <Maximize className="w-4 h-4 mr-2" />
            Spotlight
          </Button>
        </div>

        {/* Equal Grid Layout */}
        <div className={`grid ${gridClass} gap-2 h-full p-4`}>
          {participants.map((participant) => (
            <div
              key={participant.id}
              className="relative cursor-pointer group"
              onClick={() => setMainParticipant(participant.id)}
            >
              <EnhancedVideoTile participant={participant} isMain={false} />

              {/* Hover overlay for selection */}
              <div className="absolute inset-0 bg-primary/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span className="text-white font-medium bg-black/50 px-2 py-1 rounded">
                  Set as Main
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Participant Count */}
        <div className="absolute bottom-4 left-4 bg-black/50 backdrop-blur-sm px-3 py-1 rounded-full">
          <div className="flex items-center gap-2 text-white text-sm">
            <Users className="w-4 h-4" />
            <span>{participants.length} participant{participants.length !== 1 ? 's' : ''}</span>
          </div>
        </div>
      </div>
    );
  }

  // Spotlight View - One main + thumbnails
  return (
    <div className="relative h-full">
      {/* View Mode Toggle */}
      <div className="absolute top-4 left-4 z-20">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setViewMode('grid')}
          className="bg-black/50 backdrop-blur-sm hover:bg-black/70"
        >
          <Grid3X3 className="w-4 h-4 mr-2" />
          Grid View
        </Button>
      </div>

      {/* Main Participant - Full Screen */}
      <div className="absolute inset-0">
        <EnhancedVideoTile participant={mainParticipant} isMain={true} />
      </div>

      {/* Other Participants - TikTok Style Stack */}
      {otherParticipants.length > 0 && (
        <div className="absolute top-4 right-4 flex flex-col gap-2 z-10">
          {otherParticipants.map((participant) => (
            <div
              key={participant.id}
              className="border-2 border-white/20 rounded-lg overflow-hidden cursor-pointer hover:border-primary/60 transition-colors"
              onClick={() => setMainParticipant(participant.id)}
            >
              <EnhancedVideoTile participant={participant} isMain={false} />
            </div>
          ))}
        </div>
      )}

      {/* Participant Count */}
      <div className="absolute bottom-4 left-4 bg-black/50 backdrop-blur-sm px-3 py-1 rounded-full">
        <div className="flex items-center gap-2 text-white text-sm">
          <Users className="w-4 h-4" />
          <span>{participants.length} participant{participants.length !== 1 ? 's' : ''}</span>
        </div>
      </div>
    </div>
  );
}
