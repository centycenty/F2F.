import React, { createContext, useContext, useEffect, useState, useRef } from 'react';
import { mockLiveKitServer, MockParticipant, MockRoom } from '@/lib/mockLiveKitServer';

interface LocalStreamContextType {
  participants: MockParticipant[];
  localParticipant: MockParticipant | null;
  room: MockRoom | null;
  isConnected: boolean;
  isStreamActive: boolean;
  toggleCamera: () => void;
  toggleMicrophone: () => void;
  connect: (roomName: string, participantName: string) => Promise<void>;
  disconnect: () => void;
  error: string | null;
  // Moderator controls
  setMainParticipant: (participantId: string) => void;
  muteParticipant: (participantId: string) => void;
  kickParticipant: (participantId: string) => void;
  mainParticipantId: string | null;
  viewMode: 'spotlight' | 'grid';
  setViewMode: (mode: 'spotlight' | 'grid') => void;
  // Audio controls
  toggleParticipantAudio: (participantId: string) => void;
  toggleParticipantVideo: (participantId: string) => void;
  // Stream management
  initializeStream: () => void;
  stopStream: () => void;
}

const LocalStreamContext = createContext<LocalStreamContextType | null>(null);

interface LocalStreamProviderProps {
  children: React.ReactNode;
}

export function LocalStreamProvider({ children }: LocalStreamProviderProps) {
  const [participants, setParticipants] = useState<MockParticipant[]>([]);
  const [localParticipant, setLocalParticipant] = useState<MockParticipant | null>(null);
  const [room, setRoom] = useState<MockRoom | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [isStreamActive, setIsStreamActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [mainParticipantId, setMainParticipantId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'spotlight' | 'grid'>('spotlight');
  const eventListenersRef = useRef<Function[]>([]);

  const updateParticipants = (currentRoom: MockRoom) => {
    const participantList = Array.from(currentRoom.participants.values());
    setParticipants(participantList);
    
    // Set main participant if not set
    if (!mainParticipantId && participantList.length > 0) {
      setMainParticipantId(participantList[0].id);
    }
  };

  const connect = async (roomName: string, participantName: string) => {
    try {
      setError(null);
      
      // Check for media permissions first
      let userStream: MediaStream;
      try {
        userStream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: true
        });
      } catch (mediaError) {
        console.warn('Could not access camera/microphone:', mediaError);
        // Create empty stream if permission denied
        userStream = new MediaStream();
      }
      
      const { room: connectedRoom, localParticipant: local } = await mockLiveKitServer.joinRoom(
        roomName,
        participantName
      );
      
      // Use the obtained stream
      if (userStream.getTracks().length > 0) {
        local.stream = userStream;
      }

      setRoom(connectedRoom);
      setLocalParticipant(local);
      setIsConnected(true);
      updateParticipants(connectedRoom);

      // Set up event listeners
      const onParticipantConnected = (participant: MockParticipant) => {
        updateParticipants(connectedRoom);
      };

      const onParticipantDisconnected = (participant: MockParticipant) => {
        updateParticipants(connectedRoom);
      };

      const onParticipantUpdated = (participant: MockParticipant) => {
        updateParticipants(connectedRoom);
        if (participant.isLocal) {
          setLocalParticipant(participant);
        }
      };

      mockLiveKitServer.addEventListener(connectedRoom, 'participantConnected', onParticipantConnected);
      mockLiveKitServer.addEventListener(connectedRoom, 'participantDisconnected', onParticipantDisconnected);
      mockLiveKitServer.addEventListener(connectedRoom, 'participantUpdated', onParticipantUpdated);

      // Store event listeners for cleanup
      eventListenersRef.current = [
        () => mockLiveKitServer.removeEventListener(connectedRoom, 'participantConnected', onParticipantConnected),
        () => mockLiveKitServer.removeEventListener(connectedRoom, 'participantDisconnected', onParticipantDisconnected),
        () => mockLiveKitServer.removeEventListener(connectedRoom, 'participantUpdated', onParticipantUpdated)
      ];

    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to connect to room');
      console.error('Connection error:', err);
    }
  };

  const disconnect = () => {
    if (room && localParticipant) {
      mockLiveKitServer.leaveRoom(room, localParticipant.id);
      
      // Clean up event listeners
      eventListenersRef.current.forEach(cleanup => cleanup());
      eventListenersRef.current = [];
    }

    mockLiveKitServer.stopLocalStream();
    setRoom(null);
    setLocalParticipant(null);
    setParticipants([]);
    setIsConnected(false);
    setError(null);
    setMainParticipantId(null);
  };

  const toggleCamera = () => {
    if (room && localParticipant) {
      const newVideoState = !localParticipant.videoEnabled;
      
      // Update local stream tracks
      if (localParticipant.stream) {
        localParticipant.stream.getVideoTracks().forEach(track => {
          track.enabled = newVideoState;
        });
      }

      mockLiveKitServer.updateParticipant(room, localParticipant.id, {
        videoEnabled: newVideoState
      });
    }
  };

  const toggleMicrophone = () => {
    if (room && localParticipant) {
      const newAudioState = !localParticipant.audioEnabled;
      
      // Update local stream tracks
      if (localParticipant.stream) {
        localParticipant.stream.getAudioTracks().forEach(track => {
          track.enabled = newAudioState;
        });
      }

      mockLiveKitServer.updateParticipant(room, localParticipant.id, {
        audioEnabled: newAudioState
      });
    }
  };

  // Moderator controls
  const setMainParticipant = (participantId: string) => {
    setMainParticipantId(participantId);
  };

  const muteParticipant = (participantId: string) => {
    if (room) {
      mockLiveKitServer.updateParticipant(room, participantId, {
        audioEnabled: false
      });
    }
  };

  const kickParticipant = (participantId: string) => {
    if (room) {
      mockLiveKitServer.leaveRoom(room, participantId);
    }
  };

  const toggleParticipantAudio = (participantId: string) => {
    if (room) {
      const participant = participants.find(p => p.id === participantId);
      if (participant) {
        mockLiveKitServer.updateParticipant(room, participantId, {
          audioEnabled: !participant.audioEnabled
        });
      }
    }
  };

  const toggleParticipantVideo = (participantId: string) => {
    if (room) {
      const participant = participants.find(p => p.id === participantId);
      if (participant) {
        mockLiveKitServer.updateParticipant(room, participantId, {
          videoEnabled: !participant.videoEnabled
        });
      }
    }
  };

  // Initialize stream with mock participants (for moderator)
  const initializeStream = async () => {
    try {
      setError(null);

      // Create or get the main room
      const { room: mainRoom } = await mockLiveKitServer.joinRoom(
        'bigbrother-house-stream',
        'moderator-view'
      );

      // Add some initial mock participants
      const mockParticipants = [
        { name: 'Teez', id: 'teez-1' },
        { name: 'MR.SURE', id: 'sure-2' },
        { name: 'ENOGIE', id: 'enogie-3' },
        { name: 'Ikechukwu', id: 'ike-4' },
        { name: 'Alisa', id: 'alisa-5' },
        { name: 'Big Bella', id: 'bella-6' }
      ];

      // Add participants to the room
      for (const mockP of mockParticipants) {
        const { localParticipant: mockParticipant } = await mockLiveKitServer.joinRoom(
          'bigbrother-house-stream',
          mockP.name
        );

        // Set initial states
        mockLiveKitServer.updateParticipant(mainRoom, mockParticipant.id, {
          videoEnabled: true,
          audioEnabled: true
        });
      }

      setRoom(mainRoom);
      setIsStreamActive(true);
      updateParticipants(mainRoom);

    } catch (err) {
      setError('Failed to initialize stream');
      console.error('Stream initialization error:', err);
    }
  };

  const stopStream = () => {
    if (room) {
      // Remove all participants
      participants.forEach(p => {
        if (!p.isLocal) {
          mockLiveKitServer.leaveRoom(room, p.id);
        }
      });
    }

    setRoom(null);
    setParticipants([]);
    setIsStreamActive(false);
    setMainParticipantId(null);
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      disconnect();
    };
  }, []);

  const value: LocalStreamContextType = {
    participants,
    localParticipant,
    room,
    isConnected,
    isStreamActive,
    toggleCamera,
    toggleMicrophone,
    connect,
    disconnect,
    error,
    setMainParticipant,
    muteParticipant,
    kickParticipant,
    mainParticipantId,
    viewMode,
    setViewMode,
    toggleParticipantAudio,
    toggleParticipantVideo,
    initializeStream,
    stopStream
  };

  return (
    <LocalStreamContext.Provider value={value}>
      {children}
    </LocalStreamContext.Provider>
  );
}

export function useLocalStream() {
  const context = useContext(LocalStreamContext);
  if (!context) {
    throw new Error('useLocalStream must be used within a LocalStreamProvider');
  }
  return context;
}
