import { useEffect, useRef } from 'react';
import { Mic, MicOff, Video, VideoOff, User } from 'lucide-react';
import { MockParticipant } from '@/lib/mockLiveKitServer';

interface LocalVideoTileProps {
  participant: MockParticipant;
  isMain?: boolean;
}

export function LocalVideoTile({ participant, isMain = false }: LocalVideoTileProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    if (videoRef.current && participant.stream) {
      videoRef.current.srcObject = participant.stream;

      // Set volume through JavaScript API
      if (!participant.isLocal) {
        videoRef.current.volume = 0.8;
      }

      // Ensure video plays
      videoRef.current.play().catch(e => console.warn('Video play failed:', e));
    }

    // Set up audio for remote participants
    if (audioRef.current && participant.stream && !participant.isLocal) {
      audioRef.current.srcObject = participant.stream;
      audioRef.current.volume = 0.8; // Set appropriate volume

      // Handle audio play with user interaction requirement
      const playAudio = async () => {
        try {
          await audioRef.current?.play();
        } catch (e) {
          console.warn('Audio play failed, requires user interaction:', e);
          // Add click handler to enable audio
          const enableAudio = () => {
            audioRef.current?.play().catch(console.warn);
            document.removeEventListener('click', enableAudio);
          };
          document.addEventListener('click', enableAudio, { once: true });
        }
      };

      playAudio();
    }
  }, [participant.stream, participant.isLocal]);

  // Handle audio enable/disable
  useEffect(() => {
    if (audioRef.current && !participant.isLocal) {
      audioRef.current.muted = !participant.audioEnabled;
    }
  }, [participant.audioEnabled, participant.isLocal]);

  const showVideo = participant.videoEnabled && participant.stream && participant.stream.getVideoTracks().length > 0;

  return (
    <div className={`relative bg-gray-900 rounded-lg overflow-hidden h-full ${
      isMain ? "w-full" : "w-16 h-20"
    }`}>
      {/* Video Stream */}
      {showVideo ? (
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted={participant.isLocal} // Mute local video to prevent feedback
          className="w-full h-full object-cover"
          style={{ transform: participant.isLocal ? 'scaleX(-1)' : 'none' }} // Mirror local video
        />
      ) : (
        <div className="w-full h-full bg-gradient-to-br from-purple-900/20 to-pink-900/20 flex items-center justify-center">
          {participant.isLocal ? (
            <VideoOff className={`text-white/50 ${isMain ? 'w-12 h-12' : 'w-4 h-4'}`} />
          ) : (
            <User className={`text-white/50 ${isMain ? 'w-12 h-12' : 'w-4 h-4'}`} />
          )}
        </div>
      )}

      {/* Audio for remote participants */}
      {!participant.isLocal && (
        <audio
          ref={audioRef}
          autoPlay
          playsInline
          muted={!participant.audioEnabled}
          style={{ display: 'none' }}
        />
      )}

      {/* Participant Info Overlay */}
      <div className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent ${
        isMain ? 'p-4' : 'p-1'
      }`}>
        <div className="flex items-center justify-between">
          <span className={`text-white font-medium ${
            isMain ? 'text-lg' : 'text-xs'
          } truncate`}>
            {participant.name}
            {participant.isLocal && ' (You)'}
          </span>
          <div className="flex items-center gap-1">
            {participant.audioEnabled ? (
              <Mic className={`text-green-400 ${isMain ? 'w-5 h-5' : 'w-2 h-2'}`} />
            ) : (
              <MicOff className={`text-red-400 ${isMain ? 'w-5 h-5' : 'w-2 h-2'}`} />
            )}
            {participant.videoEnabled ? (
              <Video className={`text-green-400 ${isMain ? 'w-5 h-5' : 'w-2 h-2'}`} />
            ) : (
              <VideoOff className={`text-red-400 ${isMain ? 'w-5 h-5' : 'w-2 h-2'}`} />
            )}
          </div>
        </div>
      </div>

      {/* Status Indicator */}
      <div className={`absolute ${isMain ? 'top-4 right-4' : 'top-1 right-1'}`}>
        <div className={`bg-green-400 rounded-full animate-pulse ${
          isMain ? 'w-4 h-4' : 'w-2 h-2'
        }`} />
      </div>
    </div>
  );
}
