import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Camera, Mic, AlertTriangle, CheckCircle } from 'lucide-react';

interface MediaPermissionHandlerProps {
  onPermissionGranted: (stream: MediaStream) => void;
  onPermissionDenied: (error: string) => void;
  children?: React.ReactNode;
}

interface PermissionState {
  camera: 'pending' | 'granted' | 'denied' | 'checking';
  microphone: 'pending' | 'granted' | 'denied' | 'checking';
}

export function MediaPermissionHandler({ 
  onPermissionGranted, 
  onPermissionDenied, 
  children 
}: MediaPermissionHandlerProps) {
  const [permissions, setPermissions] = useState<PermissionState>({
    camera: 'pending',
    microphone: 'pending'
  });
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);

  const checkPermissions = async () => {
    setPermissions({
      camera: 'checking',
      microphone: 'checking'
    });
    setError(null);

    try {
      // First check if permissions API is available
      if ('permissions' in navigator) {
        const cameraPermission = await navigator.permissions.query({ name: 'camera' as PermissionName });
        const microphonePermission = await navigator.permissions.query({ name: 'microphone' as PermissionName });

        setPermissions({
          camera: cameraPermission.state === 'granted' ? 'granted' : 
                  cameraPermission.state === 'denied' ? 'denied' : 'pending',
          microphone: microphonePermission.state === 'granted' ? 'granted' : 
                     microphonePermission.state === 'denied' ? 'denied' : 'pending'
        });
      }

      // Try to get user media
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      });

      setStream(mediaStream);
      setPermissions({
        camera: 'granted',
        microphone: 'granted'
      });
      onPermissionGranted(mediaStream);

    } catch (err) {
      const error = err as DOMException;
      let errorMessage = 'Failed to access camera and microphone';

      // Handle specific error types
      switch (error.name) {
        case 'NotAllowedError':
          errorMessage = 'Camera and microphone access denied. Please allow permissions and try again.';
          setPermissions({
            camera: 'denied',
            microphone: 'denied'
          });
          break;
        case 'NotFoundError':
          errorMessage = 'No camera or microphone found on this device.';
          break;
        case 'NotReadableError':
          errorMessage = 'Camera or microphone is already in use by another application.';
          break;
        case 'OverconstrainedError':
          errorMessage = 'Camera or microphone constraints cannot be satisfied.';
          break;
        case 'SecurityError':
          errorMessage = 'Security error accessing camera or microphone.';
          break;
        default:
          errorMessage = `Media access error: ${error.message}`;
      }

      setError(errorMessage);
      onPermissionDenied(errorMessage);
    }
  };

  const requestCameraOnly = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: false
      });
      
      setStream(mediaStream);
      setPermissions(prev => ({ ...prev, camera: 'granted' }));
      onPermissionGranted(mediaStream);
    } catch (err) {
      const error = err as DOMException;
      setPermissions(prev => ({ ...prev, camera: 'denied' }));
      setError(`Camera access denied: ${error.message}`);
    }
  };

  const requestMicrophoneOnly = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: false,
        audio: true
      });
      
      setStream(mediaStream);
      setPermissions(prev => ({ ...prev, microphone: 'granted' }));
      onPermissionGranted(mediaStream);
    } catch (err) {
      const error = err as DOMException;
      setPermissions(prev => ({ ...prev, microphone: 'denied' }));
      setError(`Microphone access denied: ${error.message}`);
    }
  };

  // Clean up stream on unmount
  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [stream]);

  // If we have permission and stream, render children
  if (permissions.camera === 'granted' || permissions.microphone === 'granted') {
    return <>{children}</>;
  }

  return (
    <div className="flex items-center justify-center h-full bg-black text-white">
      <div className="max-w-md mx-auto text-center p-6">
        <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6">
          <Camera className="w-8 h-8 text-primary" />
        </div>

        <h2 className="text-xl font-semibold mb-4">Camera & Microphone Access</h2>
        
        {error ? (
          <div className="bg-red-500/20 border border-red-500/50 rounded-lg p-4 mb-6">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-5 h-5 text-red-400" />
              <span className="font-medium text-red-400">Permission Error</span>
            </div>
            <p className="text-sm text-red-200">{error}</p>
          </div>
        ) : (
          <p className="text-gray-300 mb-6">
            To start streaming, we need access to your camera and microphone. 
            You can grant permission for both or just one device.
          </p>
        )}

        <div className="space-y-3 mb-6">
          {/* Permission Status */}
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center gap-2">
              <Camera className="w-4 h-4" />
              <span>Camera:</span>
              {permissions.camera === 'checking' ? (
                <span className="text-yellow-400">Checking...</span>
              ) : permissions.camera === 'granted' ? (
                <CheckCircle className="w-4 h-4 text-green-400" />
              ) : permissions.camera === 'denied' ? (
                <span className="text-red-400">Denied</span>
              ) : (
                <span className="text-gray-400">Pending</span>
              )}
            </div>
            
            <div className="flex items-center gap-2">
              <Mic className="w-4 h-4" />
              <span>Microphone:</span>
              {permissions.microphone === 'checking' ? (
                <span className="text-yellow-400">Checking...</span>
              ) : permissions.microphone === 'granted' ? (
                <CheckCircle className="w-4 h-4 text-green-400" />
              ) : permissions.microphone === 'denied' ? (
                <span className="text-red-400">Denied</span>
              ) : (
                <span className="text-gray-400">Pending</span>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <Button 
            onClick={checkPermissions}
            className="w-full"
            disabled={permissions.camera === 'checking' || permissions.microphone === 'checking'}
          >
            {permissions.camera === 'checking' ? 'Requesting Access...' : 'Allow Camera & Microphone'}
          </Button>

          <div className="grid grid-cols-2 gap-3">
            <Button 
              variant="outline"
              onClick={requestCameraOnly}
              disabled={permissions.camera === 'checking'}
              className="border-gray-600 hover:bg-gray-800"
            >
              <Camera className="w-4 h-4 mr-2" />
              Camera Only
            </Button>
            
            <Button 
              variant="outline"
              onClick={requestMicrophoneOnly}
              disabled={permissions.microphone === 'checking'}
              className="border-gray-600 hover:bg-gray-800"
            >
              <Mic className="w-4 h-4 mr-2" />
              Mic Only
            </Button>
          </div>

          {(permissions.camera === 'denied' || permissions.microphone === 'denied') && (
            <div className="text-xs text-gray-400 mt-4">
              <p>If permissions were denied, you can:</p>
              <ul className="list-disc list-inside mt-1 space-y-1">
                <li>Click the camera/microphone icon in your browser's address bar</li>
                <li>Go to browser settings and allow permissions for this site</li>
                <li>Refresh the page and try again</li>
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
