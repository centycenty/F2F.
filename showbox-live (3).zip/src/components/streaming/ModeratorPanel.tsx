import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useLocalStream } from "./LocalStreamProvider";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Shield,
  Settings,
  Users,
  MessageSquare,
  Volume2,
  VolumeX,
  Play,
  Pause,
  AlertTriangle,
  Trophy,
  Timer,
  Vote,
  Eye,
  EyeOff,
  Ban,
  UserX,
  Megaphone,
  Star,
  Crown,
  Award,
  Mic,
  MicOff,
  Camera,
  CameraOff,
  CheckCircle,
  X
} from "lucide-react";

interface ModeratorPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const housemates = [
  { id: 1, name: "Teez", isLive: true, isMuted: false, viewers: 1240, isEvicted: false, warnings: 0, coins: 150 },
  { id: 2, name: "MR.SURE", isLive: true, isMuted: true, viewers: 890, isEvicted: false, warnings: 1, coins: 120 },
  { id: 3, name: "ENOGIE", isLive: true, isMuted: false, viewers: 756, isEvicted: false, warnings: 0, coins: 180 },
  { id: 4, name: "Ikechukwu", isLive: true, isMuted: false, viewers: 534, isEvicted: false, warnings: 2, coins: 90 },
  { id: 5, name: "Alisa", isLive: true, isMuted: true, viewers: 1100, isEvicted: false, warnings: 0, coins: 200 },
  { id: 6, name: "Big Bella", isLive: true, isMuted: false, viewers: 980, isEvicted: false, warnings: 1, coins: 160 },
];

const tasks = [
  { id: 1, title: "Daily Workout Challenge", status: "active", participants: 4, timeRemaining: "2h 15m" },
  { id: 2, title: "Cooking Competition", status: "pending", participants: 0, timeRemaining: "4h 30m" },
  { id: 3, title: "Talent Show", status: "completed", participants: 6, timeRemaining: "Ended" },
];

export function ModeratorPanel({ isOpen, onClose }: ModeratorPanelProps) {
  const {
    participants,
    setMainParticipant,
    toggleParticipantAudio,
    toggleParticipantVideo,
    kickParticipant,
    mainParticipantId,
    viewMode,
    setViewMode,
    isStreamActive,
    initializeStream,
    stopStream
  } = useLocalStream();

  const [announcement, setAnnouncement] = useState("");
  const [newTask, setNewTask] = useState("");
  const [selectedHousemate, setSelectedHousemate] = useState<string | null>(null);
  const [streamSettings, setStreamSettings] = useState({
    commentsEnabled: true,
    likesEnabled: true,
    votingEnabled: true,
    autoModeration: true,
    globalMute: false,
    nightMode: false,
  });

  const [competitionSettings, setCompetitionSettings] = useState({
    evictionActive: false,
    taskTimerActive: true,
    publicVoting: true,
    coinSystem: true,
  });

  const toggleMute = (participantId: string) => {
    toggleParticipantAudio(participantId);
  };

  const toggleCamera = (participantId: string) => {
    toggleParticipantVideo(participantId);
  };

  const setAsMainScreen = (participantId: string) => {
    setMainParticipant(participantId);
  };

  const warnParticipant = (participantId: string) => {
    // You could implement a warning system here
    console.log(`Warning issued to participant ${participantId}`);
  };

  const evictParticipant = (participantId: string) => {
    if (confirm("Are you sure you want to remove this participant?")) {
      kickParticipant(participantId);
    }
  };

  const sendAnnouncement = () => {
    if (announcement.trim()) {
      console.log("Sending announcement:", announcement);
      setAnnouncement("");
    }
  };

  const startTask = (taskId: number) => {
    console.log(`Starting task ${taskId}`);
  };

  const createNewTask = () => {
    if (newTask.trim()) {
      console.log("Creating new task:", newTask);
      setNewTask("");
    }
  };

  const emergencyStop = () => {
    if (confirm("This will stop all streams and activities. Continue?")) {
      console.log("Emergency stop activated");
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[95vh] overflow-hidden bg-card">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-accent" />
            Big Brother Moderator Control Panel
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="housemates" className="w-full">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="housemates">Housemates</TabsTrigger>
            <TabsTrigger value="requests">Requests</TabsTrigger>
            <TabsTrigger value="tasks">Tasks</TabsTrigger>
            <TabsTrigger value="stream">Stream</TabsTrigger>
            <TabsTrigger value="voting">Voting</TabsTrigger>
            <TabsTrigger value="emergency">Emergency</TabsTrigger>
          </TabsList>

          {/* Housemates Control */}
          <TabsContent value="housemates" className="space-y-4">
            {/* Stream Control */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  Stream Control
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Live Stream Status</h4>
                    <p className="text-sm text-muted-foreground">
                      {isStreamActive ? 'Stream is active with participants' : 'Stream is not active'}
                    </p>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${isStreamActive ? 'bg-green-400' : 'bg-gray-400'}`} />
                </div>

                <div className="flex gap-3">
                  {!isStreamActive ? (
                    <Button
                      onClick={initializeStream}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Start Live Stream
                    </Button>
                  ) : (
                    <Button
                      onClick={stopStream}
                      variant="destructive"
                    >
                      <Pause className="w-4 h-4 mr-2" />
                      Stop Stream
                    </Button>
                  )}
                </div>

                <div className="text-sm text-muted-foreground">
                  {isStreamActive
                    ? 'Stream is live with mock participants. Audiences can watch and request to join.'
                    : 'Click "Start Live Stream" to initialize the competition with participants.'
                  }
                </div>
              </CardContent>
            </Card>

            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5" />
                    Housemate Management
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-80">
                    <div className="space-y-3">
                      {participants.length === 0 ? (
                        <div className="text-center text-muted-foreground p-4">
                          No participants connected
                        </div>
                      ) : (
                        participants.map((participant) => (
                          <div key={participant.id} className="p-4 border border-border rounded-lg">
                            <div className="flex items-start justify-between mb-3">
                              <div className="flex items-center gap-3">
                                <div className={`w-3 h-3 rounded-full ${participant.videoEnabled || participant.audioEnabled ? 'bg-green-400' : 'bg-gray-400'}`} />
                                <div>
                                  <span className="font-medium">{participant.name}</span>
                                  {participant.isLocal && <Badge variant="outline" className="ml-2">You</Badge>}
                                  {mainParticipantId === participant.id && <Badge variant="default" className="ml-2">Main Screen</Badge>}
                                </div>
                              </div>
                              <div className="text-right">
                                <Badge variant="secondary" className="text-xs">
                                  Live
                                </Badge>
                              </div>
                            </div>

                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-1">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => toggleMute(participant.id)}
                                  className="p-2"
                                  disabled={participant.isLocal}
                                >
                                  {!participant.audioEnabled ? (
                                    <MicOff className="w-3 h-3 text-red-400" />
                                  ) : (
                                    <Mic className="w-3 h-3 text-green-400" />
                                  )}
                                </Button>

                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => toggleCamera(participant.id)}
                                  className="p-2"
                                  disabled={participant.isLocal}
                                >
                                  {!participant.videoEnabled ? (
                                    <CameraOff className="w-3 h-3 text-red-400" />
                                  ) : (
                                    <Camera className="w-3 h-3 text-green-400" />
                                  )}
                                </Button>

                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => setAsMainScreen(participant.id)}
                                  className="p-2"
                                  disabled={mainParticipantId === participant.id}
                                >
                                  <Star className="w-3 h-3 text-primary" />
                                </Button>

                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => warnParticipant(participant.id)}
                                  className="p-2"
                                  disabled={participant.isLocal}
                                >
                                  <AlertTriangle className="w-3 h-3 text-yellow-500" />
                                </Button>
                              </div>

                              <div className="flex items-center gap-2">
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => evictParticipant(participant.id)}
                                  className="p-2"
                                  disabled={participant.isLocal}
                                >
                                  <UserX className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Crown className="w-5 h-5" />
                    Competition Controls
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="eviction">Eviction Mode</Label>
                    <Switch
                      id="eviction"
                      checked={competitionSettings.evictionActive}
                      onCheckedChange={(checked) =>
                        setCompetitionSettings(prev => ({ ...prev, evictionActive: checked }))
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="voting">Public Voting</Label>
                    <Switch
                      id="voting"
                      checked={competitionSettings.publicVoting}
                      onCheckedChange={(checked) =>
                        setCompetitionSettings(prev => ({ ...prev, publicVoting: checked }))
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="coins">Coin System</Label>
                    <Switch
                      id="coins"
                      checked={competitionSettings.coinSystem}
                      onCheckedChange={(checked) =>
                        setCompetitionSettings(prev => ({ ...prev, coinSystem: checked }))
                      }
                    />
                  </div>

                  <div className="pt-4 border-t space-y-3">
                    <div className="flex items-center justify-between">
                      <Label>Stream Layout</Label>
                      <div className="flex gap-2">
                        <Button
                          variant={viewMode === 'spotlight' ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => setViewMode('spotlight')}
                        >
                          Spotlight
                        </Button>
                        <Button
                          variant={viewMode === 'grid' ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => setViewMode('grid')}
                        >
                          Grid
                        </Button>
                      </div>
                    </div>

                    <Button variant="outline" className="w-full">
                      <Award className="w-4 h-4 mr-2" />
                      Award Special Prize
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Star className="w-4 h-4 mr-2" />
                      Set Head of House
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Stream Requests Tab */}
          <TabsContent value="requests" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-1">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5" />
                    Live Stream Requests
                    <Badge variant="destructive" className="text-xs">3 Pending</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-80">
                    <div className="space-y-4">
                      {/* Mock Request 1 */}
                      <div className="p-4 border border-yellow-500/30 bg-yellow-500/5 rounded-lg">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-medium">Sarah_Lagos</span>
                              <Badge variant="outline" className="text-xs border-yellow-500 text-yellow-400">
                                Participant Request
                              </Badge>
                            </div>
                            <p className="text-xs text-gray-400">sarah@example.com • 5 minutes ago</p>
                          </div>
                          <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-400">
                            Pending
                          </Badge>
                        </div>

                        <p className="text-sm mb-3">
                          "I'm a huge fan of the show and would love to join as a participant. I have experience with reality TV from..."
                        </p>

                        <div className="flex items-center gap-2">
                          <Button size="sm" className="bg-green-600 hover:bg-green-700">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Approve
                          </Button>
                          <Button size="sm" variant="destructive">
                            <X className="w-3 h-3 mr-1" />
                            Reject
                          </Button>
                          <Button size="sm" variant="outline">
                            View Details
                          </Button>
                        </div>
                      </div>

                      {/* Mock Request 2 */}
                      <div className="p-4 border border-blue-500/30 bg-blue-500/5 rounded-lg">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-medium">VideoCreator</span>
                              <Badge variant="outline" className="text-xs border-blue-500 text-blue-400">
                                Guest Appearance
                              </Badge>
                            </div>
                            <p className="text-xs text-gray-400">creator@example.com • 12 minutes ago</p>
                          </div>
                          <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-400">
                            Pending
                          </Badge>
                        </div>

                        <p className="text-sm mb-3">
                          "I'd like to make a guest appearance to interview the housemates about their strategies..."
                        </p>

                        <div className="flex items-center gap-2">
                          <Button size="sm" className="bg-green-600 hover:bg-green-700">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Approve
                          </Button>
                          <Button size="sm" variant="destructive">
                            <X className="w-3 h-3 mr-1" />
                            Reject
                          </Button>
                          <Button size="sm" variant="outline">
                            View Details
                          </Button>
                        </div>
                      </div>

                      {/* Mock Request 3 */}
                      <div className="p-4 border border-purple-500/30 bg-purple-500/5 rounded-lg">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-medium">Interviewer_Pro</span>
                              <Badge variant="outline" className="text-xs border-purple-500 text-purple-400">
                                Interview Slot
                              </Badge>
                            </div>
                            <p className="text-xs text-gray-400">interview@media.com • 18 minutes ago</p>
                          </div>
                          <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-400">
                            Pending
                          </Badge>
                        </div>

                        <p className="text-sm mb-3">
                          "Media outlet requesting 10-minute interview slot with evicted housemates..."
                        </p>

                        <div className="flex items-center gap-2">
                          <Button size="sm" className="bg-green-600 hover:bg-green-700">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Approve
                          </Button>
                          <Button size="sm" variant="destructive">
                            <X className="w-3 h-3 mr-1" />
                            Reject
                          </Button>
                          <Button size="sm" variant="outline">
                            View Details
                          </Button>
                        </div>
                      </div>
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Tasks Management */}
          <TabsContent value="tasks" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Trophy className="w-5 h-5" />
                    Active Tasks
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-64">
                    <div className="space-y-3">
                      {tasks.map((task) => (
                        <div key={task.id} className="p-3 border border-border rounded-lg">
                          <div className="flex items-start justify-between mb-2">
                            <span className="font-medium">{task.title}</span>
                            <Badge 
                              variant={task.status === 'active' ? 'default' : 
                                      task.status === 'pending' ? 'secondary' : 'outline'}
                            >
                              {task.status}
                            </Badge>
                          </div>
                          <div className="flex items-center justify-between text-sm text-muted-foreground">
                            <span>{task.participants} participants</span>
                            <span>{task.timeRemaining}</span>
                          </div>
                          {task.status === 'pending' && (
                            <Button
                              size="sm"
                              onClick={() => startTask(task.id)}
                              className="w-full mt-2"
                            >
                              Start Task
                            </Button>
                          )}
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Create New Task</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Input
                    placeholder="Task name..."
                    value={newTask}
                    onChange={(e) => setNewTask(e.target.value)}
                  />
                  <Button onClick={createNewTask} className="w-full">
                    Create Task
                  </Button>
                  
                  <div className="space-y-2 pt-4 border-t">
                    <Button variant="outline" className="w-full">
                      <Timer className="w-4 h-4 mr-2" />
                      Diary Room Session
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Megaphone className="w-4 h-4 mr-2" />
                      House Meeting
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Stream Controls */}
          <TabsContent value="stream" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="w-5 h-5" />
                    Stream Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="comments">Enable Comments</Label>
                    <Switch
                      id="comments"
                      checked={streamSettings.commentsEnabled}
                      onCheckedChange={(checked) =>
                        setStreamSettings(prev => ({ ...prev, commentsEnabled: checked }))
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="likes">Enable Likes</Label>
                    <Switch
                      id="likes"
                      checked={streamSettings.likesEnabled}
                      onCheckedChange={(checked) =>
                        setStreamSettings(prev => ({ ...prev, likesEnabled: checked }))
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="global-mute">Global Mute</Label>
                    <Switch
                      id="global-mute"
                      checked={streamSettings.globalMute}
                      onCheckedChange={(checked) =>
                        setStreamSettings(prev => ({ ...prev, globalMute: checked }))
                      }
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="night-mode">Night Mode (IR)</Label>
                    <Switch
                      id="night-mode"
                      checked={streamSettings.nightMode}
                      onCheckedChange={(checked) =>
                        setStreamSettings(prev => ({ ...prev, nightMode: checked }))
                      }
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageSquare className="w-5 h-5" />
                    Announcements
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    placeholder="Type announcement..."
                    value={announcement}
                    onChange={(e) => setAnnouncement(e.target.value)}
                    className="min-h-[100px]"
                  />
                  
                  <div className="flex gap-2">
                    <Button onClick={sendAnnouncement} disabled={!announcement.trim()}>
                      Send
                    </Button>
                    <Button variant="outline">
                      <Megaphone className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="space-y-2 pt-4 border-t">
                    <Button variant="outline" className="w-full" size="sm">
                      "Big Brother is watching"
                    </Button>
                    <Button variant="outline" className="w-full" size="sm">
                      "Time for nominations"
                    </Button>
                    <Button variant="outline" className="w-full" size="sm">
                      "Lights out in 10 minutes"
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Voting Controls */}
          <TabsContent value="voting" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Vote className="w-5 h-5" />
                  Voting Management
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <Button className="h-20 text-left">
                    <div>
                      <div className="font-medium">Start Eviction Vote</div>
                      <div className="text-sm opacity-75">Open public voting</div>
                    </div>
                  </Button>
                  <Button variant="outline" className="h-20 text-left">
                    <div>
                      <div className="font-medium">Head of House Vote</div>
                      <div className="text-sm opacity-75">Housemate voting only</div>
                    </div>
                  </Button>
                  <Button variant="outline" className="h-20 text-left">
                    <div>
                      <div className="font-medium">Task Winner Vote</div>
                      <div className="text-sm opacity-75">Audience participation</div>
                    </div>
                  </Button>
                  <Button variant="outline" className="h-20 text-left">
                    <div>
                      <div className="font-medium">Close All Voting</div>
                      <div className="text-sm opacity-75">End current polls</div>
                    </div>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Emergency Controls */}
          <TabsContent value="emergency" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-destructive">
                  <AlertTriangle className="w-5 h-5" />
                  Emergency Controls
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <Button variant="destructive" onClick={emergencyStop}>
                    <AlertTriangle className="w-4 h-4 mr-2" />
                    Emergency Stop All
                  </Button>
                  <Button variant="outline" className="border-red-500 text-red-500">
                    <Ban className="w-4 h-4 mr-2" />
                    Cut All Feeds
                  </Button>
                  <Button variant="outline" className="border-yellow-500 text-yellow-500">
                    <EyeOff className="w-4 h-4 mr-2" />
                    Privacy Mode
                  </Button>
                  <Button variant="outline" className="border-orange-500 text-orange-500">
                    <VolumeX className="w-4 h-4 mr-2" />
                    Mute All Audio
                  </Button>
                </div>
                
                <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
                  <h4 className="font-medium text-red-400 mb-2">Emergency Protocols</h4>
                  <ul className="text-sm text-red-200 space-y-1">
                    <li>• Medical emergency: Call support immediately</li>
                    <li>• Technical issues: Use Emergency Stop</li>
                    <li>• Content violations: Cut feeds and investigate</li>
                    <li>• Privacy concerns: Enable Privacy Mode</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
