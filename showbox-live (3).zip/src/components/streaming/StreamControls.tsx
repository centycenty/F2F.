import { useState } from 'react';
import { useLocalParticipant } from '@livekit/components-react';
import { Button } from '@/components/ui/button';
import { Camera, CameraOff, Mic, MicOff, PhoneOff } from 'lucide-react';

export function StreamControls() {
  const { localParticipant } = useLocalParticipant();
  const [isCameraEnabled, setIsCameraEnabled] = useState(true);
  const [isMicEnabled, setIsMicEnabled] = useState(true);

  const toggleCamera = () => {
    localParticipant.setCameraEnabled(!isCameraEnabled);
    setIsCameraEnabled(!isCameraEnabled);
  };

  const toggleMic = () => {
    localParticipant.setMicrophoneEnabled(!isMicEnabled);
    setIsMicEnabled(!isMicEnabled);
  };

  const disconnect = () => {
    // This would typically disconnect from the room
    window.location.reload();
  };

  return (
    <div className="absolute bottom-20 left-1/2 transform -translate-x-1/2 flex gap-4">
      <Button
        variant="ghost"
        size="icon"
        className={`w-12 h-12 rounded-full backdrop-blur-sm ${
          isMicEnabled 
            ? 'bg-white/10 hover:bg-white/20' 
            : 'bg-red-500/80 hover:bg-red-500'
        }`}
        onClick={toggleMic}
      >
        {isMicEnabled ? (
          <Mic className="w-6 h-6 text-white" />
        ) : (
          <MicOff className="w-6 h-6 text-white" />
        )}
      </Button>

      <Button
        variant="ghost"
        size="icon"
        className={`w-12 h-12 rounded-full backdrop-blur-sm ${
          isCameraEnabled 
            ? 'bg-white/10 hover:bg-white/20' 
            : 'bg-red-500/80 hover:bg-red-500'
        }`}
        onClick={toggleCamera}
      >
        {isCameraEnabled ? (
          <Camera className="w-6 h-6 text-white" />
        ) : (
          <CameraOff className="w-6 h-6 text-white" />
        )}
      </Button>

      <Button
        variant="ghost"
        size="icon"
        className="w-12 h-12 rounded-full bg-red-500/80 hover:bg-red-500 backdrop-blur-sm"
        onClick={disconnect}
      >
        <PhoneOff className="w-6 h-6 text-white" />
      </Button>
    </div>
  );
}