import { Play, Mic, MicOff } from "lucide-react";

const housemates = [
  { id: 1, name: "Teez", status: "active", isMuted: false },
  { id: 2, name: "MR.SURE", status: "active", isMuted: true },
  { id: 3, name: "ENOGIE", status: "active", isMuted: false },
  { id: 4, name: "Ikechukwu", status: "active", isMuted: false },
  { id: 5, name: "Alisa", status: "active", isMuted: true },
  { id: 6, name: "Big Bella", status: "active", isMuted: false },
];

export function StreamGrid() {
  const [mainPerformer] = housemates; // First housemate is main performer
  const otherHousemates = housemates.slice(1);

  return (
    <div className="relative h-full">
      {/* Main Performer - Full Screen */}
      <div className="absolute inset-0">
        <div className="relative w-full h-full bg-gradient-to-br from-gray-900 to-gray-800 rounded-lg overflow-hidden">
          {/* Video Stream Placeholder */}
          <div className="w-full h-full bg-gradient-to-br from-purple-900/20 to-pink-900/20 flex items-center justify-center">
            <Play className="w-12 h-12 text-white/50" />
          </div>

          {/* Main Performer Info Overlay */}
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
            <div className="flex items-center justify-between">
              <span className="text-white font-medium text-lg">{mainPerformer.name}</span>
              <div className="flex items-center gap-2">
                {mainPerformer.isMuted ? (
                  <MicOff className="w-5 h-5 text-red-400" />
                ) : (
                  <Mic className="w-5 h-5 text-green-400" />
                )}
              </div>
            </div>
          </div>

          {/* Status Indicator */}
          <div className="absolute top-4 right-4">
            <div className="w-4 h-4 bg-green-400 rounded-full animate-pulse" />
          </div>
        </div>
      </div>

      {/* Other Participants - TikTok Style Stack */}
      <div className="absolute top-4 right-4 flex flex-col gap-2 z-10">
        {otherHousemates.map((housemate) => (
          <div
            key={housemate.id}
            className="relative w-16 h-20 bg-gradient-to-br from-gray-900 to-gray-800 rounded-lg overflow-hidden border-2 border-white/20"
          >
            {/* Mini Video Stream */}
            <div className="w-full h-full bg-gradient-to-br from-purple-900/30 to-pink-900/30 flex items-center justify-center">
              <Play className="w-4 h-4 text-white/60" />
            </div>

            {/* Mini Info Overlay */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 to-transparent p-1">
              <div className="flex items-center justify-between">
                <span className="text-white text-xs font-medium truncate">
                  {housemate.name.slice(0, 6)}
                </span>
                <div className="flex items-center">
                  {housemate.isMuted ? (
                    <MicOff className="w-2 h-2 text-red-400" />
                  ) : (
                    <Mic className="w-2 h-2 text-green-400" />
                  )}
                </div>
              </div>
            </div>

            {/* Mini Status Indicator */}
            <div className="absolute top-1 right-1">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}