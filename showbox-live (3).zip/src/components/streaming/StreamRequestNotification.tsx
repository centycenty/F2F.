import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Bell, 
  X, 
  CheckCircle, 
  Clock, 
  User,
  Video,
  Mic
} from 'lucide-react';

interface StreamRequest {
  id: string;
  userName: string;
  requestType: 'participant' | 'guest' | 'interview';
  reason: string;
  submittedAt: Date;
}

interface StreamRequestNotificationProps {
  requests: StreamRequest[];
  onApprove: (requestId: string) => void;
  onReject: (requestId: string) => void;
  onDismiss: (requestId: string) => void;
  onViewAll: () => void;
}

export function StreamRequestNotification({ 
  requests, 
  onApprove, 
  onReject, 
  onDismiss,
  onViewAll 
}: StreamRequestNotificationProps) {
  const [visibleRequests, setVisibleRequests] = useState<StreamRequest[]>([]);

  useEffect(() => {
    // Show only the 2 most recent requests
    setVisibleRequests(requests.slice(0, 2));
  }, [requests]);

  const getRequestIcon = (type: string) => {
    switch (type) {
      case 'participant': return <User className="w-4 h-4" />;
      case 'guest': return <Video className="w-4 h-4" />;
      case 'interview': return <Mic className="w-4 h-4" />;
      default: return <Bell className="w-4 h-4" />;
    }
  };

  const getRequestColor = (type: string) => {
    switch (type) {
      case 'participant': return 'border-blue-500 bg-blue-500/10';
      case 'guest': return 'border-green-500 bg-green-500/10';
      case 'interview': return 'border-purple-500 bg-purple-500/10';
      default: return 'border-gray-500 bg-gray-500/10';
    }
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / 60000);
    if (diff < 1) return 'Just now';
    return `${diff}m ago`;
  };

  if (visibleRequests.length === 0) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 space-y-3 max-w-sm">
      {/* Header */}
      <div className="bg-gray-900 border border-gray-700 rounded-lg p-3 shadow-lg">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-primary" />
            <span className="font-medium text-sm">New Stream Requests</span>
            <Badge variant="destructive" className="text-xs">
              {requests.length}
            </Badge>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onViewAll}
            className="text-xs h-auto p-1"
          >
            View All
          </Button>
        </div>
      </div>

      {/* Request Cards */}
      {visibleRequests.map((request) => (
        <div
          key={request.id}
          className={`bg-gray-900 border rounded-lg p-4 shadow-lg animate-in slide-in-from-right ${getRequestColor(request.requestType)}`}
        >
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2">
              {getRequestIcon(request.requestType)}
              <div>
                <p className="font-medium text-sm">{request.userName}</p>
                <p className="text-xs text-gray-400">
                  {request.requestType} • {formatTime(request.submittedAt)}
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDismiss(request.id)}
              className="h-auto p-1"
            >
              <X className="w-3 h-3" />
            </Button>
          </div>

          <p className="text-sm text-gray-300 mb-3 line-clamp-2">
            {request.reason.length > 60 
              ? `${request.reason.substring(0, 60)}...` 
              : request.reason
            }
          </p>

          <div className="flex gap-2">
            <Button
              size="sm"
              onClick={() => onApprove(request.id)}
              className="flex-1 bg-green-600 hover:bg-green-700 h-8"
            >
              <CheckCircle className="w-3 h-3 mr-1" />
              Approve
            </Button>
            <Button
              size="sm"
              variant="destructive"
              onClick={() => onReject(request.id)}
              className="flex-1 h-8"
            >
              <X className="w-3 h-3 mr-1" />
              Reject
            </Button>
          </div>
        </div>
      ))}

      {requests.length > 2 && (
        <div className="bg-gray-900 border border-gray-700 rounded-lg p-2 shadow-lg text-center">
          <Button
            variant="ghost"
            size="sm"
            onClick={onViewAll}
            className="text-xs w-full"
          >
            +{requests.length - 2} more requests
          </Button>
        </div>
      )}
    </div>
  );
}
