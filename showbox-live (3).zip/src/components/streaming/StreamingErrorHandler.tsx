import { useState, useEffect } from 'react';
import { AlertTriangle, X, RefreshCw, Camera, Mic } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLocalStream } from './LocalStreamProvider';

interface StreamingErrorHandlerProps {
  children: React.ReactNode;
}

export function StreamingErrorHandler({ children }: StreamingErrorHandlerProps) {
  const { error } = useLocalStream();
  const [showError, setShowError] = useState(false);
  const [retryCount, setRetryCount] = useState(0);

  useEffect(() => {
    if (error) {
      setShowError(true);
    }
  }, [error]);

  const handleRetry = () => {
    setRetryCount(prev => prev + 1);
    setShowError(false);
    // The retry logic would be handled by the parent component
    window.location.reload();
  };

  const handleDismiss = () => {
    setShowError(false);
  };

  const getErrorActions = (errorMessage: string) => {
    if (errorMessage.includes('camera') || errorMessage.includes('video')) {
      return {
        icon: <Camera className="w-5 h-5" />,
        title: 'Camera Issue',
        suggestions: [
          'Check if another app is using your camera',
          'Grant camera permissions in browser settings',
          'Try refreshing the page'
        ]
      };
    }
    
    if (errorMessage.includes('microphone') || errorMessage.includes('audio')) {
      return {
        icon: <Mic className="w-5 h-5" />,
        title: 'Microphone Issue',
        suggestions: [
          'Check if another app is using your microphone',
          'Grant microphone permissions in browser settings',
          'Try refreshing the page'
        ]
      };
    }

    return {
      icon: <AlertTriangle className="w-5 h-5" />,
      title: 'Connection Issue',
      suggestions: [
        'Check your internet connection',
        'Try refreshing the page',
        'Contact support if the issue persists'
      ]
    };
  };

  if (!showError || !error) {
    return <>{children}</>;
  }

  const errorActions = getErrorActions(error);

  return (
    <>
      {children}
      
      {/* Error Overlay */}
      <div className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div className="bg-gray-900 border border-gray-700 rounded-lg max-w-md w-full p-6 text-white">
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-500/20 rounded-full text-red-400">
                {errorActions.icon}
              </div>
              <h3 className="text-lg font-semibold text-white">
                {errorActions.title}
              </h3>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleDismiss}
              className="text-gray-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Error Message */}
          <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3 mb-4">
            <p className="text-red-200 text-sm">{error}</p>
          </div>

          {/* Suggestions */}
          <div className="mb-6">
            <h4 className="text-sm font-medium text-gray-300 mb-3">Try these solutions:</h4>
            <ul className="space-y-2">
              {errorActions.suggestions.map((suggestion, index) => (
                <li key={index} className="flex items-start gap-2 text-sm text-gray-400">
                  <span className="w-4 h-4 rounded-full bg-gray-700 flex items-center justify-center text-xs font-medium text-gray-300 mt-0.5 flex-shrink-0">
                    {index + 1}
                  </span>
                  {suggestion}
                </li>
              ))}
            </ul>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button
              onClick={handleRetry}
              className="flex-1"
              disabled={retryCount >= 3}
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              {retryCount >= 3 ? 'Too many retries' : 'Try Again'}
            </Button>
            <Button
              variant="outline"
              onClick={handleDismiss}
              className="border-gray-600 hover:bg-gray-800"
            >
              Continue
            </Button>
          </div>

          {retryCount > 0 && (
            <p className="text-xs text-gray-500 mt-3 text-center">
              Retry attempt: {retryCount}/3
            </p>
          )}
        </div>
      </div>
    </>
  );
}
