import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  MoreHorizontal,
  Flag,
  Share,
  Heart,
  MessageCircle,
  Eye
} from 'lucide-react';

interface VideoPlayerProps {
  videoUrl?: string;
  thumbnail?: string;
  title: string;
  duration: number;
  isPlaying?: boolean;
  isMuted?: boolean;
  onPlay?: () => void;
  onPause?: () => void;
  onToggleMute?: () => void;
  onLike?: () => void;
  onComment?: () => void;
  onShare?: () => void;
  onReport?: () => void;
  likes: number;
  comments: number;
  views: number;
  isLiked?: boolean;
  className?: string;
}

export function VideoPlayer({
  videoUrl,
  thumbnail,
  title,
  duration,
  isPlaying = false,
  isMuted = false,
  onPlay,
  onPause,
  onToggleMute,
  onLike,
  onComment,
  onShare,
  onReport,
  likes,
  comments,
  views,
  isLiked = false,
  className = ''
}: VideoPlayerProps) {
  const [currentTime, setCurrentTime] = useState(0);
  const [showControls, setShowControls] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleTimeUpdate = () => {
      setCurrentTime(video.currentTime);
    };

    const handleLoadedMetadata = () => {
      setCurrentTime(0);
    };

    video.addEventListener('timeupdate', handleTimeUpdate);
    video.addEventListener('loadedmetadata', handleLoadedMetadata);

    return () => {
      video.removeEventListener('timeupdate', handleTimeUpdate);
      video.removeEventListener('loadedmetadata', handleLoadedMetadata);
    };
  }, []);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    if (isPlaying) {
      video.play().catch(console.warn);
    } else {
      video.pause();
    }
  }, [isPlaying]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = isMuted;
  }, [isMuted]);

  const handlePlayPause = () => {
    if (isPlaying) {
      onPause?.();
    } else {
      onPlay?.();
    }
  };

  const handleFullscreen = () => {
    if (containerRef.current) {
      if (!isFullscreen) {
        containerRef.current.requestFullscreen?.();
      } else {
        document.exitFullscreen?.();
      }
      setIsFullscreen(!isFullscreen);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progressPercentage = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div 
      ref={containerRef}
      className={`relative bg-black rounded-lg overflow-hidden group ${className}`}
      onMouseEnter={() => setShowControls(true)}
      onMouseLeave={() => setShowControls(false)}
    >
      {/* Video Element */}
      <video
        ref={videoRef}
        className="w-full h-full object-cover"
        poster={thumbnail}
        loop
        playsInline
        preload="metadata"
      >
        {videoUrl && <source src={videoUrl} type="video/mp4" />}
      </video>

      {/* Overlay Controls */}
      <div className={`absolute inset-0 bg-black/20 transition-opacity duration-300 ${
        showControls ? 'opacity-100' : 'opacity-0'
      }`}>
        
        {/* Center Play Button */}
        <div className="absolute inset-0 flex items-center justify-center">
          <Button
            variant="ghost"
            size="icon"
            onClick={handlePlayPause}
            className="w-16 h-16 rounded-full bg-black/80 backdrop-blur-sm hover:bg-black/90 text-white"
          >
            {isPlaying ? (
              <Pause className="w-8 h-8 text-white" />
            ) : (
              <Play className="w-8 h-8 text-white ml-1" />
            )}
          </Button>
        </div>

        {/* Top Controls */}
        <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-black/80 backdrop-blur-sm px-2 py-1 rounded text-xs text-white">
              {formatTime(currentTime)} / {formatTime(duration)}
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={onToggleMute}
              className="w-8 h-8 bg-black/50 backdrop-blur-sm hover:bg-black/70"
            >
              {isMuted ? (
                <VolumeX className="w-4 h-4 text-white" />
              ) : (
                <Volume2 className="w-4 h-4 text-white" />
              )}
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={handleFullscreen}
              className="w-8 h-8 bg-black/50 backdrop-blur-sm hover:bg-black/70"
            >
              <Maximize className="w-4 h-4 text-white" />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={onReport}
              className="w-8 h-8 bg-black/50 backdrop-blur-sm hover:bg-black/70"
            >
              <Flag className="w-4 h-4 text-white" />
            </Button>
          </div>
        </div>

        {/* Bottom Controls */}
        <div className="absolute bottom-4 left-4 right-4">
          {/* Progress Bar */}
          <div className="mb-3">
            <div className="w-full bg-white/20 rounded-full h-1">
              <div 
                className="bg-primary h-1 rounded-full transition-all duration-300"
                style={{ width: `${progressPercentage}%` }}
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={onLike}
                className={`bg-black/50 backdrop-blur-sm hover:bg-black/70 ${
                  isLiked ? 'text-red-500' : 'text-white'
                }`}
              >
                <Heart className="w-4 h-4" fill={isLiked ? 'currentColor' : 'none'} />
                <span className="ml-1 text-xs">{likes > 0 ? likes : ''}</span>
              </Button>

              <Button
                variant="ghost"
                size="sm"
                onClick={onComment}
                className="bg-black/50 backdrop-blur-sm hover:bg-black/70 text-white"
              >
                <MessageCircle className="w-4 h-4" />
                <span className="ml-1 text-xs">{comments > 0 ? comments : ''}</span>
              </Button>

              <Button
                variant="ghost"
                size="sm"
                onClick={onShare}
                className="bg-black/50 backdrop-blur-sm hover:bg-black/70 text-white"
              >
                <Share className="w-4 h-4" />
              </Button>
            </div>

            <div className="flex items-center gap-2 bg-black/50 backdrop-blur-sm px-2 py-1 rounded text-xs">
              <Eye className="w-3 h-3" />
              <span>{views > 0 ? views : 0} views</span>
            </div>
          </div>
        </div>
      </div>

      {/* Loading State */}
      {!videoUrl && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-800">
          <div className="text-center">
            <Play className="w-12 h-12 mx-auto mb-2 text-gray-400" />
            <p className="text-sm text-gray-400">Video Preview</p>
          </div>
        </div>
      )}
    </div>
  );
}
