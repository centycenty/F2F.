import { VideoTrack, AudioTrack } from '@livekit/components-react';
import { Participant, Track } from 'livekit-client';
import { Mic, MicOff, Video, VideoOff } from 'lucide-react';

interface VideoTileProps {
  participant: Participant;
  isMain?: boolean;
}

export function VideoTile({ participant, isMain = false }: VideoTileProps) {
  const cameraPublication = participant.getTrackPublication(Track.Source.Camera);
  const microphonePublication = participant.getTrackPublication(Track.Source.Microphone);
  const isLocal = participant.isLocal;
  
  const isCameraEnabled = cameraPublication?.isEnabled ?? false;
  const isMicEnabled = microphonePublication?.isEnabled ?? false;

  return (
    <div className={`relative bg-gray-900 rounded-lg overflow-hidden ${
      isMain ? "col-span-2 row-span-2" : ""
    }`}>
      {/* Video Stream */}
      {isCameraEnabled && cameraPublication?.track ? (
        <VideoTrack 
          trackRef={{
            participant: participant,
            source: Track.Source.Camera,
            publication: cameraPublication
          }}
          className="w-full h-full object-cover"
        />
      ) : (
        <div className="w-full h-full bg-gradient-to-br from-purple-900/20 to-pink-900/20 flex items-center justify-center">
          <VideoOff className="w-8 h-8 text-white/50" />
        </div>
      )}

      {/* Audio Track (hidden but necessary for audio) */}
      {isMicEnabled && microphonePublication?.track && (
        <AudioTrack 
          trackRef={{
            participant: participant,
            source: Track.Source.Microphone,
            publication: microphonePublication
          }}
        />
      )}

      {/* Participant Info Overlay */}
      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3">
        <div className="flex items-center justify-between">
          <span className="text-white font-medium">
            {participant.identity || participant.name || 'Unknown'}
            {isLocal && ' (You)'}
          </span>
          <div className="flex items-center gap-2">
            {isMicEnabled ? (
              <Mic className="w-4 h-4 text-green-400" />
            ) : (
              <MicOff className="w-4 h-4 text-red-400" />
            )}
            {isCameraEnabled ? (
              <Video className="w-4 h-4 text-green-400" />
            ) : (
              <VideoOff className="w-4 h-4 text-red-400" />
            )}
          </div>
        </div>
      </div>

      {/* Status Indicator */}
      <div className="absolute top-2 right-2">
        <div className={`w-3 h-3 rounded-full ${
          participant.connectionQuality === 'excellent' ? 'bg-green-400' :
          participant.connectionQuality === 'good' ? 'bg-yellow-400' :
          'bg-red-400'
        } animate-pulse`} />
      </div>
    </div>
  );
}