import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Heart, Trophy, Users, Clock, CheckCircle } from "lucide-react";

interface VotingModalProps {
  isOpen: boolean;
  onClose: () => void;
  userAuth: boolean;
  onAuthRequired: () => void;
}

interface VotingOption {
  name: string;
  votes: number;
  percentage: number;
}

interface Poll {
  id: number;
  title: string;
  type: string;
  options: VotingOption[];
  timeRemaining?: string;
  totalVotes: number;
}

export function VotingModal({ isOpen, onClose, userAuth, onAuthRequired }: VotingModalProps) {
  const [selectedVotes, setSelectedVotes] = useState<Record<number, string>>({});
  const [polls, setPolls] = useState<Poll[]>([
    {
      id: 1,
      title: "Favorite Housemate",
      type: "favorite",
      options: [
        { name: "Teez", votes: 1240, percentage: 35 },
        { name: "Alisa", votes: 890, percentage: 25 },
        { name: "Big Bella", votes: 756, percentage: 21 },
        { name: "MR.SURE", votes: 534, percentage: 15 },
        { name: "Others", votes: 142, percentage: 4 },
      ],
      totalVotes: 3562,
      timeRemaining: "2d 14h"
    },
    {
      id: 2,
      title: "Next Task Suggestion",
      type: "task",
      options: [
        { name: "Cooking Challenge", votes: 2100, percentage: 45 },
        { name: "Truth or Dare", votes: 1800, percentage: 38 },
        { name: "Dance Competition", votes: 800, percentage: 17 },
      ],
      totalVotes: 4700,
      timeRemaining: "6h 23m"
    },
    {
      id: 3,
      title: "Who Should Win Head of House?",
      type: "hoh",
      options: [
        { name: "Teez", votes: 890, percentage: 32 },
        { name: "Big Bella", votes: 720, percentage: 26 },
        { name: "Alisa", votes: 650, percentage: 23 },
        { name: "ENOGIE", votes: 530, percentage: 19 },
      ],
      totalVotes: 2790,
      timeRemaining: "1h 45m"
    }
  ]);

  // Simulate real-time vote updates
  useEffect(() => {
    if (!isOpen) return;

    const interval = setInterval(() => {
      setPolls(prevPolls => 
        prevPolls.map(poll => ({
          ...poll,
          options: poll.options.map(option => {
            // Random vote increment (0-5 votes)
            const increment = Math.floor(Math.random() * 6);
            const newVotes = option.votes + increment;
            return { ...option, votes: newVotes };
          })
        })).map(poll => {
          // Recalculate percentages and total
          const totalVotes = poll.options.reduce((sum, option) => sum + option.votes, 0);
          return {
            ...poll,
            totalVotes,
            options: poll.options.map(option => ({
              ...option,
              percentage: Math.round((option.votes / totalVotes) * 100)
            }))
          };
        })
      );
    }, 3000); // Update every 3 seconds

    return () => clearInterval(interval);
  }, [isOpen]);

  const handleVote = (pollId: number, option: string) => {
    if (!userAuth) {
      onAuthRequired();
      return;
    }
    
    // Update local state
    setSelectedVotes(prev => ({
      ...prev,
      [pollId]: option
    }));

    // Simulate adding vote to the option
    setPolls(prevPolls => 
      prevPolls.map(poll => {
        if (poll.id === pollId) {
          return {
            ...poll,
            options: poll.options.map(opt => {
              if (opt.name === option) {
                const newVotes = opt.votes + 1;
                return { ...opt, votes: newVotes };
              }
              return opt;
            })
          };
        }
        return poll;
      }).map(poll => {
        // Recalculate percentages
        if (poll.id === pollId) {
          const totalVotes = poll.options.reduce((sum, option) => sum + option.votes, 0);
          return {
            ...poll,
            totalVotes,
            options: poll.options.map(option => ({
              ...option,
              percentage: Math.round((option.votes / totalVotes) * 100)
            }))
          };
        }
        return poll;
      })
    );
  };

  const getPollIcon = (type: string) => {
    switch (type) {
      case "favorite":
        return <Heart className="w-5 h-5 text-primary" />;
      case "task":
        return <Trophy className="w-5 h-5 text-accent" />;
      case "hoh":
        return <Users className="w-5 h-5 text-yellow-500" />;
      default:
        return <Trophy className="w-5 h-5 text-accent" />;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto bg-card">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-accent" />
            Live Voting & Polls
            <Badge variant="outline" className="ml-2">LIVE</Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
          {polls.map((poll) => (
            <Card key={poll.id} className="border-border">
              <CardHeader>
                <CardTitle className="flex items-center justify-between text-lg">
                  <div className="flex items-center gap-2">
                    {getPollIcon(poll.type)}
                    {poll.title}
                  </div>
                  {poll.timeRemaining && (
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      {poll.timeRemaining}
                    </div>
                  )}
                </CardTitle>
                <div className="text-sm text-muted-foreground">
                  {poll.totalVotes.toLocaleString()} total votes
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {poll.options.map((option) => (
                  <div key={option.name} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Button
                        variant={selectedVotes[poll.id] === option.name ? "default" : "outline"}
                        size="sm"
                        onClick={() => handleVote(poll.id, option.name)}
                        disabled={selectedVotes[poll.id] && selectedVotes[poll.id] !== option.name}
                        className="min-w-[140px] justify-start relative"
                      >
                        {option.name}
                        {selectedVotes[poll.id] === option.name && (
                          <CheckCircle className="w-4 h-4 ml-2" />
                        )}
                      </Button>
                      <div className="text-right">
                        <div className="text-sm font-medium">
                          {option.votes.toLocaleString()} ({option.percentage}%)
                        </div>
                      </div>
                    </div>
                    
                    {/* Animated Progress Bar */}
                    <Progress 
                      value={option.percentage} 
                      className="h-2 bg-muted"
                    />
                  </div>
                ))}

                {selectedVotes[poll.id] && (
                  <div className="mt-4 p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
                    <div className="flex items-center gap-2 text-green-400 text-sm">
                      <CheckCircle className="w-4 h-4" />
                      Vote submitted for "{selectedVotes[poll.id]}"
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {!userAuth && (
          <Card className="border-accent/50 bg-accent/5 mt-6">
            <CardContent className="p-6 text-center">
              <Trophy className="w-8 h-8 mx-auto mb-3 text-accent" />
              <h3 className="font-semibold mb-2">Join the Community!</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Sign up to vote in polls, influence tasks, and help choose your favorite housemates!
              </p>
              <Button onClick={onAuthRequired} size="lg" className="w-full">
                Quick Sign Up - Start Voting!
              </Button>
            </CardContent>
          </Card>
        )}

        {userAuth && (
          <div className="text-center text-sm text-muted-foreground mt-4">
            <p>Thanks for participating! Your votes help shape the show. 🎉</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
