import { useState } from 'react';
import { useLocalStream } from '@/components/streaming/LocalStreamProvider';

interface RoomConfig {
  serverUrl: string;
  token: string;
  roomName: string;
}

export function useRoomConnection() {
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { connect, disconnect, isConnected } = useLocalStream();

  const connectToRoom = async (roomName: string, participantName: string) => {
    setIsConnecting(true);
    setError(null);

    try {
      await connect(roomName, participantName);
    } catch (err) {
      setError('Failed to connect to room');
      console.error('Room connection error:', err);
    } finally {
      setIsConnecting(false);
    }
  };

  const disconnectFromRoom = () => {
    disconnect();
    setError(null);
  };

  // Create a mock room config for compatibility with existing code
  const roomConfig: RoomConfig | null = isConnected ? {
    serverUrl: 'local://demo',
    token: 'demo-token',
    roomName: 'bigbrother-house'
  } : null;

  return {
    roomConfig,
    isConnecting,
    error,
    connectToRoom,
    disconnectFromRoom,
    isConnected
  };
}
