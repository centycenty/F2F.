// Mock LiveKit server implementation for demo purposes
// This simulates real streaming functionality without requiring external LiveKit infrastructure

interface MockParticipant {
  id: string;
  name: string;
  isLocal: boolean;
  videoEnabled: boolean;
  audioEnabled: boolean;
  stream?: MediaStream;
}

interface MockRoom {
  name: string;
  participants: Map<string, MockParticipant>;
  listeners: Map<string, Function[]>;
}

class MockLiveKitServer {
  private rooms: Map<string, MockRoom> = new Map();
  private localStream: MediaStream | null = null;

  async createRoom(roomName: string): Promise<MockRoom> {
    if (!this.rooms.has(roomName)) {
      this.rooms.set(roomName, {
        name: roomName,
        participants: new Map(),
        listeners: new Map()
      });
    }
    return this.rooms.get(roomName)!;
  }

  async joinRoom(roomName: string, participantName: string): Promise<{
    room: MockRoom;
    localParticipant: MockParticipant;
    token: string;
  }> {
    const room = await this.createRoom(roomName);
    
    // Get user media for local participant
    try {
      this.localStream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      });
    } catch (error) {
      console.warn('Could not access camera/microphone:', error);
      // Try to get just video or just audio
      try {
        this.localStream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: false
        });
        console.log('Got video-only stream');
      } catch (videoError) {
        try {
          this.localStream = await navigator.mediaDevices.getUserMedia({
            video: false,
            audio: true
          });
          console.log('Got audio-only stream');
        } catch (audioError) {
          console.warn('No media access, creating empty stream');
          // Create empty stream if no permission at all
          this.localStream = new MediaStream();
        }
      }
    }

    const localParticipant: MockParticipant = {
      id: `local-${Date.now()}`,
      name: participantName,
      isLocal: true,
      videoEnabled: true,
      audioEnabled: true,
      stream: this.localStream
    };

    room.participants.set(localParticipant.id, localParticipant);

    // Add some mock remote participants for demo
    if (room.participants.size === 1) {
      this.addMockRemoteParticipants(room);
    }

    // Notify listeners about new participant
    this.emitEvent(room, 'participantConnected', localParticipant);

    return {
      room,
      localParticipant,
      token: this.generateToken(roomName, participantName)
    };
  }

  private addMockRemoteParticipants(room: MockRoom) {
    const mockParticipants = [
      { name: 'Teez', id: 'mock-1' },
      { name: 'MR.SURE', id: 'mock-2' },
      { name: 'ENOGIE', id: 'mock-3' },
      { name: 'Ikechukwu', id: 'mock-4' }
    ];

    mockParticipants.forEach(mock => {
      const participant: MockParticipant = {
        id: mock.id,
        name: mock.name,
        isLocal: false,
        videoEnabled: Math.random() > 0.3, // Random video state
        audioEnabled: Math.random() > 0.2, // Random audio state
        stream: this.createMockVideoStream()
      };

      room.participants.set(participant.id, participant);
      
      // Simulate delayed connection
      setTimeout(() => {
        this.emitEvent(room, 'participantConnected', participant);
      }, Math.random() * 3000);
    });
  }

  private createMockVideoStream(): MediaStream {
    // Create a mock video stream using canvas
    const canvas = document.createElement('canvas');
    canvas.width = 320;
    canvas.height = 240;
    const ctx = canvas.getContext('2d')!;
    
    // Create animated gradient background
    const animate = () => {
      const time = Date.now() * 0.001;
      const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
      gradient.addColorStop(0, `hsl(${(time * 50) % 360}, 70%, 50%)`);
      gradient.addColorStop(1, `hsl(${(time * 30 + 180) % 360}, 70%, 30%)`);
      
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      // Add some moving elements
      ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
      for (let i = 0; i < 5; i++) {
        const x = (Math.sin(time + i) * 0.5 + 0.5) * canvas.width;
        const y = (Math.cos(time * 0.7 + i) * 0.5 + 0.5) * canvas.height;
        ctx.beginPath();
        ctx.arc(x, y, 20, 0, Math.PI * 2);
        ctx.fill();
      }
      
      requestAnimationFrame(animate);
    };
    
    animate();

    // @ts-ignore - captureStream is supported in modern browsers
    const videoStream = canvas.captureStream(30);

    // Add mock audio track with speech-like patterns
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const destination = audioContext.createMediaStreamDestination();

      // Create speech-like audio patterns
      const createSpeechPattern = () => {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        const filterNode = audioContext.createBiquadFilter();

        // Random frequency for different "voices"
        const baseFreq = 80 + Math.random() * 200; // Human voice range
        oscillator.frequency.setValueAtTime(baseFreq, audioContext.currentTime);

        // Apply filter for more natural sound
        filterNode.type = 'lowpass';
        filterNode.frequency.setValueAtTime(1000, audioContext.currentTime);

        // Very low volume to simulate background conversation
        gainNode.gain.setValueAtTime(0.02, audioContext.currentTime);

        // Connect nodes
        oscillator.connect(filterNode);
        filterNode.connect(gainNode);
        gainNode.connect(destination);

        // Create speech-like pattern
        const patternDuration = 0.5 + Math.random() * 1.5; // 0.5-2 seconds
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + patternDuration);

        // Schedule next pattern with pause
        setTimeout(() => {
          if (audioContext.state !== 'closed') {
            createSpeechPattern();
          }
        }, (patternDuration + Math.random() * 2) * 1000); // 0-2 second pause
      };

      // Start initial pattern
      createSpeechPattern();

      // Add audio track to video stream
      destination.stream.getAudioTracks().forEach(track => {
        videoStream.addTrack(track);
      });

    } catch (e) {
      console.warn('Could not create mock audio:', e);
    }

    return videoStream;
  }

  private generateToken(roomName: string, participantName: string): string {
    return btoa(JSON.stringify({
      room: roomName,
      participant: participantName,
      timestamp: Date.now(),
      demo: true
    }));
  }

  addEventListener(room: MockRoom, event: string, callback: Function) {
    if (!room.listeners.has(event)) {
      room.listeners.set(event, []);
    }
    room.listeners.get(event)!.push(callback);
  }

  removeEventListener(room: MockRoom, event: string, callback: Function) {
    if (room.listeners.has(event)) {
      const listeners = room.listeners.get(event)!;
      const index = listeners.indexOf(callback);
      if (index > -1) {
        listeners.splice(index, 1);
      }
    }
  }

  private emitEvent(room: MockRoom, event: string, data: any) {
    if (room.listeners.has(event)) {
      room.listeners.get(event)!.forEach(callback => callback(data));
    }
  }

  updateParticipant(room: MockRoom, participantId: string, updates: Partial<MockParticipant>) {
    const participant = room.participants.get(participantId);
    if (participant) {
      Object.assign(participant, updates);
      this.emitEvent(room, 'participantUpdated', participant);
    }
  }

  leaveRoom(room: MockRoom, participantId: string) {
    const participant = room.participants.get(participantId);
    if (participant) {
      room.participants.delete(participantId);
      this.emitEvent(room, 'participantDisconnected', participant);
      
      // Clean up local stream
      if (participant.isLocal && participant.stream) {
        participant.stream.getTracks().forEach(track => track.stop());
      }
    }
  }

  stopLocalStream() {
    if (this.localStream) {
      this.localStream.getTracks().forEach(track => track.stop());
      this.localStream = null;
    }
  }
}

// Singleton instance
export const mockLiveKitServer = new MockLiveKitServer();

// Export types
export type { MockParticipant, MockRoom };
