import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { 
  BarChart3, 
  Users, 
  Heart, 
  MessageSquare, 
  Trophy, 
  Settings,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Shield,
  Eye,
  TrendingUp
} from "lucide-react";

const Admin = () => {
  const [streamStatus, setStreamStatus] = useState({
    isLive: true,
    totalViewers: 15420,
    peakViewers: 18932,
    totalLikes: 45672,
    totalComments: 12840,
    activePolls: 3,
  });

  const [housemates] = useState([
    { id: 1, name: "Teez", votes: 2340, likes: 8920, comments: 1240, isLive: true, isMuted: false },
    { id: 2, name: "Alisa", votes: 2100, likes: 7650, comments: 1100, isLive: true, isMuted: false },
    { id: 3, name: "Big Bella", votes: 1980, likes: 6840, comments: 980, isLive: true, isMuted: true },
    { id: 4, name: "MR.SURE", votes: 1720, likes: 5930, comments: 890, isLive: true, isMuted: false },
    { id: 5, name: "ENOGIE", votes: 1560, likes: 4820, comments: 756, isLive: true, isMuted: false },
    { id: 6, name: "Ikechukwu", votes: 1340, likes: 3920, comments: 534, isLive: false, isMuted: false },
  ]);

  const [newAnnouncement, setNewAnnouncement] = useState("");
  const [newTask, setNewTask] = useState({ title: "", description: "" });

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">BigBrotherNaija Admin</h1>
            <p className="text-muted-foreground">Manage live stream and show activities</p>
          </div>
          <div className="flex items-center gap-4">
            <Badge variant={streamStatus.isLive ? "default" : "secondary"} className="px-3 py-1">
              {streamStatus.isLive ? "🔴 LIVE" : "⏸️ OFFLINE"}
            </Badge>
            <Button 
              variant={streamStatus.isLive ? "destructive" : "default"}
              onClick={() => setStreamStatus(prev => ({ ...prev, isLive: !prev.isLive }))}
            >
              {streamStatus.isLive ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
              {streamStatus.isLive ? "End Stream" : "Start Stream"}
            </Button>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Viewers</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{streamStatus.totalViewers.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                Peak: {streamStatus.peakViewers.toLocaleString()}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Likes</CardTitle>
              <Heart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{streamStatus.totalLikes.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                +2.3k in last hour
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Comments</CardTitle>
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{streamStatus.totalComments.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                +890 in last hour
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Polls</CardTitle>
              <Trophy className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{streamStatus.activePolls}</div>
              <p className="text-xs text-muted-foreground">
                2 ending soon
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Housemate Management */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Housemate Performance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {housemates.map((housemate, index) => (
                  <div key={housemate.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-muted-foreground">#{index + 1}</span>
                        <div className={`w-3 h-3 rounded-full ${housemate.isLive ? 'bg-green-400' : 'bg-gray-400'}`} />
                        <span className="font-medium">{housemate.name}</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-1">
                        <Trophy className="w-4 h-4 text-accent" />
                        {housemate.votes}
                      </div>
                      <div className="flex items-center gap-1">
                        <Heart className="w-4 h-4 text-primary" />
                        {housemate.likes}
                      </div>
                      <div className="flex items-center gap-2">
                        <Button size="sm" variant="outline" className="h-8 w-8 p-0">
                          {housemate.isMuted ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
                        </Button>
                        <Button size="sm" variant="outline" className="h-8 w-8 p-0">
                          <Eye className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <div className="space-y-6">
            {/* Send Announcement */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="w-5 h-5" />
                  Send Announcement
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  placeholder="Type announcement message..."
                  value={newAnnouncement}
                  onChange={(e) => setNewAnnouncement(e.target.value)}
                  className="min-h-[80px]"
                />
                <div className="flex gap-2">
                  <Button className="flex-1" disabled={!newAnnouncement.trim()}>
                    Send to All
                  </Button>
                  <Button variant="outline">
                    Schedule
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Create Task */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="w-5 h-5" />
                  Create New Task
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Input
                  placeholder="Task title..."
                  value={newTask.title}
                  onChange={(e) => setNewTask(prev => ({ ...prev, title: e.target.value }))}
                />
                <Textarea
                  placeholder="Task description..."
                  value={newTask.description}
                  onChange={(e) => setNewTask(prev => ({ ...prev, description: e.target.value }))}
                  className="min-h-[60px]"
                />
                <Button className="w-full" disabled={!newTask.title.trim()}>
                  Create Task & Start Voting
                </Button>
              </CardContent>
            </Card>

            {/* Stream Controls */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Stream Controls
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="comments">Allow Comments</Label>
                  <Switch id="comments" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="likes">Allow Likes</Label>
                  <Switch id="likes" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="voting">Enable Voting</Label>
                  <Switch id="voting" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="automod">Auto Moderation</Label>
                  <Switch id="automod" defaultChecked />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Admin;