import { StreamingApp } from "@/components/StreamingApp";

const Index = () => {
  return <StreamingApp />;
};

export default Index;
